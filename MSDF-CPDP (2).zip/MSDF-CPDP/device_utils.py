# device_utils.py
"""
设备管理工具，确保所有数据都在正确设备上
"""

import torch
from torch_geometric.data import Data, Batch

class DeviceManager:
    def __init__(self, device=None):
        self.device = device or torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        print(f"设备管理器初始化: 使用 {self.device}")
    
    def to_device(self, data, device=None):
        """将任意数据移动到指定设备"""
        target_device = device or self.device
        
        if isinstance(data, torch.Tensor):
            return data.to(target_device)
        elif isinstance(data, Data):  # PyG Data对象
            return data.to(target_device)
        elif isinstance(data, Batch):  # PyG Batch对象
            return data.to(target_device)
        elif isinstance(data, (list, tuple)):
            return type(data)(self.to_device(item, target_device) for item in data)
        elif isinstance(data, dict):
            return {key: self.to_device(value, target_device) for key, value in data.items()}
        elif hasattr(data, 'to'):
            # 其他有to方法的数据类型
            return data.to(target_device)
        else:
            return data
    
    def ensure_same_device(self, model, *data_items):
        """确保数据和模型在同一设备上"""
        model_device = next(model.parameters()).device
        
        result = []
        for item in data_items:
            if isinstance(item, (torch.Tensor, Data, Batch)):
                if item.device != model_device:
                    item = item.to(model_device)
            result.append(item)
        
        return result if len(result) > 1 else result[0]

# 全局设备管理器实例
device_manager = DeviceManager()

# 快捷函数
def get_device():
    return device_manager.device

def move_to_device(data):
    return device_manager.to_device(data)