# gmf_simcom.py
"""
SimCom++ 完整实现（修正版）
修复记录：
  1. SlimGMF: hand_expander 20→48→64，hidden_dim=64，向量门控
  2. SimComPlusPlus.fit(): 删除内部 Com 冗余训练
  3. SimComPlusPlus.fit(): GMF 早停使用真正独立验证集（MPOS 前划分）
  4. SimComPlusPlus.extract_purified_features(): 修复解包 bug
  5. 默认 gmf_hidden=64
"""

import numpy as np
import torch
import torch.nn as nn
import copy
import torch.nn.functional as F
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import QuantileTransformer
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, matthews_corrcoef


# =============================================================================
# 损失函数
# =============================================================================

def orthogonality_loss(feat_h, feat_g):
    """正交损失：手工特征和 GNN 特征的余弦相似度平方，越接近 0 越互补。"""
    if feat_h.size(1) != feat_g.size(1):
        min_dim = min(feat_h.size(1), feat_g.size(1))
        feat_h = feat_h[:, :min_dim]
        feat_g = feat_g[:, :min_dim]
    cos_sim = F.cosine_similarity(feat_h, feat_g)
    return torch.mean(cos_sim ** 2)


def coral_loss(source, target):
    """CORAL Loss：源域和目标域特征协方差矩阵的 Frobenius 距离。"""
    d = source.size(1)
    src_c = source - torch.mean(source, 0, keepdim=True)
    tar_c = target - torch.mean(target, 0, keepdim=True)
    src_cov = (src_c.t() @ src_c) / (source.size(0) - 1)
    tar_cov = (tar_c.t() @ tar_c) / (target.size(0) - 1)
    return torch.sum((src_cov - tar_cov) ** 2) / (4 * d * d)


def center_loss_binary(features: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
    """二分类 center loss: 正类向正类中心收缩, 负类向负类中心收缩"""
    if labels.dim() > 1:
        labels = labels.view(-1)
    pos_mask = labels > 0.5
    neg_mask = labels <= 0.5
    loss = torch.tensor(0.0, device=features.device)
    terms = 0
    if pos_mask.sum() >= 2:
        pos_feats = features[pos_mask]
        pos_center = pos_feats.mean(dim=0, keepdim=True)
        loss = loss + F.mse_loss(pos_feats, pos_center.expand_as(pos_feats))
        terms += 1
    if neg_mask.sum() >= 2:
        neg_feats = features[neg_mask]
        neg_center = neg_feats.mean(dim=0, keepdim=True)
        loss = loss + F.mse_loss(neg_feats, neg_center.expand_as(neg_feats))
        terms += 1
    if terms == 0:
        return torch.tensor(0.0, device=features.device)
    return loss / terms


def center_margin_loss(features: torch.Tensor, labels: torch.Tensor, margin: float = 1.0) -> torch.Tensor:
    """二分类 margin loss: 最大化正负类中心的欧氏距离"""
    if labels.dim() > 1:
        labels = labels.view(-1)
    pos_mask = labels > 0.5
    neg_mask = labels <= 0.5
    if pos_mask.sum() < 1 or neg_mask.sum() < 1:
        return torch.tensor(0.0, device=features.device)
    pos_center = features[pos_mask].mean(dim=0)
    neg_center = features[neg_mask].mean(dim=0)
    dist = torch.norm(pos_center - neg_center, p=2)
    return F.relu(torch.tensor(margin, device=features.device) - dist)


# =============================================================================
# 基础模块
# =============================================================================

class CosineLinear(nn.Module):
    """余弦分类头：免疫跨项目特征模长剧变。"""
    def __init__(self, in_features, out_features=1, scale=15.0):
        super().__init__()
        self.weight = nn.Parameter(torch.Tensor(out_features, in_features))
        self.scale  = nn.Parameter(torch.FloatTensor([scale]))
        nn.init.xavier_uniform_(self.weight)

    def forward(self, x):
        x_norm = F.normalize(x, p=2, dim=1)
        w_norm = F.normalize(self.weight, p=2, dim=1)
        return F.linear(x_norm, w_norm) * self.scale


class FocalLoss(nn.Module):
    """Focal Loss：缓解类不平衡。"""
    def __init__(self, alpha=0.25, gamma=2, reduction='mean'):
        super().__init__()
        self.alpha     = alpha
        self.gamma     = gamma
        self.reduction = reduction

    def forward(self, inputs, targets):
        bce  = F.binary_cross_entropy(inputs, targets, reduction='none')
        pt   = torch.exp(-bce)
        af   = self.alpha * targets + (1 - self.alpha) * (1 - targets)
        loss = af * (1 - pt) ** self.gamma * bce
        return loss.mean() if self.reduction == 'mean' else loss.sum()


class MLPClassifierWrapper(nn.Module):
    """
    GNN 分支 MLP（sklearn 风格接口）。
    fit() / predict_proba() 与 RandomForestClassifier 接口兼容。
    """
    def __init__(self, input_dim, hidden_dim=64, dropout=0.5,
                 lr=0.001, epochs=50, batch_size=32, device='cuda'):
        super().__init__()
        self.device     = device
        self.epochs     = epochs
        self.batch_size = batch_size

        self.model = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.BatchNorm1d(hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
        ).to(device)
        self.classifier = CosineLinear(hidden_dim // 2, 1, scale=15.0).to(device)
        self.criterion  = FocalLoss(alpha=0.75, gamma=2)
        self.optimizer  = torch.optim.AdamW(
            list(self.model.parameters()) + list(self.classifier.parameters()),
            lr=lr, weight_decay=1e-3
        )

    def forward(self, x):
        return torch.sigmoid(self.classifier(self.model(x)).squeeze(-1))

    def fit(self, X, y):
        self.train()
        X_t = torch.FloatTensor(X).to(self.device)
        y_t = torch.FloatTensor(y).to(self.device)
        n   = len(X)
        for _ in range(self.epochs):
            idx = torch.randperm(n)
            for i in range(0, n, self.batch_size):
                b = idx[i: i + self.batch_size]
                if len(b) < 2:
                    continue
                self.optimizer.zero_grad()
                pred = self.forward(X_t[b])
                loss = self.criterion(pred, y_t[b].view_as(pred))
                loss.backward()
                self.optimizer.step()
        return self

    def predict_proba(self, X):
        self.eval()
        with torch.no_grad():
            p1 = self.forward(torch.FloatTensor(X).to(self.device)).cpu().numpy()
        return np.vstack([1 - p1, p1]).T


# =============================================================================
# SlimGMF（修正版）
# =============================================================================

class SlimGMF(nn.Module):
    """
    修正版 GMF。
    变更：
      - hand_expander: 20 → 48 → hidden_dim（捕捉手工特征非线性交互）
      - gnn_proj:      64 → hidden_dim（等幅投影，不压缩）
      - gate:          向量级门控 Linear(hidden*2→hidden→hidden) + Sigmoid
      - hidden_dim 默认 64（与 GNN 输出对称）
    """
    def __init__(self, hand_dim=20, gnn_dim=64, hidden_dim=64, dropout=0.3):
        super().__init__()

        mid = max(hidden_dim // 2, 32)   # 中间层维度，至少 32

        # ── Hand 分支：两步升维，捕捉非线性交互 ──────────────────────────
        self.hand_expander = nn.Sequential(
            nn.Linear(hand_dim, mid),
            nn.LayerNorm(mid),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(mid, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
        )

        # ── GNN 分支：等幅投影，不压缩信息 ──────────────────────────────
        self.gnn_proj = nn.Linear(gnn_dim, hidden_dim)
        self.gnn_norm = nn.LayerNorm(hidden_dim)

        # ── 向量级门控（每个维度独立控制） ──────────────────────────────
        # 输出 hidden_dim 维，每维 ∈ (0,1)，允许细粒度融合
        self.gate = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.Sigmoid(),
        )

        # ── 分类头 ────────────────────────────────────────────────────────
        self.classifier = nn.Linear(hidden_dim, 1)
        self.dropout    = nn.Dropout(dropout)

    def forward(self, x_hand, x_gnn):
        # Hand：20 → mid → hidden_dim
        h = self.hand_expander(x_hand)                # (B, hidden_dim)

        # GNN：64 → hidden_dim
        g = F.relu(self.gnn_proj(x_gnn))
        g = self.gnn_norm(g)                          # (B, hidden_dim)

        # 向量门控：每维独立决定 Hand/GNN 权重
        alpha = self.gate(torch.cat([h, g], dim=-1))  # (B, hidden_dim)
        fused = alpha * h + (1 - alpha) * g           # (B, hidden_dim)
        fused = self.dropout(fused)

        logits = self.classifier(fused).squeeze(-1)
        prob   = torch.sigmoid(logits)

        gates_info = {
            'alpha_mean': alpha.mean().item(),
            'alpha_std':  alpha.std().item(),
        }
        return prob, (h, g), fused, gates_info

    def extract_purified_features(self, x_hand, x_gnn):
        """提取融合后特征（与 forward 保持一致）。"""
        h     = self.hand_expander(x_hand)
        g     = self.gnn_norm(F.relu(self.gnn_proj(x_gnn)))
        alpha = self.gate(torch.cat([h, g], dim=-1))
        return alpha * h + (1 - alpha) * g


# =============================================================================
# SlimGMF（标量门控版本）- 对比路线
# =============================================================================
class SlimGMF_ScalarGate(nn.Module):
    """
    SlimGMF 的标量门控版本。
    与 SlimGMF 的区别：
      - gate: 标量门控，输出单个标量值 ∈ (0,1)，所有维度共享
      - 用于验证标量门控 vs 向量门控的有效性
    """
    def __init__(self, hand_dim=20, gnn_dim=64, hidden_dim=64, dropout=0.3):
        super().__init__()

        mid = max(hidden_dim // 2, 32)   # 中间层维度，至少 32

        # ── Hand 分支：两步升维，捕捉非线性交互 ──────────────────────────
        self.hand_expander = nn.Sequential(
            nn.Linear(hand_dim, mid),
            nn.LayerNorm(mid),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(mid, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
        )

        # ── GNN 分支：等幅投影，不压缩信息 ──────────────────────────────
        self.gnn_proj = nn.Linear(gnn_dim, hidden_dim)
        self.gnn_norm = nn.LayerNorm(hidden_dim)

        # ── 标量门控（所有维度共享同一个权重） ─────────────────────────
        # 输出单个标量 ∈ (0,1)
        self.gate = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(hidden_dim // 2, 1),
            nn.Sigmoid(),
        )

        # ── 分类头 ────────────────────────────────────────────────────────
        self.classifier = nn.Linear(hidden_dim, 1)
        self.dropout    = nn.Dropout(dropout)

    def forward(self, x_hand, x_gnn):
        # Hand：20 → mid → hidden_dim
        h = self.hand_expander(x_hand)                # (B, hidden_dim)

        # GNN：64 → hidden_dim
        g = F.relu(self.gnn_proj(x_gnn))
        g = self.gnn_norm(g)                          # (B, hidden_dim)

        # 标量门控：所有维度使用同一个权重
        alpha_scalar = self.gate(torch.cat([h, g], dim=-1))  # (B, 1)
        alpha = alpha_scalar.expand_as(h)  # (B, hidden_dim)
        fused = alpha * h + (1 - alpha) * g           # (B, hidden_dim)
        fused = self.dropout(fused)

        logits = self.classifier(fused).squeeze(-1)
        prob   = torch.sigmoid(logits)

        gates_info = {
            'alpha_mean': alpha_scalar.mean().item(),
            'alpha_std':  alpha_scalar.std().item(),
        }
        return prob, (h, g), fused, gates_info

    def extract_purified_features(self, x_hand, x_gnn):
        """提取融合后特征（与 forward 保持一致）。"""
        h     = self.hand_expander(x_hand)
        g     = self.gnn_norm(F.relu(self.gnn_proj(x_gnn)))
        alpha_scalar = self.gate(torch.cat([h, g], dim=-1))
        alpha = alpha_scalar.expand_as(h)
        return alpha * h + (1 - alpha) * g


# 向后兼容别名
GatingMechanismFusion = SlimGMF


# =============================================================================
# SimComPlusPlus（修正版）
# =============================================================================

class SimComPlusPlus:
    """
    SimCom++ 完整实现。
    修正：
      1. 删除内部 Com MLP 冗余训练（始终使用外部 GNN 分支）
      2. GMF 早停使用真正独立验证集：在 MPOS 增强前从源域划出 15%
      3. extract_purified_features 解包 bug 修复
    """

    def __init__(self,
                 sim_params=None,
                 com_params=None,
                 gmf_hidden=64,           # ← 默认改为 64
                 gmf_dropout=0.3,
                 gmf_epochs=50,
                 gmf_lr=0.001,
                 gmf_batch_size=32,
                 early_stopping_patience=0,
                 use_mpos=True,
                 mpos_k=5,
                 mpos_ratio=1.0,
                 use_mpos_in_fusion=True,
                 use_mpos_in_gmf=False,
                 use_mpos_hand_only=False,
                 use_simple_fusion=False,
                 use_pos_weight_loss=False,
                 fixed_sim_weight=0.65,
                 fixed_gmf_weight=0.35,
                 fusion_strategy='post_rc',
                 use_center_in_gmf=False,
                 use_margin_in_gmf=False,
                 gmf_center_weight=0.02,
                 gmf_margin_weight=0.1,
                 gmf_margin=0.5,
                 use_scalar_gate=False,     # ← 新增：是否使用标量门控
                 device='cuda',
                 random_state=42):

        self.sim_params = sim_params or {
            'n_estimators': 500, 'max_depth': 20, 'min_samples_split': 5,
            'max_features': 'sqrt', 'class_weight': None,
            'n_jobs': -1, 'random_state': random_state
        }
        self.com_params = com_params or {
            'n_estimators': 500, 'max_depth': 20, 'min_samples_split': 5,
            'max_features': 'sqrt', 'class_weight': None,
            'n_jobs': -1, 'random_state': random_state
        }
        self.gmf_hidden              = gmf_hidden
        self.gmf_dropout             = gmf_dropout
        self.gmf_epochs              = gmf_epochs
        self.gmf_lr                  = gmf_lr
        self.gmf_batch_size          = gmf_batch_size
        self.early_stopping_patience = early_stopping_patience
        self.use_mpos                = use_mpos
        self.mpos_k                  = mpos_k
        self.mpos_ratio              = mpos_ratio
        self.use_mpos_in_fusion      = use_mpos_in_fusion
        self.use_mpos_in_gmf         = use_mpos_in_gmf
        self.use_mpos_hand_only      = use_mpos_hand_only
        self.use_simple_fusion       = use_simple_fusion
        self.use_pos_weight_loss    = use_pos_weight_loss
        self.fixed_sim_weight        = fixed_sim_weight
        self.fixed_gmf_weight        = fixed_gmf_weight
        self.fusion_strategy         = fusion_strategy
        self.use_center_in_gmf       = use_center_in_gmf
        self.use_margin_in_gmf       = use_margin_in_gmf
        self.gmf_center_weight       = gmf_center_weight
        self.gmf_margin_weight       = gmf_margin_weight
        self.gmf_margin              = gmf_margin
        self.use_scalar_gate        = use_scalar_gate    # ← 新增
        self.device                  = device if torch.cuda.is_available() else 'cpu'
        self.random_state            = random_state

        self.rf_sim          = None
        self.rf_com          = None
        self.gmf_model       = None
        self.meta_classifier = None

        from sklearn.preprocessing import StandardScaler
        self.meta_scaler     = StandardScaler()
        self.scaler_sim      = None
        self.scaler_com      = None
        self.scaler_gmf_hand = None
        self.scaler_gmf_gnn  = None

    # ------------------------------------------------------------------
    # MPOS 增强
    # ------------------------------------------------------------------

    def _apply_mpos(self, hand_features, gnn_features, labels):
        """联合增强 Hand + GNN 特征（在拼接空间上做 MPOS）。"""
        if not self.use_mpos:
            return hand_features, gnn_features, labels
        try:
            from mpos import MPOSAugmenter
            joint = np.hstack([hand_features, gnn_features])
            aug   = MPOSAugmenter(
                k_neighbors=self.mpos_k, target_ratio=self.mpos_ratio,
                random_state=self.random_state, scale_features=False, improved=True
            )
            joint_res, labels_res = aug.fit_resample(joint, labels)
            d = hand_features.shape[1]
            return joint_res[:, :d], joint_res[:, d:], labels_res
        except Exception as e:
            print(f"    MPOS failed: {e}")
            return hand_features, gnn_features, labels

    def _apply_mpos_hand_only(self, hand_features, gnn_features, labels):
        """只对 Hand 特征做 MPOS，GNN 特征采用对应邻居的原始特征。"""
        if not getattr(self, 'use_mpos_hand_only', False):
            return hand_features, gnn_features, labels
        try:
            from mpos import MPOSAugmenter
            from sklearn.neighbors import NearestNeighbors

            aug = MPOSAugmenter(
                k_neighbors=self.mpos_k, target_ratio=self.mpos_ratio,
                random_state=self.random_state, scale_features=True, improved=True
            )
            hand_res, labels_res = aug.fit_resample(hand_features, labels)

            n_original = len(labels)
            n_resampled = len(labels_res)
            if n_resampled > n_original:
                scaler = aug.scaler
                hand_scaled = scaler.transform(hand_features)
                hand_res_scaled = scaler.transform(hand_res[n_original:])

                nn = NearestNeighbors(n_neighbors=self.mpos_k, metric='euclidean')
                nn.fit(hand_scaled)
                distances, indices = nn.kneighbors(hand_res_scaled)

                gnn_res = np.zeros((n_resampled, gnn_features.shape[1]))
                gnn_res[:n_original] = gnn_features

                for i in range(n_original, n_resampled):
                    neighbor_indices = indices[i - n_original]
                    gnn_res[i] = gnn_features[neighbor_indices].mean(axis=0)

                return hand_res, gnn_res, labels_res
            else:
                return hand_res, gnn_features, labels_res
        except Exception as e:
            print(f"    MPOS Hand-only failed: {e}")
            return hand_features, gnn_features, labels

    # ------------------------------------------------------------------
    # 特征提取（供外部调用）
    # ------------------------------------------------------------------

    def extract_purified_features(self, hand_features, gnn_features):
        """提取 GMF 融合后的特征向量。"""
        self.gmf_model.eval()
        with torch.no_grad():
            h_t = torch.FloatTensor(hand_features).to(self.device)
            g_t = torch.FloatTensor(gnn_features).to(self.device)
            # ✓ 修复：第二个返回值才是 (h, g) 元组
            _, (feat_h, feat_g), _, _ = self.gmf_model(h_t, g_t)
            return torch.cat([feat_h, feat_g], dim=1).cpu().numpy()

    # ------------------------------------------------------------------
    # fit
    # ------------------------------------------------------------------

    def fit(self, train_hand, train_gnn, train_labels,
            target_hand=None, target_gnn=None, prob_gnn_val=None,
            test_proj="unknown"):  # 添加项目名称参数
        """
        训练 GMF 分支。
        外部 Hand 和 GNN 分支在 newtgnn.py 里独立训练后挂载，
        本方法只负责训练 SlimGMF 早期融合网络。
        """
        np.random.seed(self.random_state)
        torch.manual_seed(self.random_state)

        print("\n  [SimCom++] 开启 GMF 训练...")
        print("    [✓] Hand 分支（RF）将使用外部传入的概率，跳过内部训练。")
        print("    [✓] GNN  分支（MLP）将使用外部传入的概率，跳过内部训练。")

        # 初始化外部接口（newtgnn.py 在 fit 之后挂载）
        self.external_hand_prob_func = None
        self.external_hand_model     = None
        self.external_gnn_prob_func  = None
        self.external_gnn_model      = None

        # ── 修复：在 MPOS 之前先划分验证集 ─────────────────────────────
        # 验证集不做 MPOS 增强，保留真实分布，用于 GMF 早停
        if self.early_stopping_patience > 0:
            val_size = max(30, int(len(train_labels) * 0.15))
            try:
                tr_idx, val_idx = train_test_split(
                    range(len(train_labels)), test_size=val_size,
                    random_state=self.random_state, stratify=train_labels
                )
            except ValueError:
                # stratify 失败（极端不平衡）时退回随机划分
                tr_idx, val_idx = train_test_split(
                    range(len(train_labels)), test_size=val_size,
                    random_state=self.random_state
                )

            h_raw_tr  = train_hand[tr_idx];   g_raw_tr  = train_gnn[tr_idx]
            y_raw_tr  = train_labels[tr_idx]
            h_val     = train_hand[val_idx];   g_val     = train_gnn[val_idx]
            y_val     = train_labels[val_idx]

            print(f"    [GMF Split] 训练={len(y_raw_tr)} 验证={len(y_val)}")
        else:
            # 不使用验证集，全部数据用于训练
            h_raw_tr  = train_hand
            g_raw_tr  = train_gnn
            y_raw_tr  = train_labels
            h_val     = None
            g_val     = None
            y_val     = None
            print(f"    [GMF Split] 训练={len(y_raw_tr)} 验证=无（禁用早停）")

        # ── MPOS 只在训练子集上做 ────────────────────────────────────────
        if self.use_mpos and self.use_mpos_in_gmf:
            if self.use_mpos_hand_only:
                print("  [MPOS] 对 GMF 训练子集执行 Hand-only 增强...")
                h_tr, g_tr, y_tr = self._apply_mpos_hand_only(h_raw_tr, g_raw_tr, y_raw_tr)
                print(f"  [MPOS Hand-only] {len(y_raw_tr)} → {len(y_tr)} 样本")
            else:
                print("  [MPOS] 对 GMF 训练子集执行联合增强...")
                h_tr, g_tr, y_tr = self._apply_mpos(h_raw_tr, g_raw_tr, y_raw_tr)
                print(f"  [MPOS] {len(y_raw_tr)} → {len(y_tr)} 样本，比例 1:1")
        else:
            h_tr, g_tr, y_tr = h_raw_tr, g_raw_tr, y_raw_tr

        # ── 构建并训练 SlimGMF ───────────────────────────────────────────
        if self.use_scalar_gate:
            self.gmf_model = SlimGMF_ScalarGate(
                hand_dim=h_tr.shape[1],
                gnn_dim=g_tr.shape[1],
                hidden_dim=self.gmf_hidden,
                dropout=self.gmf_dropout,
            ).to(self.device)
        else:
            self.gmf_model = SlimGMF(
                hand_dim=h_tr.shape[1],
                gnn_dim=g_tr.shape[1],
                hidden_dim=self.gmf_hidden,
                dropout=self.gmf_dropout,
            ).to(self.device)

        self._train_gmf(
            h_tr, g_tr, y_tr,
            h_val, g_val, y_val,        # ← 真正独立的验证集
            target_hand, target_gnn,
            test_proj=test_proj          # 添加项目名称
        )
        
        # 保存 GMF 训练模型权重（仅向量门控版本保存）
        if not self.use_scalar_gate:
            import os
            gmf_model_cache_dir = "cache/model_weights"
            os.makedirs(gmf_model_cache_dir, exist_ok=True)
            gmf_model_cache_path = os.path.join(gmf_model_cache_dir, f"{test_proj}_gmf_model.pth")
            torch.save({
                'gmf_state_dict': self.gmf_model.state_dict(),
            }, gmf_model_cache_path)
            print(f"  [Cache] 保存 GMF 训练模型权重: {gmf_model_cache_path}")
        else:
            print(f"  [Cache] 标量门控版本不保存模型权重")
        
        print("    [✓] GMF 训练完成（独立验证集早停）。")
        print("  [SimCom++] 训练完成！\n")
        return self

    # ------------------------------------------------------------------
    # _train_gmf
    # ------------------------------------------------------------------

    def _train_gmf(self, X_h_tr, X_g_tr, y_tr,
                   X_h_val, X_g_val, y_val,
                   target_hand=None, target_gnn=None,
                   test_proj="unknown"):  # 添加项目名称参数
        """训练 SlimGMF，使用真正独立的验证集做早停。"""
        X_h_t = torch.FloatTensor(X_h_tr).to(self.device)
        X_g_t = torch.FloatTensor(X_g_tr).to(self.device)
        y_t   = torch.FloatTensor(y_tr).to(self.device)

        # 当 early_stopping_patience=0 时，验证集为 None
        if X_h_val is not None and X_g_val is not None and y_val is not None:
            X_h_v = torch.FloatTensor(X_h_val).to(self.device)
            X_g_v = torch.FloatTensor(X_g_val).to(self.device)
            y_v   = torch.FloatTensor(y_val).to(self.device)
            use_val = True
        else:
            X_h_v = X_g_v = y_v = None
            use_val = False

        X_h_target = X_g_target = None
        if target_hand is not None and target_gnn is not None:
            X_h_target = torch.FloatTensor(target_hand).to(self.device)
            X_g_target = torch.FloatTensor(target_gnn).to(self.device)
            print(f"  [CORAL] 启用目标域约束（目标样本数={len(target_hand)}）")

        optimizer = torch.optim.AdamW(
            self.gmf_model.parameters(), lr=self.gmf_lr, weight_decay=1e-3
        )
        pos_r = float(sum(y_tr) / max(len(y_tr), 1))
        if self.use_pos_weight_loss:
            pos_weight = torch.tensor((1.0 - pos_r) / max(pos_r, 1e-8), device=self.device)
            criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
            print(f"  [GMF] 使用 BCEWithLogitsLoss(pos_weight={pos_weight.item():.4f}), pos_ratio={pos_r:.4f}")
        else:
            criterion = FocalLoss(alpha=0.75, gamma=2)
            print(f"  [GMF] 使用 FocalLoss(alpha=0.75, gamma=2), pos_ratio={pos_r:.4f}")
        best_score  = -float('inf')
        patience_ctr = 0
        best_state  = None
        n = len(y_tr)

        for epoch in range(self.gmf_epochs):
            self.gmf_model.train()
            
            # 构建缓存路径
            import os
            shuffle_cache_dir = "cache/shuffle_history"
            os.makedirs(shuffle_cache_dir, exist_ok=True)
            shuffle_cache_path = os.path.join(shuffle_cache_dir, f"{test_proj}_gmf_shuffle_epoch{epoch}.npy")
            
            # 生成随机索引（使用 numpy 以便保存）
            import numpy as np
            
            if os.path.exists(shuffle_cache_path):
                # 加载已有的 shuffle 顺序
                indices = np.load(shuffle_cache_path)
                print(f"  [Cache] 加载 GMF Epoch {epoch} shuffle 顺序: {shuffle_cache_path}")
            else:
                # 生成新的 shuffle 顺序
                indices = np.random.permutation(n)
                np.save(shuffle_cache_path, indices)
                print(f"  [Cache] 保存 GMF Epoch {epoch} shuffle 顺序: {shuffle_cache_path}")
            
            # 转换为 PyTorch tensor
            indices = torch.from_numpy(indices).long()
            
            total_loss = 0.0
            nb = 0

            for i in range(0, n, self.gmf_batch_size):
                bi = indices[i: i + self.gmf_batch_size]
                if len(bi) < 2:
                    continue
                bh, bg, by = X_h_t[bi], X_g_t[bi], y_t[bi]
                smooth     = by.view(-1) * 0.8 + 0.1

                optimizer.zero_grad()
                prob, (h_proj, g_proj), fused, _ = self.gmf_model(bh, bg)

                cls_loss = criterion(prob, smooth)

                coral_c = torch.tensor(0.0, device=self.device)
                if X_h_target is not None:
                    _, _, fused_tgt, _ = self.gmf_model(X_h_target, X_g_target)
                    coral_c = coral_loss(fused, fused_tgt)

                center_val = torch.tensor(0.0, device=self.device)
                if self.use_center_in_gmf:
                    center_val = center_loss_binary(fused, by)

                margin_val = torch.tensor(0.0, device=self.device)
                if self.use_margin_in_gmf:
                    margin_val = center_margin_loss(fused, by, margin=self.gmf_margin)

                ortho_w   = 0.15 if epoch >= 10 else 0.0
                ortho_val = orthogonality_loss(h_proj, g_proj)

                loss = (cls_loss
                        + 0.1 * coral_c
                        + self.gmf_center_weight * center_val
                        + self.gmf_margin_weight * margin_val
                        + ortho_w * ortho_val)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.gmf_model.parameters(), 1.0)
                optimizer.step()
                total_loss += loss.item()
                nb += 1

            # ── 验证（独立验证集）────────────────────────────────────────
            if use_val:
                self.gmf_model.eval()
                with torch.no_grad():
                    val_prob, _, _, _ = self.gmf_model(X_h_v, X_g_v)
                    vp = val_prob.cpu().numpy()
                    yv = y_v.cpu().numpy()
                try:
                    val_auc = roc_auc_score(yv, vp)
                except ValueError:
                    val_auc = 0.5

                if val_auc > best_score:
                    best_score  = val_auc
                    best_state  = copy.deepcopy(self.gmf_model.state_dict())
                    patience_ctr = 0
                else:
                    patience_ctr += 1

                if patience_ctr >= self.early_stopping_patience:
                    print(f"    GMF 早停于 epoch {epoch + 1}（验证 AUC={best_score:.4f}）")
                    break
            else:
                # 无验证集时，每10轮打印训练损失
                if (epoch + 1) % 10 == 0:
                    print(f"    Epoch {epoch + 1}: Loss={total_loss/max(nb,1):.4f}")

        if use_val and best_state:
            self.gmf_model.load_state_dict(best_state)

    # ------------------------------------------------------------------
    # predict_proba
    # ------------------------------------------------------------------

    def predict_proba(self, test_hand, test_gnn,
                       prior_hand: float = 1.0,
                       prior_gnn:  float = 0.7,
                       prior_gmf:  float = 1.3,
                       tau_hard: float = 0.80,
                       tau_soft: float = 0.65,
                       T: float = 0.5):
        """
        自适应分支路由融合器。
        """
        from scipy.stats import rankdata

        def rank_norm(p, eps=1e-5):
            return np.clip(rankdata(p) / len(p), eps, 1 - eps)

        def H(p):
            p = np.clip(p, 1e-7, 1 - 1e-7)
            return -p * np.log2(p) - (1 - p) * np.log2(1 - p)

        raw_sim = (self.external_hand_prob_func(test_hand)
                   if getattr(self, 'external_hand_prob_func', None)
                   else np.full(len(test_hand), 0.5))

        raw_com = (self.external_gnn_prob_func(test_gnn)
                   if getattr(self, 'external_gnn_prob_func', None)
                   else np.full(len(test_gnn), 0.5))

        self.gmf_model.eval()
        with torch.no_grad():
            raw_gmf_t, _, _, gates_info = self.gmf_model(
                torch.FloatTensor(test_hand).to(self.device),
                torch.FloatTensor(test_gnn).to(self.device)
            )
        raw_gmf = raw_gmf_t.cpu().numpy()

        n_sim = rank_norm(raw_sim)
        n_com = rank_norm(raw_com)
        n_gmf = rank_norm(raw_gmf)

        h_sim = H(n_sim)
        h_com = H(n_com)
        h_gmf = H(n_gmf)

        H_sim_mean = h_sim.mean()
        H_com_mean = h_com.mean()
        H_gmf_mean = h_gmf.mean()

        H_sim_soft = H_sim_mean >= tau_soft
        H_sim_hard = H_sim_mean >= tau_hard
        H_com_soft = H_com_mean >= tau_soft
        H_com_hard = H_com_mean >= tau_hard
        H_gmf_soft = H_gmf_mean >= tau_soft
        H_gmf_hard = H_gmf_mean >= tau_hard

        W_sim = prior_hand * np.exp(-H_sim_mean / T)
        W_com = prior_gnn  * np.exp(-H_com_mean / T)
        W_gmf = prior_gmf  * np.exp(-H_gmf_mean / T)

        if H_sim_soft and not H_sim_hard:
            W_sim *= 0.5
        if H_com_soft and not H_com_hard:
            W_com *= 0.5
        if H_gmf_soft and not H_gmf_hard:
            W_gmf *= 0.5

        if H_sim_hard:
            W_sim = 0.0
        if H_com_hard:
            W_com = 0.0
        if H_gmf_hard:
            W_gmf = 0.0

        total_W = W_sim + W_com + W_gmf

        if total_W < 1e-10:
            H_mean_mat = np.stack([H_sim_mean, H_com_mean, H_gmf_mean])
            best = np.argmin(H_mean_mat)
            if best == 0:
                W_sim = 1.0; W_com = 0.0; W_gmf = 0.0
            elif best == 1:
                W_sim = 0.0; W_com = 1.0; W_gmf = 0.0
            else:
                W_sim = 0.0; W_com = 0.0; W_gmf = 1.0
            total_W = 1.0
            print(f"  [路由保底] 全部分支失效，退化为熵最低单分支")

        W_sim /= total_W;  W_com /= total_W;  W_gmf /= total_W

        final_prob = W_sim * n_sim + W_com * n_com + W_gmf * n_gmf

        gnn_active = (W_com > 1e-6) * 1.0
        print(f"  [SlimGMF] gate α={gates_info['alpha_mean']:.3f} "
              f"± {gates_info['alpha_std']:.3f}")
        print(f"  [目标域分支置信度] "
              f"Hand全局熵:{H_sim_mean:.3f}  "
              f"GNN全局熵:{H_com_mean:.3f}  "
              f"GMF全局熵:{H_gmf_mean:.3f}")
        print(f"  [路由] GNN参与:{'是' if W_com > 1e-6 else '否'}  "
              f"Weight: Hand={W_sim:.3f}  GNN={W_com:.3f}  GMF={W_gmf:.3f}")

        return final_prob, {
            'prob_sim':   raw_sim,
            'prob_com':   raw_com,
            'prob_gmf':   raw_gmf,
            'gates_info': gates_info,
            'gnn_active': gnn_active,
            'H_sim_mean': H_sim_mean,
            'H_com_mean': H_com_mean,
            'H_gmf_mean': H_gmf_mean,
            'W_sim': W_sim, 'W_com': W_com, 'W_gmf': W_gmf,
            'fusion_mode': 'AdaptiveRouter_GlobalEntropy',
        }

    def predict(self, test_hand, test_gnn, threshold=0.5):
        prob, _ = self.predict_proba(test_hand, test_gnn)
        return (prob > threshold).astype(int)

    # ------------------------------------------------------------------
    # SimCom++_Consistency: 方向一致性增强版
    # ------------------------------------------------------------------
    def predict_proba_consistency(self, test_hand, test_gnn,
                                  prior_hand: float = 1.0,
                                  prior_gnn:  float = 0.7,
                                  prior_gmf:  float = 1.3,
                                  tau_hard: float = 0.80,
                                  tau_soft: float = 0.65,
                                  T: float = 0.5):
        from scipy.stats import rankdata

        def rank_norm(p, eps=1e-5):
            return np.clip(rankdata(p) / len(p), eps, 1 - eps)

        def H(p):
            p = np.clip(p, 1e-7, 1 - 1e-7)
            return -p * np.log2(p) - (1 - p) * np.log2(1 - p)

        raw_sim = (self.external_hand_prob_func(test_hand)
                   if getattr(self, 'external_hand_prob_func', None)
                   else np.full(len(test_hand), 0.5))

        raw_com = (self.external_gnn_prob_func(test_gnn)
                   if getattr(self, 'external_gnn_prob_func', None)
                   else np.full(len(test_gnn), 0.5))

        self.gmf_model.eval()
        with torch.no_grad():
            raw_gmf_t, _, _, gates_info = self.gmf_model(
                torch.FloatTensor(test_hand).to(self.device),
                torch.FloatTensor(test_gnn).to(self.device)
            )
        raw_gmf = raw_gmf_t.cpu().numpy()

        n_sim = rank_norm(raw_sim)
        n_com = rank_norm(raw_com)
        n_gmf = rank_norm(raw_gmf)

        h_sim = H(n_sim)
        h_com = H(n_com)
        h_gmf = H(n_gmf)

        w_sim = prior_hand * np.exp(-h_sim / T)
        w_com = prior_gnn  * np.exp(-h_com / T)
        w_gmf = prior_gmf  * np.exp(-h_gmf / T)

        w_sim = np.where((h_sim >= tau_soft) & (h_sim < tau_hard), w_sim * 0.5, w_sim)
        w_com = np.where((h_com >= tau_soft) & (h_com < tau_hard), w_com * 0.5, w_com)
        w_gmf = np.where((h_gmf >= tau_soft) & (h_gmf < tau_hard), w_gmf * 0.5, w_gmf)

        w_sim = np.where(h_sim >= tau_hard, 0.0, w_sim)
        w_com = np.where(h_com >= tau_hard, 0.0, w_com)
        w_gmf = np.where(h_gmf >= tau_hard, 0.0, w_gmf)

        hand_dir = (n_sim > 0.5)
        gnn_dir  = (n_com > 0.5)
        gmf_dir  = (n_gmf > 0.5)

        gnn_isolated = (gnn_dir != hand_dir) & (gnn_dir != gmf_dir)
        hand_isolated = (hand_dir != gnn_dir) & (hand_dir != gmf_dir)

        w_com = np.where(gnn_isolated, w_com * 0.15, w_com)
        w_sim = np.where(hand_isolated, w_sim * 0.6, w_sim)

        total = w_sim + w_com + w_gmf

        all_zero = (total < 1e-10)
        if all_zero.any():
            n = all_zero.sum()
            hand_dir_az = (n_sim[all_zero] > 0.5)
            gmf_dir_az  = (n_gmf[all_zero] > 0.5)
            hand_gmf_agree = (hand_dir_az == gmf_dir_az)

            w_mat = np.zeros((n, 3))
            for i in range(n):
                if hand_gmf_agree[i]:
                    w_mat[i, 0] = 0.5
                    w_mat[i, 1] = 0.0
                    w_mat[i, 2] = 0.5
                else:
                    w_mat[i, 0] = 1.0
                    w_mat[i, 1] = 0.0
                    w_mat[i, 2] = 0.0

            w_sim[all_zero] = w_mat[:, 0]
            w_com[all_zero] = w_mat[:, 1]
            w_gmf[all_zero] = w_mat[:, 2]
            total = w_sim + w_com + w_gmf

            agree_count = hand_gmf_agree.sum()
            print(f"  [路由保底] {n} 个全失效实例："
                  f"{agree_count} 个退化为 Hand+GMF 双分支，"
                  f"{n - agree_count} 个退化为 Hand 单分支")

        w_sim /= total;  w_com /= total;  w_gmf /= total

        gnn_active = (w_com > 1e-6).mean()
        consistency_rate = (~gnn_isolated).mean()
        H_sim_mean = h_sim.mean()
        H_com_mean = h_com.mean()
        H_gmf_mean = h_gmf.mean()
        print(f"  [SlimGMF] gate α={gates_info['alpha_mean']:.3f} "
              f"± {gates_info['alpha_std']:.3f}")
        print(f"  [目标域分支置信度] "
              f"Hand均值熵:{H_sim_mean:.3f}  "
              f"GNN均值熵:{H_com_mean:.3f}  "
              f"GMF均值熵:{H_gmf_mean:.3f}")
        print(f"  [一致性路由] GNN参与率:{gnn_active:.1%}  "
              f"GNN一致性率:{consistency_rate:.1%}  "
              f"Hand均权:{w_sim.mean():.3f}  GNN均权:{w_com.mean():.3f}  "
              f"GMF均权:{w_gmf.mean():.3f}")

        final_prob = w_sim * n_sim + w_com * n_com + w_gmf * n_gmf

        return final_prob, {
            'prob_sim':   raw_sim,
            'prob_com':   raw_com,
            'prob_gmf':   raw_gmf,
            'gates_info': gates_info,
            'gnn_active': gnn_active,
            'gnn_consistency': consistency_rate,
            'H_sim_mean': H_sim_mean,
            'H_com_mean': H_com_mean,
            'H_gmf_mean': H_gmf_mean,
            'w_sim': w_sim, 'w_com': w_com, 'w_gmf': w_gmf,
            'fusion_mode': 'AdaptiveRouter_Consistency',
        }
