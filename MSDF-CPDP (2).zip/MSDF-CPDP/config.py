class OptimizedConfig:
    # ===== 路径 =====
    DATA_ROOT       = 'data/'
    PROJECTS_DIR    = 'projects/'
    CSV_DIR         = 'csvs/'
    PAIRS_FILE      = 'pairs-one.txt'
    RESULTS_DIR     = 'results/'

    # ===== LineDef 原始论文参数 =====
    LINE_DEF_TOKEN_DIM   = 50
    LINE_DEF_HIDDEN      = 128
    LINE_DEF_GCN_LAYERS  = 2
    LINE_DEF_TOKEN_WIN   = 2
    LINE_DEF_LINE_WIN    = 6

    # ===== 训练参数（论文值） =====
    EPOCHS          = 200  # 【放宽训练限制】确保像 poi-3.0 这样慢热的项目能彻底跑透
    BATCH_SIZE      = 64
    LEARNING_RATE   = 0.001
    WEIGHT_DECAY    = 0
    DROPOUT         = 0.2
    OPTIMIZER       = 'Adam'

    # ===== TCA 参数（保留） =====
    TCA_DIM   = 20
    TCA_LAMB  = 1.0
    TCA_GAMMA = 1.0

    # ===== MPOS 参数（保留） =====
    USE_MPOS            = True
    MPOS_K_NEIGHBORS    = 5
    MPOS_TARGET_RATIO   = 1.0

    # ===== DA 参数 (MMD + CORR) =====
    DA_LAMBDA     = 0.01  # 精细控制：在强大特征空间基础上实现精准对齐
    USE_DA        = True

    # ===== 实验设置 =====
    LOOP_SIZE     = 1
    RANDOM_SEED   = 42
    PACKAGE_HEADS = None # Unused but required by parse_source signature

class BaselineConfig:
    """
    Unified Configuration for Baseline Models (Deep & Traditional)
    """
    LOOP_SIZE       = 20
    
    # ===== Traditional Common (TCA, TCA+) =====
    TCA_KERNEL      = 'rbf'
    TCA_DIM         = 20
    TCA_LAMBDA      = 1.0
    TCA_GAMMA       = 1.0

    # ===== NNFilter / RF =====
    NN_K            = 10
    RF_N_ESTIMATORS = 100