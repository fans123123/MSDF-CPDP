# encoding=utf-8

import tool.javalang as jl
import os
import numpy as np
import pandas as pd
from typing import List, Dict, Tuple, Any
import warnings
import glob
import json
from tqdm import tqdm
import re

# 在文件开头添加拆分函数
def camel_case_split(identifier):
    """
    将 CamelCase 或 snake_case 拆分为单词列表
    例如: "DefaultExchangeFormatter" -> ['default', 'exchange', 'formatter']
    """
    # 匹配驼峰命名和下划线
    matches = re.finditer('.+?(?:(?<=[a-z])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])|(?<=[a-z])(?=[0-9])|(?<=[0-9])(?=[A-Z])|_|$)', identifier)
    return [m.group(0).replace('_', '').lower() for m in matches if m.group(0)]


warnings.filterwarnings('ignore')

# 手工特征列表（PROMISE仓库中的20个度量）
features = ['wmc', 'dit', 'noc', 'cbo', 'rfc', 'lcom', 'ca', 'ce', 'npm', 'lcom3', 'loc', 'dam', 'moa', 'mfa', 'cam',
            'ic', 'cbm', 'amc', 'max_cc', 'avg_cc']

# 类名映射 - 修复常见不匹配问题
CLASS_NAME_MAPPINGS = {
    # 常见Builder类映射
    "BinaryPredicateSupport": "org.apache.camel.builder.xml.BinaryPredicateSupport",
    "Builder": "org.apache.camel.builder.Builder",
    "BuilderSupport": "org.apache.camel.builder.BuilderSupport",
    
    # CSV中完整类名 -> 实际类名
    "org.apache.camel.builder.BinaryPredicateSupport": "org.apache.camel.builder.xml.BinaryPredicateSupport",
    "org.apache.camel.builder.NoErrorHandlerBuilder": "org.apache.camel.builder.NoErrorHandlerBuilder",
    "org.apache.camel.builder.ProcessorBuilder": "org.apache.camel.builder.ProcessorBuilder",
    "org.apache.camel.builder.ValueBuilder": "org.apache.camel.builder.ValueBuilder",
    "org.apache.camel.builder.DeadLetterChannelBuilder": "org.apache.camel.builder.DeadLetterChannelBuilder",
    "org.apache.camel.builder.ConstantProcessorBuilder": "org.apache.camel.builder.ConstantProcessorBuilder",
    "org.apache.camel.builder.CanceledProcessorBuilder": "org.apache.camel.builder.CanceledProcessorBuilder",
    
    # 其他常见映射
    "CanceledProcessorBuilder": "org.apache.camel.builder.CanceledProcessorBuilder",
}

def load_class_mappings(mapping_file=None):
    """
    加载类名映射
    可以从文件加载，也可以使用内置映射
    """
    mappings = CLASS_NAME_MAPPINGS.copy()
    
    if mapping_file and os.path.exists(mapping_file):
        try:
            with open(mapping_file, 'r', encoding='utf-8') as f:
                external_mappings = json.load(f)
                mappings.update(external_mappings)
                print(f"加载外部映射: {len(external_mappings)} 个")
        except Exception as e:
            print(f"加载映射文件失败: {e}")
    
    print(f"总映射数: {len(mappings)}")
    return mappings

def apply_class_mapping(class_names, mappings):
    """
    应用类名映射
    """
    if not mappings:
        return class_names
    
    mapped_names = []
    mapping_applied = 0
    
    for class_name in class_names:
        original_name = class_name
        
        # 检查是否需要映射
        if class_name in mappings:
            mapped_name = mappings[class_name]
            if mapped_name:
                class_name = mapped_name
                mapping_applied += 1
                print(f"  映射: {original_name} -> {class_name}")
        
        mapped_names.append(class_name)
    
    if mapping_applied > 0:
        print(f"应用了 {mapping_applied} 个类名映射")
    
    return mapped_names

def append_suffix(df: pd.DataFrame) -> pd.DataFrame:
    """
    为文件名添加.java后缀 - 智能列识别版
    """
    if 'file_name' in df.columns:
        return df

    best_col = None
    best_score = -float('inf')
    
    # 候选列：名字包含 name 或 file
    candidates = [col for col in df.columns if 'name' in col.lower() or 'file' in col.lower()]
    
    # 如果没有找到候选列，尝试所有object类型的列
    if not candidates:
        candidates = [col for col in df.columns if df[col].dtype == object]

    print(f"检测到候选文件名列: {candidates}")

    for col in candidates:
        try:
            score = 0
            series = df[col].dropna().astype(str)
            if series.empty:
                continue
                
            # 1. 检查是否有唯一值 (如果是项目名，通常唯一值很少)
            unique_ratio = series.nunique() / len(series) if len(series) > 0 else 0
            if unique_ratio > 0.1:  # 至少有10%的唯一值
                score += 5
            else:
                score -= 5 # 可能是项目名
            
            # 2. 检查是否以 .java 结尾
            if series.str.endswith('.java').mean() > 0.5:
                score += 20
            
            # 3. 检查是否像类路径 (包含点，且不含空格)
            if series.str.contains(r'\.').mean() > 0.5 and not series.str.contains(' ').any():
                score += 10
                
            print(f"列 '{col}' 得分: {score} (唯一率: {unique_ratio:.2f})")
            
            if score > best_score:
                best_score = score
                best_col = col
        except Exception as e:
            print(f"评估列 '{col}' 时出错: {e}")
            continue

    if best_col:
        print(f"选择最佳列 '{best_col}' 重命名为 'file_name'")
        # 如果列名重复，pandas会自动重命名为 name, name.1 等
        # 我们需要确保只重命名最佳的那一列
        df = df.rename(columns={best_col: 'file_name'})
    else:
        # 最后的保底：使用第一列
        if not df.empty:
            print(f"警告: 未找到合适的文件名列，强制使用第一列: {df.columns[0]}")
            df = df.rename(columns={df.columns[0]: 'file_name'})
    
    # 为没有.java后缀的文件名添加后缀
    if 'file_name' in df.columns:
        # 确保是字符串类型
        df['file_name'] = df['file_name'].astype(str)
        
        # 只对不以.java结尾的添加后缀
        # 注意：不要对NaN或空字符串添加
        mask = (~df['file_name'].str.endswith('.java')) & (df['file_name'] != 'nan') & (df['file_name'] != '')
        if mask.any():
            df.loc[mask, 'file_name'] = df.loc[mask, 'file_name'] + ".java"
    
    return df


def extract_handcraft_instances(csv_path):
    """
    从CSV提取文件列表
    """
    print(f"\n从CSV提取文件列表: {csv_path}")
    
    try:
        # 读取CSV文件
        df = pd.read_csv(csv_path)
        print(f"CSV形状: {df.shape}")
        print(f"列名: {list(df.columns)}")
        
        # 处理文件名列
        df = append_suffix(df)
        
        # 提取文件名列表
        file_list = []
        for filename in df['file_name']:
            if pd.isna(filename):
                continue
                
            filename = str(filename).strip()
            
            # 清理文件名
            if filename.startswith('"') and filename.endswith('"'):
                filename = filename[1:-1]
            
            # 标准化路径分隔符
            filename = filename.replace('\\', '/')
            
            file_list.append(filename)
        
        print(f"提取了 {len(file_list)} 个文件实例")
        
        if file_list:
            print("前10个文件:")
            for i, file_name in enumerate(file_list[:10]):
                print(f"  {i+1}. {file_name}")
        
        return file_list
        
    except Exception as e:
        print(f"提取文件列表失败 {csv_path}: {e}")
        import traceback
        traceback.print_exc()
        return []


import re

def preprocess_token(token: str) -> str:
    """
    Paper Section B: Data Preprocessing
    1. Remove special characters (., " ' ( ) : space !)
    2. Replace integers, real numbers, exponential notation, hex with <num>
    3. Replace constant strings with <str>
    """
    token = token.strip()
    
    # 1. Remove special characters mentioned in paper
    # The paper says: ., " ' ( ) : (space) !
    # But we are processing tokens from AST, which might already be separated.
    # If the token IS one of these characters, we should probably return None or empty string.
    # Or if the token CONTAINS these, we remove them.
    # Given the example: "factory=new ActiveMQConnectionFactory(getBrokerUrl());" -> "factory new ActiveMQConnectionFactory getBrokerUrl"
    # It seems we should filter out tokens that ARE these special characters, or strip them.
    
    # Check if token is a string literal (simplified check)
    if (token.startswith('"') and token.endswith('"')) or (token.startswith("'") and token.endswith("'")):
        return "<str>"
        
    # Check if token is a number
    # Integers, real numbers, exponential, hex
    # Regex for various number formats (including Java suffixes L, l, F, f, D, d)
    number_pattern = re.compile(r'^(-?\d+(\.\d+)?([eE][+-]?\d+)?[fFdDlL]?|0x[0-9a-fA-F]+)$')
    if number_pattern.match(token):
        return "<num>"
        
    # Remove special chars from the token itself
    # Based on user instruction: remove special characters like .,;(){}
    # And specifically "remove empty lines; remove special characters (like .,;(){} etc.);"
    
    # We define a set of characters to strip/remove
    # The instruction says "remove special characters (like .,;(){} etc.)"
    # This implies we should filter these out if they appear as tokens, OR strip them from tokens.
    # Usually in AST parsing, punctuation like ; { } are separate tokens if we parse lexical tokens.
    # But here we are extracting specific AST nodes (MethodInvocation, etc).
    # The node strings might contain some noise.
    
    # Updated list of chars to remove - kept only structural punctuation that carries no semantic meaning for defect prediction
    # Kept: ! (logic), [ ] (array), : (ternary/label) as they might be relevant
    # Removed: . , ; ( ) { } " '
    chars_to_remove = r'[.,;(){}\"\'\[\]]' 
    clean_token = re.sub(chars_to_remove, '', token)
    
    # Also remove single-character tokens that are just these symbols (if any remain)
    if clean_token in ['.', ',', ';', '(', ')', '{', '}', '"', "'", '[', ']']:
        return None

    # [Optimization] Filter out short variable names or noise (e.g. single letters unless they are common like 'i' in loops)
    # But for defect prediction, 'i', 'j' are important. 
    # Let's filter out only empty strings and perhaps very long noise.
    if not clean_token:
        return None
        
    return clean_token

def tokenize_source_lines(source_file_path: str) -> List[str]:
    try:
        with open(source_file_path, 'r', encoding='utf-8', errors='ignore') as file_obj:
            content = file_obj.read()
            tokens = list(jl.tokenizer.tokenize(content))
            line_tokens = {}
            
            for token in tokens:
                token_val = getattr(token, 'value', str(token))
                
                # [关键修复]：在这里进行驼峰拆分！
                if isinstance(token_val, str) and len(token_val) > 1:
                    sub_tokens = camel_case_split(token_val)
                else:
                    sub_tokens = [token_val.lower()]
                
                for sub_t in sub_tokens:
                    processed_token = preprocess_token(sub_t)
                    if processed_token:
                        if hasattr(token, 'position') and token.position:
                            line_no = token.position.line if hasattr(token.position, 'line') else token.position[0]
                        else:
                            line_no = 1
                            
                        if line_no not in line_tokens:
                            line_tokens[line_no] = []
                        line_tokens[line_no].append(processed_token)
            
            sorted_lines = sorted(line_tokens.keys())
            result = []
            for line_no in sorted_lines:
                tokens_in_line = line_tokens[line_no]
                if tokens_in_line:
                    result.append(" ".join(tokens_in_line))
            return result
    except Exception as e:
        print(f"解析文件 {source_file_path} 时出错: {e}")
        return []


def find_java_files_by_classname(project_root, class_names, package_heads=None, use_mapping=True):
    """
    在项目中根据类名查找Java文件 - 增强版本
    支持类名映射、智能匹配和大小写不敏感搜索
    """
    print(f"\n根据类名查找Java文件...")
    print(f"项目根目录: {project_root}")
    print(f"需要查找 {len(class_names)} 个类")
    
    # 应用类名映射
    if use_mapping:
        mappings = load_class_mappings()
        class_names = apply_class_mapping(class_names, mappings)
    
    # 首先找到所有的Java文件
    all_java_files = []
    
    # 搜索所有可能的Java文件
    for root, dirs, files in os.walk(project_root):
        # 跳过测试、构建等目录
        if any(skip in root.lower() for skip in ['test', 'target', '.git', 'build', '.idea']):
            continue
            
        for file in files:
            if file.endswith('.java'):
                full_path = os.path.join(root, file)
                all_java_files.append(full_path)
    
    print(f"在项目目录中找到 {len(all_java_files)} 个Java文件")
    
    if not all_java_files:
        print(f"未找到任何Java文件")
        return {}
    
    # 创建多种映射（包括大小写不敏感）
    simple_class_map = {}  # 简单类名 -> 文件路径列表
    simple_class_lower_map = {}  # 简单类名小写 -> 文件路径列表
    full_class_map = {}    # 完整类名（带包路径） -> 文件路径
    full_class_lower_map = {}  # 完整类名小写 -> 文件路径
    
    for java_file in all_java_files:
        try:
            # 获取简单类名（不带.java）
            filename = os.path.basename(java_file)
            simple_classname = filename[:-5]  # 去除.java
            simple_classname_lower = simple_classname.lower()
            
            # 构建完整类名
            # 读取Java文件获取包名
            package_name = ""
            with open(java_file, 'r', encoding='utf-8', errors='ignore') as f:
                for line in f:
                    line = line.strip()
                    if line.startswith('package '):
                        package_name = line[8:].replace(';', '').strip()
                        break
            
            # 构建完整类名
            if package_name:
                full_classname = f"{package_name}.{simple_classname}"
                full_classname_lower = full_classname.lower()
            else:
                full_classname = simple_classname
                full_classname_lower = simple_classname_lower
            
            # 添加到映射
            full_class_map[full_classname] = java_file
            full_class_lower_map[full_classname_lower] = java_file
            
            # 添加到简单类名映射（可能多个同名的类）
            if simple_classname not in simple_class_map:
                simple_class_map[simple_classname] = []
            simple_class_map[simple_classname].append(java_file)
            
            if simple_classname_lower not in simple_class_lower_map:
                simple_class_lower_map[simple_classname_lower] = []
            simple_class_lower_map[simple_classname_lower].append(java_file)
            
        except Exception as e:
            continue
    
    print(f"构建了 {len(simple_class_map)} 个简单类名映射")
    print(f"构建了 {len(full_class_map)} 个完整类名映射")
    
    # 查找目标类
    result = {}
    found_count = 0
    
    # Use simple loop instead of tqdm to avoid crashes
    print(f"\n查找并解析文件进度 (Simple Loop):")
    total_classes = len(class_names)
    for i, search_class_name in enumerate(class_names):
        if i % 100 == 0:
            print(f"  Processing {i}/{total_classes}...")
        found_file = None
        
        # print(f"\n查找类: {search_class_name}") # Removed for cleaner output with tqdm
        
        # 策略0: 大小写不敏感匹配完整类名
        search_class_lower = search_class_name.lower()
        if search_class_lower in full_class_lower_map:
            found_file = full_class_lower_map[search_class_lower]
            actual_class = next(k for k, v in full_class_map.items() if v == found_file)
            # print(f"  大小写不敏感匹配完整类名: {actual_class}")
            # print(f"  找到: {found_file}")
        
        # 策略1: 直接匹配完整类名（大小写敏感）
        if not found_file and search_class_name in full_class_map:
            found_file = full_class_map[search_class_name]
            # print(f"  通过完整类名找到: {found_file}")
        
        # 策略2: 如果完整类名不匹配，尝试提取简单类名
        if not found_file and '.' in search_class_name:
            # 提取简单类名（最后一个点之后的部分）
            simple_name = search_class_name.split('.')[-1]
            simple_name_lower = simple_name.lower()
            # print(f"  尝试简单类名: {simple_name}")
            
            # 先尝试大小写敏感
            if simple_name in simple_class_map:
                candidates = simple_class_map[simple_name]
            # 再尝试大小写不敏感
            elif simple_name_lower in simple_class_lower_map:
                candidates = simple_class_lower_map[simple_name_lower]
                print(f"  大小写不敏感匹配简单类名")
            else:
                candidates = []
            
            if candidates:
                if len(candidates) == 1:
                    # 只有一个候选，直接使用
                    found_file = candidates[0]
                    # print(f"  通过简单类名找到: {found_file}")
                else:
                    # 多个候选，尝试匹配包名
                    # print(f"  有 {len(candidates)} 个同名类候选")
                    
                    # 提取包名部分
                    target_package_parts = search_class_name.split('.')[:-1]
                    
                    # 排序候选：先尝试匹配度最高的
                    scored_candidates = []
                    for candidate in candidates:
                        # 获取候选文件的包名
                        candidate_package = ""
                        try:
                            with open(candidate, 'r', encoding='utf-8', errors='ignore') as f:
                                for line in f:
                                    line = line.strip()
                                    if line.startswith('package '):
                                        candidate_package = line[8:].replace(';', '').strip()
                                        break
                        except:
                            candidate_package = ""
                        
                        # 计算匹配分数
                        match_score = 0
                        if candidate_package:
                            candidate_parts = candidate_package.split('.')
                            
                            # 反向匹配（从后往前）
                            for i in range(1, min(len(target_package_parts), len(candidate_parts)) + 1):
                                if target_package_parts[-i].lower() == candidate_parts[-i].lower():
                                    match_score += 1
                                else:
                                    break
                        
                        scored_candidates.append((match_score, candidate, candidate_package))
                    
                    # 按分数排序
                    scored_candidates.sort(key=lambda x: x[0], reverse=True)
                    
                    # 选择最佳匹配
                    if scored_candidates and scored_candidates[0][0] > 0:
                        best_score, best_candidate, best_package = scored_candidates[0]
                        found_file = best_candidate
                        # print(f"  通过包名匹配找到 (匹配度: {best_score}): {found_file}")
                        # print(f"    目标包: {'.'.join(target_package_parts)}")
                        # print(f"    实际包: {best_package}")
                    else:
                        # 没有匹配的包名，选择第一个
                        found_file = candidates[0]
                        # print(f"  包名不匹配，使用第一个候选: {found_file}")
        
        # 策略3: 直接匹配简单类名（如果原始名称就是简单类名）
        if not found_file and '.' not in search_class_name:
            search_lower = search_class_name.lower()
            
            # 先尝试大小写敏感
            if search_class_name in simple_class_map:
                candidates = simple_class_map[search_class_name]
            # 再尝试大小写不敏感
            elif search_lower in simple_class_lower_map:
                candidates = simple_class_lower_map[search_lower]
                print(f"  大小写不敏感匹配")
            else:
                candidates = []
            
            if candidates:
                # 对于常见类名，优先选择在常见包中的
                if package_heads:
                    preferred_packages = package_heads
                else:
                    preferred_packages = [
                        'org.apache.camel.builder',
                        'org.apache.camel.builder.xml',
                        'org.apache.camel.impl',
                        'org.apache.camel'
                    ]
                
                preferred_candidate = None
                other_candidates = []
                
                for candidate in candidates:
                    candidate_package = ""
                    try:
                        with open(candidate, 'r', encoding='utf-8', errors='ignore') as f:
                            for line in f:
                                line = line.strip()
                                if line.startswith('package '):
                                    candidate_package = line[8:].replace(';', '').strip()
                                    break
                    except:
                        candidate_package = ""
                    
                    # 检查是否在优先包中
                    is_preferred = False
                    for pref_package in preferred_packages:
                        if candidate_package.startswith(pref_package):
                            is_preferred = True
                            break
                    
                    if is_preferred:
                        preferred_candidate = candidate
                        print(f"  找到优先包中的类: {candidate_package}")
                        break
                    else:
                        other_candidates.append(candidate)
                
                if preferred_candidate:
                    found_file = preferred_candidate
                elif other_candidates:
                    found_file = other_candidates[0]
                    # print(f"  没有优先包中的类，使用第一个候选")
        
        # 如果找到文件，提取Token
        if found_file:
            try:
                tokens_list = tokenize_source_lines(found_file)
                
                if tokens_list and len(tokens_list) > 0:
                    # 使用原始类名（CSV中的格式）作为key
                    csv_filename = search_class_name
                    if not csv_filename.endswith('.java'):
                        csv_filename = csv_filename + '.java'
                    
                    result[csv_filename] = tokens_list
                    found_count += 1
                    
                    # print(f"  Token提取成功: {len(tokens_list)} 行")
                else:
                    pass
                    # print(f"  Token提取失败或空文件")
                    
            except Exception as e:
                pass
                # print(f"  解析失败: {e}")
        else:
            pass
            # print(f"  未找到对应Java文件")
            
            # 显示可能的候选（大小写不敏感）
            if '.' in search_class_name:
                simple_name = search_class_name.split('.')[-1]
                simple_name_lower = simple_name.lower()
                
                if simple_name_lower in simple_class_lower_map:
                    candidates = simple_class_lower_map[simple_name_lower]
                    # print(f"  可能的同名文件 (大小写不敏感):")
                    for i, candidate in enumerate(candidates[:3]):
                        # 获取实际类名
                        for full_class, path in full_class_map.items():
                            if path == candidate:
                                # print(f"    候选{i+1}: {full_class}")
                                break
    
    print(f"\n查找结果:")
    print(f"  目标类数: {len(class_names)}")
    print(f"  找到文件: {found_count}")
    
    if found_count > 0:
        success_rate = found_count / len(class_names) * 100
        print(f"  成功率: {success_rate:.1f}%")
    
    # 显示一些统计信息
    if result:
        print(f"\nToken提取完成:")
        print(f"  成功提取: {len(result)} 个文件")
        
        # 显示前几个文件的Token信息
        print(f"\nToken序列示例（前3个文件）:")
        items = list(result.items())[:3]
        for i, (filename, tokens) in enumerate(items):
            print(f"  {i+1}. {filename}")
            print(f"    行数: {len(tokens)}")
            if tokens:
                print(f"    前2行: {tokens[:2]}")
    
    return result


def parse_source(project_root_path: str, handcraft_file_names: List[str], 
                 package_heads: List[str] = None, use_mapping: bool = True) -> Dict[str, List[str]]:
    """
    主解析函数 - 根据CSV中的类名在项目目录中查找Java文件
    增强版本：支持类名映射
    """
    print(f"\n{'='*60}")
    print(f"开始解析项目: {os.path.basename(project_root_path)}")
    print(f"使用类名映射: {'是' if use_mapping else '否'}")
    print(f"{'='*60}")
    
    # 从文件名中提取类名（去除.java后缀）
    class_names = []
    for filename in handcraft_file_names:
        if filename.endswith('.java'):
            class_names.append(filename[:-5])  # 去除.java后缀
        else:
            # 如果没有.java后缀，直接使用
            class_names.append(filename)
    
    print(f"需要查找 {len(class_names)} 个类")
    print(f"类名示例（前10个）: {class_names[:10]}")
    
    # 使用类名查找文件
    token_dict = find_java_files_by_classname(project_root_path, class_names, package_heads=package_heads, use_mapping=use_mapping)
    
    if not token_dict:
        print(f"未找到任何Java文件")
        return {}
    
    # 显示一些统计信息
    print(f"\nToken提取完成:")
    print(f"  成功提取: {len(token_dict)} 个文件")
    
    # 显示前几个文件的Token信息
    print(f"\nToken序列示例（前3个文件）:")
    items = list(token_dict.items())[:3]
    for i, (filename, tokens) in enumerate(items):
        print(f"  {i+1}. {filename}")
        print(f"    行数: {len(tokens)}")
        if tokens:
            print(f"    前2行: {tokens[:2]}")
    
    return token_dict


def padding_vector(vector: List[int], size: int) -> List[int]:
    """
    填充向量到指定长度
    """
    if len(vector) >= size:
        return vector[:size]
    
    padding = [0] * (size - len(vector))
    return vector + padding


def padding_all(dict_token: Dict[str, List[int]], size: int) -> Dict[str, List[int]]:
    """
    为所有向量填充到相同长度
    """
    result = {}
    for key, vector in dict_token.items():
        result[key] = padding_vector(vector, size)
    return result


def max_length(dict_list: List[Dict[str, List[int]]]) -> int:
    """
    计算所有向量中的最大长度
    """
    max_len = 0
    for d in dict_list:
        for vector in d.values():
            if len(vector) > max_len:
                max_len = len(vector)
    return max_len


def transform_token_to_number(list_dict_token: List[Dict[str, List[str]]]) -> Tuple[List[Dict[str, List[int]]], int, int]:
    """
    将token转换为数字序列
    """
    print("\n转换token到数字序列...")
    
    # 1. 统计token频率
    frequence = {}
    for dict_token in list_dict_token:
        for token_vector in dict_token.values():
            for token in token_vector:
                frequence[token] = frequence.get(token, 0) + 1
    
    print(f"总token种类: {len(frequence)}")
    
    # 2. 构建词汇表（过滤低频token）
    vocabulary = {}
    result = []
    count = 0
    
    # 保留频率≥2的token
    for token, freq in frequence.items():
        if freq >= 2:
            vocabulary[token] = count
            count += 1
    
    print(f"词汇表大小: {len(vocabulary)} (过滤低频token后)")
    
    # 显示一些词汇
    if vocabulary:
        print(f"词汇示例（前20个）:")
        vocab_items = list(vocabulary.items())[:20]
        for i, (token, idx) in enumerate(vocab_items):
            print(f"  {idx:4d}: {token}")
    
    # 3. 转换为数字序列
    max_len = 0
    for dict_token in list_dict_token:
        encoded_dict = {}
        for file_name, token_vector in dict_token.items():
            vector = []
            for token in token_vector:
                if token in vocabulary:
                    vector.append(vocabulary[token])
                else:
                    # 对于OOV（词表外）token，使用0表示
                    vector.append(0)
            
            if len(vector) > max_len:
                max_len = len(vector)
            
            encoded_dict[file_name] = vector
        
        result.append(encoded_dict)
    
    print(f"最大序列长度: {max_len}")
    
    # 4. 统一填充到最大长度
    for i in range(len(result)):
        result[i] = padding_all(result[i], max_len)
        print(f"数据集 {i}: {len(result[i])} 个文件")
    
    return result, max_len, len(vocabulary)


def extract_data(csv_path, token_dict, require_alignment=True):
    """
    对齐版本的extract_data：通过文件名确保Token特征和手工特征对齐
    
    参数:
        csv_path: 手工特征CSV文件路径
        token_dict: Token字典 {文件名: 行序列}
        require_alignment: 是否严格要求对齐
        
    返回:
        token_features, hand_features, labels (已经对齐)
    """
    print(f"对齐提取数据: {csv_path}")
    
    try:
        # 读取手工特征文件
        raw_handcraft = pd.read_csv(csv_path)
        print(f"CSV形状: {raw_handcraft.shape}")
        
        raw_handcraft = append_suffix(raw_handcraft)
        
        # 确保features存在
        features = ['wmc', 'dit', 'noc', 'cbo', 'rfc', 'lcom', 'ca', 'ce', 'npm', 'lcom3', 
                   'loc', 'dam', 'moa', 'mfa', 'cam', 'ic', 'cbm', 'amc', 'max_cc', 'avg_cc']
        available_features = [f for f in features if f in raw_handcraft.columns]
        
        print(f"可用特征: {len(available_features)}个")
        
        # 建立文件名到索引的映射
        csv_file_to_idx = {}
        for idx, filename in enumerate(raw_handcraft['file_name']):
            csv_file_to_idx[str(filename).strip()] = idx
        
        token_x_data = []
        hand_x_data = []
        label_data = []
        matched_filenames = []
        matched_count = 0
        
        print(f"开始匹配 {len(token_dict)} 个源文件...")
        
        for token_filename, token_vector in token_dict.items():
            # 标准化文件名
            token_file_simple = os.path.basename(str(token_filename)).strip()
            
            # 尝试在CSV中查找匹配
            matched = False
            
            # 策略1：精确匹配
            if token_file_simple in csv_file_to_idx:
                csv_idx = csv_file_to_idx[token_file_simple]
                matched = True
            
            # 策略2：模糊匹配（去除后缀）
            if not matched:
                token_no_suffix = token_file_simple.replace('.java', '')
                for csv_file, csv_idx in csv_file_to_idx.items():
                    csv_no_suffix = str(csv_file).replace('.java', '')
                    if token_no_suffix == csv_no_suffix:
                        matched = True
                        break
            
            # 策略3：包含关系
            if not matched and require_alignment:
                for csv_file, csv_idx in csv_file_to_idx.items():
                    if token_file_simple in str(csv_file) or str(csv_file) in token_file_simple:
                        matched = True
                        break
            
            if matched:
                # 提取Token特征
                token_x_data.append(token_vector)
                
                # 提取手工特征
                csv_idx_val = csv_idx if 'csv_idx' in locals() else list(csv_file_to_idx.values())[0]
                row = raw_handcraft.iloc[csv_idx_val]
                
                hand_features = row[available_features].values.tolist()
                hand_x_data.append(hand_features)
                
                # 提取标签
                if 'bug' in raw_handcraft.columns:
                    label = row['bug']
                    label = 1 if label > 0 else 0
                elif 'defect' in raw_handcraft.columns:
                    label = row['defect']
                    label = 1 if label > 0 else 0
                else:
                    label = 0
                
                label_data.append([label])
                matched_filenames.append(token_filename)
                matched_count += 1
                
                if matched_count <= 5:
                    print(f"  匹配: {token_file_simple}")
            else:
                if require_alignment:
                    print(f"  未找到匹配: {token_file_simple}")
                # 如果不需要严格对齐，可以跳过或使用默认值
        
        # 转换为numpy数组
        if matched_count > 0:
            # token_x_data 是变长文本序列，不能转为float32数组
            # 保持为 Python list 或 object array
            # token_x_data = np.array(token_x_data, dtype=np.float32)
            
            hand_x_data = np.array(hand_x_data, dtype=np.float32)
            label_data = np.array(label_data, dtype=np.float32)
            
            print(f"\n对齐提取完成:")
            print(f"  匹配文件数: {matched_count}/{len(token_dict)}")
            print(f"  Token特征(文件数): {len(token_x_data)}")
            print(f"  手工特征: {hand_x_data.shape}")
            print(f"  标签: {label_data.shape}")
            
            # 统计标签分布
            unique, counts = np.unique(label_data, return_counts=True)
            print(f"  标签分布: {dict(zip(unique, counts))}")
            
            return token_x_data, hand_x_data, label_data, matched_filenames
        else:
            print("没有匹配的文件")
            return np.array([]), np.array([]), np.array([]), []
        
    except Exception as e:
        print(f"对齐提取失败: {e}")
        import traceback
        traceback.print_exc()
        return np.array([]), np.array([]), np.array([]), []

def imbalance_process(train_tokens: np.ndarray, train_hand_craft: np.ndarray, 
                      train_label: np.ndarray, processor=None) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    处理类别不平衡
    """
    if processor is None:
        return train_tokens, train_hand_craft, train_label
    
    try:
        # 统计原始分布
        unique, counts = np.unique(train_label, return_counts=True)
        print(f"原始类别分布: {dict(zip(unique, counts))}")
        
        # 重塑标签为1D
        train_label_1d = train_label.ravel()
        
        # 合并特征进行重采样
        if train_tokens.shape[0] == train_hand_craft.shape[0]:
            combined_features = np.concatenate([train_tokens, train_hand_craft], axis=1)
            
            # 应用重采样
            X_resampled, y_resampled = processor.fit_resample(combined_features, train_label_1d)
            
            # 分离特征
            token_dim = train_tokens.shape[1]
            train_tokens_resampled = X_resampled[:, :token_dim]
            train_hand_resampled = X_resampled[:, token_dim:]
            train_label_resampled = y_resampled.reshape(-1, 1)
            
            # 统计新分布
            unique_new, counts_new = np.unique(train_label_resampled, return_counts=True)
            print(f"重采样后分布: {dict(zip(unique_new, counts_new))}")
            
            return train_tokens_resampled, train_hand_resampled, train_label_resampled
        else:
            print("警告: Token和手工特征数量不匹配，跳过不平衡处理")
            return train_tokens, train_hand_craft, train_label
            
    except Exception as e:
        print(f"不平衡处理出错: {e}")
        return train_tokens, train_hand_craft, train_label


# 测试函数
def test_class_mapping():
    """
    测试类名映射功能
    """
    print("\n测试类名映射功能...")
    
    test_cases = [
        "BinaryPredicateSupport",
        "Builder",
        "BuilderSupport",
        "CanceledProcessorBuilder",
        "org.apache.camel.builder.BinaryPredicateSupport",
        "org.apache.camel.builder.Builder",
        "org.apache.camel.builder.xml.BinaryPredicateSupport",
        "org.apache.camel.impl.DefaultExchangeFormatter"  # 不应该被映射
    ]
    
    mappings = load_class_mappings()
    mapped = apply_class_mapping(test_cases, mappings)
    
    print("\n映射测试结果:")
    for original, mapped_name in zip(test_cases, mapped):
        if original != mapped_name:
            print(f"  {original} -> {mapped_name}")
        else:
            print(f"  {original} (无变化)")

def test_find_java_files():
    """
    测试查找Java文件功能
    """
    print("\n测试查找Java文件功能...")
    
    # 测试数据
    project_root = "data/projects/camel-1.6"
    test_class_names = [
        "BinaryPredicateSupport",
        "Builder",
        "BuilderSupport",
        "org.apache.camel.builder.BinaryPredicateSupport",
        "org.apache.camel.impl.DefaultExchangeFormatter",
        "CanceledProcessorBuilder"  # 这个可能不存在
    ]
    
    if not os.path.exists(project_root):
        print(f"项目目录不存在: {project_root}")
        return
    
    print("测试带映射的查找...")
    result = find_java_files_by_classname(project_root, test_class_names, use_mapping=True)
    
    print(f"\n测试结果:")
    print(f"  找到 {len(result)} 个文件:")
    for filename, tokens in result.items():
        print(f"  - {filename}: {len(tokens)} tokens")
    
    return result


if __name__ == "__main__":
    print("测试ParsingSource模块...")
    
    # 测试所有函数存在性
    funcs = ['extract_handcraft_instances', 'parse_source', 'transform_token_to_number', 
             'extract_data', 'append_suffix',
             'find_java_files_by_classname', 'load_class_mappings', 'apply_class_mapping']
    
    all_exist = True
    for func in funcs:
        if func in globals():
            print(f"{func} 存在")
        else:
            print(f"{func} 不存在")
            all_exist = False
    
    if all_exist:
        print("\n所有函数测试通过")
        
        # 运行具体测试
        test_class_mapping()
        test_find_java_files()
    else:
        print("\n部分函数缺失，请检查代码")
# [file content end]