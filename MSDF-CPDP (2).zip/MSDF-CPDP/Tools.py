# [file name]: Tools.py
# [file content begin]
"""
工具函数集合 - 修复版
添加数据对齐辅助函数
"""
import os
import pickle
import numpy as np
import torch


def create_directory_if_not_exists(path):
    """创建目录（如果不存在） - 保持不变"""
    if not os.path.exists(path):
        os.makedirs(path)
        print(f"创建目录: {path}")
    return path


def dump_data(path, obj):
    """保存数据到文件 - 保持不变"""
    with open(path, 'wb') as f:
        pickle.dump(obj, f)
    return True


def load_data(path):
    """从文件加载数据 - 保持不变"""
    with open(path, 'rb') as f:
        obj = pickle.load(f)
    return obj


def save_model(model, path):
    """保存模型 - 保持不变"""
    torch.save(model.state_dict(), path)
    print(f"模型已保存: {path}")


def load_model(model, path, device='cpu'):
    """加载模型 - 保持不变"""
    if os.path.exists(path):
        model.load_state_dict(torch.load(path, map_location=device))
        model.eval()
        print(f"模型已加载: {path}")
        return True
    else:
        print(f"模型文件不存在: {path}")
        return False


def calculate_class_weights(labels):
    """计算类别权重 - 保持不变"""
    labels = np.array(labels).flatten()
    unique, counts = np.unique(labels, return_counts=True)
    
    if len(unique) == 2:
        weight_positive = counts[0] / counts[1] if counts[1] > 0 else 1.0
        return torch.tensor([weight_positive])
    else:
        return torch.tensor([1.0])


def normalize_features(features, method='standard'):
    """特征标准化 - 保持不变"""
    if method == 'standard':
        mean = features.mean(axis=0, keepdims=True)
        std = features.std(axis=0, keepdims=True)
        std[std == 0] = 1.0
        return (features - mean) / std
    elif method == 'minmax':
        min_val = features.min(axis=0, keepdims=True)
        max_val = features.max(axis=0, keepdims=True)
        range_val = max_val - min_val
        range_val[range_val == 0] = 1.0
        return (features - min_val) / range_val
    else:
        return features


def setup_random_seed(seed=42):
    """设置随机种子 - 保持不变"""
    import random
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    print(f"设置随机种子: {seed}")

# 新增：数据对齐辅助函数

def align_features_by_samples(features_list, strategy='min'):
    """
    通过样本数对齐多个特征数组
    strategy: 
        'min' - 取最小样本数（截断）
        'max' - 取最大样本数（填充）
        'first' - 以第一个特征数组为基准
    """
    if not features_list:
        return features_list
    
    # 移除None值
    valid_features = [f for f in features_list if f is not None]
    if not valid_features:
        return features_list
    
    # 确定目标样本数
    if strategy == 'min':
        target_size = min(len(f) for f in valid_features)
    elif strategy == 'max':
        target_size = max(len(f) for f in valid_features)
    elif strategy == 'first':
        target_size = len(valid_features[0])
    else:
        target_size = len(valid_features[0])
    
    aligned_features = []
    for features in features_list:
        if features is None:
            aligned_features.append(None)
        elif len(features) == target_size:
            aligned_features.append(features)
        elif len(features) > target_size:
            # 截断
            aligned_features.append(features[:target_size])
        else:
            # 填充（使用均值）
            padding_shape = list(features.shape)
            padding_shape[0] = target_size - len(features)
            
            if len(features) > 0:
                padding = np.zeros(padding_shape)
                padding[:] = features.mean(axis=0)
                aligned_features.append(np.vstack([features, padding]))
            else:
                # 如果原始特征为空，填充零
                aligned_features.append(np.zeros((target_size, features.shape[1] if len(features.shape) > 1 else 1)))
    
    return aligned_features


def check_data_alignment(*data_arrays):
    """
    检查多个数据数组是否对齐（样本数相同）
    返回: (是否对齐, 公共样本数, 各数组样本数)
    """
    lengths = []
    for data in data_arrays:
        if data is not None:
            if hasattr(data, '__len__'):
                lengths.append(len(data))
            else:
                lengths.append(0)
    
    if not lengths:
        return True, 0, []
    
    aligned = len(set(lengths)) <= 1
    common_length = min(lengths) if lengths else 0
    
    return aligned, common_length, lengths


def concatenate_features_safely(feature_arrays):
    """
    安全地拼接多个特征数组
    自动对齐样本数，然后沿特征维度拼接
    """
    if not feature_arrays:
        return None
    
    # 对齐样本数
    aligned_features = align_features_by_samples(feature_arrays, strategy='min')
    
    # 移除None值
    valid_features = [f for f in aligned_features if f is not None]
    if not valid_features:
        return None
    
    # 确保都是2D数组
    valid_features_2d = []
    for f in valid_features:
        if len(f.shape) == 1:
            valid_features_2d.append(f.reshape(-1, 1))
        else:
            valid_features_2d.append(f)
    
    # 拼接
    try:
        concatenated = np.concatenate(valid_features_2d, axis=1)
        return concatenated
    except Exception as e:
        print(f"特征拼接失败: {e}")
        return valid_features_2d[0] if valid_features_2d else None
# [file content end]