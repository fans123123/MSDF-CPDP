"""
newtgnn.py  —— SimCom++ 完整训练流程
GNN 分支: CodeBERT → AST 结构图(tree-sitter), 追求跨项目结构迁移性
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import os
import pandas as pd
import pickle
import warnings
import time
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Ellipse
from scipy.stats import binomtest, wilcoxon
from sklearn.metrics import roc_auc_score, balanced_accuracy_score, matthews_corrcoef, f1_score, average_precision_score
from sklearn.preprocessing import QuantileTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics.pairwise import rbf_kernel
from scipy.stats import rankdata

from torch_geometric.data import Batch
from collections import Counter

from ParsingSource import extract_handcraft_instances, parse_source, extract_data, append_suffix
from Tools import setup_random_seed
from device_utils import get_device
from config import OptimizedConfig as Config

# ---- 新版 GNN 接口(AST 结构图)----
from models.line_def import (
    ASTGraphBuilder,
    LineDefGCNAtt,
    VOCAB_SIZE,
    EMBED_DIM,
    STRUCT_DIM,
    NODE_FEAT_DIM,
)

# 导入 SimCom++
from gmf_simcom import SimComPlusPlus, MLPClassifierWrapper

# 导入 MPOS
try:
    from mpos import MPOSAugmenter
    USE_MPOS = True
except ImportError:
    print("[Warning] MPOS module not found.")
    USE_MPOS = False

warnings.filterwarnings('ignore')
DEVICE = get_device()
setup_random_seed(Config.RANDOM_SEED)


# ================================================================
# MASTER 多源加权数据选择 - 辅助函数
# ================================================================

def compute_mmd(X, Y, gamma=0.01):
    """
    计算两个样本集之间的 MMD 距离（使用 RBF 核）
    返回值越小，表示两个分布越相似
    """
    X = np.asarray(X)
    Y = np.asarray(Y)
    n = X.shape[0]
    m = Y.shape[0]
    XY = np.vstack([X, Y])
    K = rbf_kernel(XY, gamma=gamma)
    K_XX = K[:n, :n]
    K_YY = K[n:, n:]
    K_XY = K[:n, n:]
    mmd = K_XX.mean() + K_YY.mean() - 2 * K_XY.mean()
    return max(0, mmd)


def compute_kmm_weight(src_hand, tgt_hand, gamma=0.01, epsilon=1e-2):
    """
    使用 KMM (Kernel Mean Matching) 计算源项目每个样本的权重
    返回权重数组，平均值约为 1
    """
    try:
        from cvxopt import matrix, solvers
    except ImportError:
        print("[Warning] cvxopt not installed, using simplified weights")
        return np.ones(src_hand.shape[0])
    
    n_src = src_hand.shape[0]
    n_tgt = tgt_hand.shape[0]
    
    # 计算核矩阵
    X_all = np.vstack([src_hand, tgt_hand])
    K = rbf_kernel(X_all, gamma=gamma)
    K_ss = K[:n_src, :n_src]
    K_st = K[:n_src, n_src:]
    
    # 目标：最小化 || (1/n_src) * K_ss * beta - (1/n_tgt) * K_st * 1 ||^2
    # 约束：0 <= beta <= 1, 且 beta 的和 = n_src
    # 使用 CVXOPT 求解二次规划
    
    # 简化版 KMM：使用源-目标核矩阵的平均相似度作为权重
    # 避免复杂的二次规划，直接计算每个源样本与目标分布的相似度
    kappa = np.mean(K_st, axis=1)  # 每个源样本与目标分布的核相似度
    kappa = kappa / kappa.mean()  # 归一化
    
    # 加权：与目标更相似的源样本获得更高权重
    beta = kappa + epsilon
    beta = beta / beta.mean()  # 使平均值为 1
    
    return beta


def compute_source_weight_master(src_hand, src_label, tgt_hand, method='mmd', use_kmm=False):
    """
    计算源项目的综合权重（MASTER 风格）
    """
    # 1. 分布差异度量（MMD，越小越相似，转为相似度）
    mmd_dist = compute_mmd(src_hand, tgt_hand)
    similarity = 1 / (1 + mmd_dist)  # MMD 距离越小，相似度越高
    
    # 2. 源项目自身质量：若 use_kmm=True，则用 KMM 权重的均值表示可迁移性
    if use_kmm:
        weights = compute_kmm_weight(src_hand, tgt_hand)
        self_quality = np.mean(weights)  # KMM 权重平均值，越大表示源与目标越匹配
    else:
        # 简化版：随机森林特征重要性均值
        rf = RandomForestClassifier(n_estimators=100, random_state=42)
        rf.fit(src_hand, src_label)
        self_quality = np.mean(rf.feature_importances_)
    
    # 综合权重
    weight = similarity * self_quality
    return weight


def multi_source_weighted_sampling(source_data_list, target_hand, top_k=2, use_kmm=False):
    """
    多源加权采样：从候选源项目中选择 Top-K，并根据 MMD 权重合并数据
    
    参数:
        source_data_list: 包含多个源项目数据的列表，每个元素为 (proj_name, data_dict)
        target_hand: 目标项目的 Hand 特征（用于计算 MMD）
        top_k: 选择前 K 个最相似的源项目
        use_kmm: 是否使用 KMM 计算样本级别权重
    
    返回:
        merged_hand: 合并后的 Hand 特征
        merged_labels: 合并后的标签
        sample_weights: 每个样本的权重（用于加权训练）
        selected_projects: 被选中的项目列表
        project_weights: 每个项目的权重
    """
    # 计算每个源项目与目标项目的综合权重
    project_weights = {}
    for proj_name, data in source_data_list:
        src_hand = data['hand']
        src_label = data['label_original']
        
        weight = compute_source_weight_master(src_hand, src_label, target_hand, use_kmm=use_kmm)
        project_weights[proj_name] = weight
    
    # 按权重排序，选择 Top-K
    sorted_projects = sorted(project_weights.items(), key=lambda x: x[1], reverse=True)
    selected_projects = sorted_projects[:top_k]
    
    print(f"\n  [MASTER] Top-{top_k} 源项目选择:")
    for proj, w in selected_projects:
        print(f"    - {proj}: weight={w:.4f}")
    
    # 归一化项目权重（使和为 1）
    total_weight = sum(w for _, w in selected_projects)
    normalized_weights = {proj: w / total_weight for proj, w in selected_projects}
    
    # 按权重合并数据
    merged_hand_list = []
    merged_labels_list = []
    merged_weights_list = []  # 存储每个样本的权重
    
    for proj_name, proj_weight in selected_projects:
        data = all_project_data[proj_name]
        src_hand = data['hand']
        src_label = data['label_original']
        
        # 项目级别权重
        proj_normalized_weight = normalized_weights[proj_name]
        
        # 计算 KMM 样本级别权重（如果启用）
        if use_kmm:
            sample_weights = compute_kmm_weight(src_hand, target_hand)
        else:
            # 使用均匀权重
            sample_weights = np.ones(src_hand.shape[0])
        
        # 综合权重 = 项目权重 × 样本权重
        combined_weights = proj_normalized_weight * sample_weights
        
        merged_hand_list.append(src_hand)
        merged_labels_list.append(src_label)
        merged_weights_list.append(combined_weights)
    
    # 合并所有数据
    merged_hand = np.vstack(merged_hand_list)
    merged_labels = np.concatenate(merged_labels_list)
    merged_weights = np.concatenate(merged_weights_list)
    
    # 归一化样本权重（使平均为 1）
    merged_weights = merged_weights / merged_weights.mean()
    
    return merged_hand, merged_labels, merged_weights, selected_projects, normalized_weights


def rank_normalize(probs, epsilon=1e-5):
    """
    将异构模型的原始概率转换0~1 之间的均匀百分位排(Rank Normalization)

    参数:
        probs: 模型输出的原始概率数(一numpy array)
        epsilon: 微小偏移量, 防止输出绝对0 1(这对后续计算交叉熵或对数极其重要)
    返回:
        归一化后的概率数
    """
    norm_probs = rankdata(probs) / len(probs)
    norm_probs = np.clip(norm_probs, epsilon, 1.0 - epsilon)
    return norm_probs


# ============================================================================
# DA 损失
# ============================================================================

def mmd_loss(source, target, kernel_mul=2.0, kernel_num=5, fix_sigma=None):
    """MMD 损失(用于GNN 预训练域对齐)"""
    n_samples = int(source.size(0)) + int(target.size(0))
    total = torch.cat([source, target], dim=0)
    total0 = total.unsqueeze(0).expand(total.size(0), total.size(0), total.size(1))
    total1 = total.unsqueeze(1).expand(total.size(0), total.size(0), total.size(1))
    L2 = ((total0 - total1) ** 2).sum(2)

    bw = fix_sigma if fix_sigma else torch.sum(L2.data) / (n_samples ** 2 - n_samples)
    bw /= kernel_mul ** (kernel_num // 2)
    bw_list = [bw * (kernel_mul ** i) for i in range(kernel_num)]
    kernels = sum(torch.exp(-L2 / b) for b in bw_list)

    m = source.size(0)
    XX = kernels[:m, :m]
    YY = kernels[m:, m:]
    XY = kernels[:m, m:]
    YX = kernels[m:, :m]
    return torch.mean(XX) + torch.mean(YY) - torch.mean(XY) - torch.mean(YX)


def coral_loss(source, target):
    """CORAL 损失"""
    d = source.size(1)
    xm  = torch.mean(source, 0, keepdim=True) - source
    xc  = xm.t() @ xm / (source.size(0) - 1)
    xmt = torch.mean(target, 0, keepdim=True) - target
    xct = xmt.t() @ xmt / (target.size(0) - 1)
    return torch.sum((xc - xct) ** 2) / (4 * d * d)


def center_loss_binary(features: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
    """
    二分类 center loss:
      - 正类向正类中心收缩
      - 负类向负类中心收缩

    Args:
        features: (B, D)
        labels:   (B, 1) or (B,)
    """
    if labels.dim() > 1:
        labels = labels.view(-1)

    pos_mask = labels > 0.5
    neg_mask = labels <= 0.5

    loss = torch.tensor(0.0, device=features.device)
    terms = 0

    if pos_mask.sum() >= 2:
        pos_feats = features[pos_mask]
        pos_center = pos_feats.mean(dim=0, keepdim=True)
        loss = loss + F.mse_loss(
            pos_feats,
            pos_center.expand_as(pos_feats)
        )
        terms += 1

    if neg_mask.sum() >= 2:
        neg_feats = features[neg_mask]
        neg_center = neg_feats.mean(dim=0, keepdim=True)
        loss = loss + F.mse_loss(
            neg_feats,
            neg_center.expand_as(neg_feats)
        )
        terms += 1

    if terms == 0:
        return torch.tensor(0.0, device=features.device)

    return loss / terms


def center_margin_loss(features: torch.Tensor, labels: torch.Tensor, margin: float = 1.0) -> torch.Tensor:
    """
    二分类 margin loss:
      - 最大化正负类中心的欧氏距离
      - 当距离小于 margin 时产生损失

    Args:
        features: (B, D)
        labels:   (B, 1) or (B,)
        margin:   间隔阈值
    """
    if labels.dim() > 1:
        labels = labels.view(-1)

    pos_mask = labels > 0.5
    neg_mask = labels <= 0.5

    if pos_mask.sum() < 1 or neg_mask.sum() < 1:
        return torch.tensor(0.0, device=features.device)

    pos_center = features[pos_mask].mean(dim=0)
    neg_center = features[neg_mask].mean(dim=0)
    dist = torch.norm(pos_center - neg_center, p=2)
    return F.relu(torch.tensor(margin, device=features.device) - dist)


# ============================================================================
# 评估
# ============================================================================

def extract_loc_from_csv(csv_path, fnames):
    """从CSV文件中提取LOC信息, 与文件名对齐

    参数:
        csv_path: CSV文件路径
        fnames: 文件名列表(与预测顺序一致)
    返回:
        loc_array: 与fnames对应的LOC数组
    """
    try:
        df = pd.read_csv(csv_path)
        df = append_suffix(df)

        if 'loc' not in df.columns:
            print(f"  [Warning] CSV中没有loc列: {csv_path}")
            return None

        csv_file_to_loc = {}
        for idx, row in df.iterrows():
            filename = str(row.get('file_name', '')).strip()
            if filename:
                csv_file_to_loc[filename] = row['loc']
                csv_file_to_loc[os.path.basename(filename)] = row['loc']
                csv_file_to_loc[filename.replace('.java', '')] = row['loc']
                csv_file_to_loc[os.path.basename(filename).replace('.java', '')] = row['loc']

        loc_list = []
        matched = 0
        for fname in fnames:
            fname_str = str(fname).strip()
            loc_val = 0.0
            if fname_str in csv_file_to_loc:
                loc_val = csv_file_to_loc[fname_str]
                matched += 1
            elif os.path.basename(fname_str) in csv_file_to_loc:
                loc_val = csv_file_to_loc[os.path.basename(fname_str)]
                matched += 1
            else:
                basename = os.path.basename(fname_str).replace('.java', '')
                if basename in csv_file_to_loc:
                    loc_val = csv_file_to_loc[basename]
                    matched += 1
            loc_list.append(float(loc_val))

        print(f"  [LOC] 匹配成功: {matched}/{len(fnames)} 个文件")
        return np.array(loc_list)
    except Exception as e:
        print(f"  [Warning] 提取LOC失败: {e}")
        return None


def evaluate_paper(y_true, y_prob, threshold=0.44, top_k_ratio=None, loc=None):
    """论文标准评估
    
    参数:
        y_true: 真实标签
        y_prob: 预测概率
        threshold: 分类阈
        top_k_ratio: 自适应阈值比
        loc: 代码行数列表 (可, 如果提供则计算基于LOC的P_opt@20%
    """
    y_true = np.array(y_true).flatten()
    y_prob = np.array(y_prob).flatten()

    if top_k_ratio is not None:
        k = max(1, min(len(y_prob), int(len(y_prob) * top_k_ratio)))
        adaptive_thresh = np.sort(y_prob)[-k] - 1e-6
        y_pred = (y_prob > adaptive_thresh).astype(int)
    else:
        y_pred = (y_prob > threshold).astype(int)

    try:
        auc = roc_auc_score(y_true, y_prob)
    except ValueError:
        auc = 0.5

    try:
        ap = average_precision_score(y_true, y_prob)
    except ValueError:
        ap = 0.0

    n = len(y_true)
    total_defects = int(y_true.sum())
    
    # 基于样本数的 Port20% (传统方法)
    top_n = max(1, int(n * 0.2))
    top_n_indices = np.argsort(y_prob)[-top_n:]
    defects_in_top20 = int(y_true[top_n_indices].sum())
    port20 = defects_in_top20 / total_defects if total_defects > 0 else 0.0
    
    # 基于LOCP_opt@20% (论文标准)
    p_opt20 = port20  # 默认使用样本数版
    if loc is not None:
        loc = np.array(loc).flatten()
        if len(loc) == len(y_true):
            total_loc = loc.sum()
            target_loc = total_loc * 0.2  # 20% 代码
            
            # 按预测概率排序, 累积LOC直到达到20%
            sorted_indices = np.argsort(y_prob)[::-1]  # 降序
            cumsum_loc = np.cumsum(loc[sorted_indices])
            
            # 找到累积LOC达到20%cutoff
            cutoff_idx = np.searchsorted(cumsum_loc, target_loc, side='right')
            if cutoff_idx == 0:
                cutoff_idx = 1
            
            top_indices_loc = sorted_indices[:cutoff_idx]
            defects_in_top20_loc = int(y_true[top_indices_loc].sum())
            p_opt20 = defects_in_top20_loc / total_defects if total_defects > 0 else 0.0

    predicted_defective = set(np.where(y_pred == 1)[0])
    actual_defective = set(np.where(y_true == 1)[0])
    ifa = 1.0 if any(p in predicted_defective for p in actual_defective) else 0.0

    return {
        'BalancedAccuracy': balanced_accuracy_score(y_true, y_pred),
        'MCC':  matthews_corrcoef(y_true, y_pred),
        'AUC':  auc,
        'AP':   ap,  # Average Precision
        'F1':   f1_score(y_true, y_pred),
        'Port20%': port20,
        'P_opt20%': p_opt20,  # 基于LOC的版
        'IFA':  ifa,
    }


# ============================================================================
# Focal Loss
# ============================================================================

class FocalLoss(nn.Module):
    def __init__(self, alpha=1, gamma=2):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma

    def forward(self, inputs, targets):
        bce = F.binary_cross_entropy_with_logits(inputs, targets, reduction='none')
        pt  = torch.exp(-bce)
        if not isinstance(self.alpha, torch.Tensor):
            self.alpha = torch.tensor(self.alpha, device=inputs.device)
        alpha_f = self.alpha * targets + (1. - self.alpha) * (1. - targets)
        return (alpha_f * (1 - pt) ** self.gamma * bce).mean()


# ============================================================================
# 数据集构建(tok_embed
# ============================================================================

def build_gnn_dataset(token_lines, labels, builder: ASTGraphBuilder, indices=None):
    """
    构建 GNN 数据集
    tok_data.x tok_data.type_idx builder.build_one() 直接生成
    不再需要外部词向量
    """
    dataset = []
    if indices is None:
        indices = range(len(token_lines))

    valid_indices = [i for i in indices if token_lines[i]]

    for idx in valid_indices:
        file_lines = token_lines[idx]
        label = labels[idx] if labels is not None else None

        tok_data, line_data, line_map = builder.build_one(file_lines)
        tok_data.line_map = line_map

        dataset.append({'tok': tok_data, 'line': line_data, 'label': label})

    return dataset


# ============================================================================
# 韦恩图绘制函数
# ============================================================================
# Case Study 候选样本收集与分析
# ============================================================================

def compute_case_score(met_prob, struct_prob, final_prob, true_label,
                       met_pred, struct_pred, final_pred, threshold=0.42):
    """
    给 case study 候选样本打分：
    分数越高，越适合作为论文案例图。
    """
    # 必须是真实缺陷样本，否则说明力大幅下降
    if true_label != 1:
        return -1e9

    score = 0.0

    # 最核心：Met 漏掉，但 Struct / Final 抓到了
    if (met_pred == 0) and (struct_pred == 1):
        score += 3.0
    if (met_pred == 0) and (final_pred == 1):
        score += 4.0

    # Final 比 Met 的提升越大越好
    score += max(0.0, final_prob - met_prob) * 5.0

    # Struct 比 Met 的提升越大越好
    score += max(0.0, struct_prob - met_prob) * 3.0

    # 最终模型置信度越高越好
    score += max(0.0, final_prob - threshold) * 2.0

    return score


def build_code_lines_for_display(token_lines, max_lines=12):
    """把 token line 转成可显示代码片段"""
    code_lines = []
    for line in token_lines[:max_lines]:
        if isinstance(line, list):
            code_lines.append(" ".join(map(str, line)))
        else:
            code_lines.append(str(line))
    return code_lines


def simple_local_explain(model, x, background, feature_names, top_k=7):
    """
    基于特征替换法的局部解释：
    对于每个特征，将其替换为参考值（背景均值），计算预测概率的变化量
    变化量越大，说明该特征对当前样本的预测贡献越大
    """
    base_prob = model.predict_proba(x.reshape(1, -1))[0, 1]
    ref = np.mean(background, axis=0)
    
    contribs = []
    for j, name in enumerate(feature_names):
        x2 = x.copy()
        x2[j] = ref[j]
        new_prob = model.predict_proba(x2.reshape(1, -1))[0, 1]
        contribution = base_prob - new_prob
        
        contribs.append({
            "feature": name,
            "importance": float(contribution),
            "value": float(x[j])
        })
    
    # 按贡献量绝对值排序，返回 top_k
    contribs = sorted(contribs, key=lambda z: abs(z["importance"]), reverse=True)
    return contribs[:top_k], float(base_prob)


def draw_case_study_figure(
    code_lines,
    explanations,
    met_prob,
    struct_prob,
    final_prob,
    true_label,
    save_path
):
    """
    绘制单个 Case Study 样本的可视化图
    
    参数:
        code_lines: 代码片段列表
        explanations: 特征重要性解释列表
        met_prob: Met 分支预测概率
        struct_prob: GNN 分支预测概率
        final_prob: 融合模型预测概率
        true_label: 真实标签 (0=非缺陷, 1=缺陷)
        save_path: 保存路径
    """
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    
    # ========== 左侧：代码片段 ==========
    ax_code = axes[0]
    ax_code.axis('off')
    
    # 标题
    label_text = "Defective" if true_label == 1 else "Non-Defective"
    ax_code.set_title(f"Tokenized Code Snippet (Ground Truth: {label_text})", fontsize=12, fontweight='bold')
    
    # 渲染代码
    code_text = "\n".join(code_lines) if code_lines else "[No code available]"
    ax_code.text(
        0.05, 0.95, code_text,
        transform=ax_code.transAxes,
        fontsize=9,
        verticalalignment='top',
        fontfamily='monospace',
        bbox=dict(boxstyle='round', facecolor='#f5f5f5', edgecolor='#cccccc')
    )
    
    # ========== 右侧：预测概率和特征重要性 ==========
    ax_right = axes[1]
    ax_right.axis('off')
    
    # 预测概率部分
    ax_right.text(0.5, 0.95, "Prediction Scores", fontsize=12, fontweight='bold',
                  ha='center', va='top', transform=ax_right.transAxes)
    
    # 绘制概率条形图
    probs = [met_prob, struct_prob, final_prob]
    labels = ['Met (Hand)', 'Struct (GNN)', 'Final (Fusion)']
    colors = ['#B65AB7', '#BDEFFF', '#4CAF50']
    
    bar_y = [0.80, 0.70, 0.60]
    bar_height = 0.06
    
    for i, (prob, label, color) in enumerate(zip(probs, labels, colors)):
        # 背景条
        ax_right.add_patch(plt.Rectangle((0.1, bar_y[i] - bar_height/2), 0.8, bar_height,
                                          facecolor='#e0e0e0', edgecolor='none', transform=ax_right.transAxes))
        # 概率条
        ax_right.add_patch(plt.Rectangle((0.1, bar_y[i] - bar_height/2), 0.8 * prob, bar_height,
                                          facecolor=color, edgecolor='none', transform=ax_right.transAxes))
        # 标签
        ax_right.text(0.1, bar_y[i] + bar_height, f"{label}: {prob:.3f}",
                      fontsize=10, transform=ax_right.transAxes, va='bottom')
    
    # Metric-side 解释部分
    ax_right.text(0.5, 0.45, "Metric-side Explanation", fontsize=12, fontweight='bold',
                  ha='center', va='top', transform=ax_right.transAxes)
    
    if explanations and len(explanations) > 0:
        # 绘制特征贡献双向条形图（支持正负贡献）
        features = [e['feature'] for e in explanations[:7]]
        importances = [e['importance'] for e in explanations[:7]]
        
        max_abs_imp = max(abs(v) for v in importances) if importances else 1.0
        if max_abs_imp == 0:
            max_abs_imp = 1.0
        
        y_positions = np.linspace(0.35, 0.10, len(features))
        x_center = 0.40
        max_bar_width = 0.28
        
        # 中心线
        ax_right.plot(
            [x_center, x_center],
            [0.07, 0.38],
            color='black',
            linewidth=1,
            transform=ax_right.transAxes
        )
        
        for i, (feat, imp) in enumerate(zip(features, importances)):
            width = max_bar_width * (abs(imp) / max_abs_imp)
            color = '#D62728' if imp >= 0 else '#1F77B4'
            
            if imp >= 0:
                x_start = x_center
            else:
                x_start = x_center - width
            
            ax_right.add_patch(
                plt.Rectangle(
                    (x_start, y_positions[i] - 0.02),
                    width,
                    0.035,
                    facecolor=color,
                    edgecolor='none',
                    transform=ax_right.transAxes
                )
            )
            
            ax_right.text(
                0.72,
                y_positions[i],
                f"{feat}: {imp:+.4f}",
                fontsize=9,
                transform=ax_right.transAxes,
                va='center'
            )
    else:
        ax_right.text(0.5, 0.25, "[No explanations available]",
                      fontsize=10, ha='center', va='center', transform=ax_right.transAxes)
    
    plt.tight_layout()
    
    # 保存为 SVG 格式
    plt.savefig(save_path, format='svg', bbox_inches='tight', dpi=150)
    plt.close()
    
    print(f"  [Case Study] 已保存案例图: {save_path}")


# ============================================================================
# 注意：圆形大小是固定的，不会随数据变化而变化
# 固定参数：radius=0.82, left_center=(-0.18,0.02), right_center=(0.18,0.02)
# 坐标范围也固定，确保不同子图和不同项目的圆大小一致
# 显示归一化比例：相对于各自分支总识别数量的独有比例
def draw_venn_diagram(
    ax,
    title,
    left_only,
    overlap,
    right_only,
    left_label="Hand",
    right_label="GNN",
    left_color="#B65AB7",
    right_color="#BDEFFF",
):
    ax.set_aspect("equal")
    ax.axis("off")

    # ========== 固定的圆形参数（不随数据变化）==========
    # 圆形大小固定为 radius=0.82，不随数字大小变化
    # 重叠程度固定：通过 center 位置控制，不随数据变化
    radius = 0.82
    left_center = (-0.18, 0.02)
    right_center = (0.18, 0.02)

    ax.add_patch(
        Circle(
            left_center,
            radius,
            facecolor=left_color,
            edgecolor="none",
            alpha=0.78,
        )
    )

    ax.add_patch(
        Circle(
            right_center,
            radius,
            facecolor=right_color,
            edgecolor="none",
            alpha=0.78,
        )
    )

    # ========== 计算归一化比例 ==========
    # 各自分支总识别数量
    left_total = left_only + overlap
    right_total = right_only + overlap
    
    # 计算独有比例（相对于各自分支总识别数量）
    if left_total > 0:
        left_ratio = (left_only / left_total) * 100
    else:
        left_ratio = 0.0
    
    if right_total > 0:
        right_ratio = (right_only / right_total) * 100
    else:
        right_ratio = 0.0
    
    # 重叠部分显示原始数量（作为参考）
    overlap_display = f"{overlap}"
    
    # 三个区域的显示内容
    left_display = f"{left_only}\n({left_ratio:.1f}%)"
    right_display = f"{right_only}\n({right_ratio:.1f}%)"

    # 三个区域的数字位置（向内移动，避免文字跑到圆外面）
    ax.text(-0.75, 0.02, left_display, ha="center", va="center", fontsize=10)
    ax.text(0.00, 0.02, overlap_display, ha="center", va="center", fontsize=11)
    ax.text(0.75, 0.02, right_display, ha="center", va="center", fontsize=10)

    # 底部标签位置（固定位置）
    ax.text(-0.30, -0.93, left_label, ha="center", va="center", fontsize=14, fontweight='bold')
    ax.text(0.30, -0.93, right_label, ha="center", va="center", fontsize=14, fontweight='bold')

    # 标题
    ax.set_title(title, fontsize=15, fontweight="normal", pad=12)

    # ========== 固定坐标范围（确保不同子图圆大小一致）==========
    ax.set_xlim(-1.25, 1.25)
    ax.set_ylim(-1.08, 1.02)


# ============================================================================
# 三集合韦恩图区域计算函数
# ============================================================================
def calc_three_set_regions(A, B, C):
    """
    计算三个集合的标准韦恩图 7 个互斥区域
    
    参数:
        A = Met 集合（样本索引或布尔数组）
        B = Struct 集合
        C = MetStruct++ 集合
    
    返回:
        dict: 包含 7 个区域的计数字典
    """
    # 转换为集合（如果输入是 numpy 数组）
    if hasattr(A, 'astype'):
        A = set(np.where(A)[0])
    if hasattr(B, 'astype'):
        B = set(np.where(B)[0])
    if hasattr(C, 'astype'):
        C = set(np.where(C)[0])
    
    return {
        "left_only": len(A - B - C),           # 只属于 Met
        "right_only": len(B - A - C),          # 只属于 Struct
        "bottom_only": len(C - A - B),         # 只属于 MetStruct++
        "left_right_only": len((A & B) - C),   # Met + Struct 交集（不含 MetStruct++）
        "left_bottom_only": len((A & C) - B),  # Met + MetStruct++ 交集（不含 Struct）
        "right_bottom_only": len((B & C) - A), # Struct + MetStruct++ 交集（不含 Met）
        "all_three": len(A & B & C),           # 三者共同交集
    }


# ============================================================================
# 三圆韦恩图绘制函数（用于三个分支比较）
# ============================================================================
# 更强调 MetStruct++ 融合作用的三分支示意图（全部使用圆形）
def draw_three_branch_containment_style(
    ax,
    title,
    met_unique_in_fusion,
    struct_unique_in_fusion,
    fusion_only,
    met_struct_overlap_outside_fusion,
    met_fusion_only,
    struct_fusion_only,
    all_three,
    left_label="Met",
    right_label="Struct",
    bottom_label="MetStruct++",
    left_color="#A000A0",
    right_color="#87D7F5",
    bottom_color="#A8F08A",
    left_alpha=0.85,
    right_alpha=0.70,
    bottom_alpha=0.50,
    left_center=(-0.48, 0.22),
    right_center=(0.48, 0.22),
    bottom_center=(0.00, -0.05),
    left_radius=0.62,
    right_radius=0.62,
    bottom_radius=1.35,
    fontsize_num=12,
    fontsize_label=16,
    fontsize_title=18,
):
    """
    更强调 MetStruct++ 融合作用的三分支示意图（全部使用圆形）

    注意：
    这个图更强调"MetStruct++ 对 Met 和 Struct 的覆盖与融合效果"，
    不是严格意义上的标准 7 区域 Venn 几何表达。

    参数含义建议：
    met_unique_in_fusion:
        Met 能识别、Struct 不能识别，且这些样本也被 MetStruct++ 覆盖

    struct_unique_in_fusion:
        Struct 能识别、Met 不能识别，且这些样本也被 MetStruct++ 覆盖

    fusion_only:
        只有 MetStruct++ 识别出来的样本

    met_struct_overlap_outside_fusion:
        Met 和 Struct 的交集但不属于 MetStruct++（如果没有就传 0）

    met_fusion_only:
        Met 与 MetStruct++ 交集但不属于 Struct

    struct_fusion_only:
        Struct 与 MetStruct++ 交集但不属于 Met

    all_three:
        三者共同交集
    """

    ax.set_aspect("equal")
    ax.axis("off")

    # 先画大圆：MetStruct++
    ax.add_patch(
        Circle(
            bottom_center,
            bottom_radius,
            facecolor=bottom_color,
            edgecolor="none",
            alpha=bottom_alpha,
            zorder=1
        )
    )

    # 再画两个小圆：Met / Struct
    ax.add_patch(
        Circle(
            left_center,
            left_radius,
            facecolor=left_color,
            edgecolor="none",
            alpha=left_alpha,
            zorder=2
        )
    )

    ax.add_patch(
        Circle(
            right_center,
            right_radius,
            facecolor=right_color,
            edgecolor="none",
            alpha=right_alpha,
            zorder=2
        )
    )

    # =========================
    # 数字位置（更符合"融合覆盖"表达）
    # =========================

    # Met 相对 Struct 的独有部分（同时被 MetStruct++ 覆盖）
    ax.text(-0.82, 0.18, str(met_fusion_only if met_fusion_only is not None else met_unique_in_fusion),
            ha="center", va="center", fontsize=fontsize_num)

    # Struct 相对 Met 的独有部分（同时被 MetStruct++ 覆盖）
    ax.text(0.82, 0.18, str(struct_fusion_only if struct_fusion_only is not None else struct_unique_in_fusion),
            ha="center", va="center", fontsize=fontsize_num)

    # 三者共同交集
    ax.text(0.00, 0.22, str(all_three),
            ha="center", va="center", fontsize=fontsize_num + 1)

    # 只有 MetStruct++ 识别
    ax.text(0.00, -0.92, str(fusion_only),
            ha="center", va="center", fontsize=fontsize_num)

    # 如果你仍想显示 "Met 和 Struct 交集但不属于 MetStruct++"
    # 一般如果你强调融合覆盖，这个值应很小甚至为 0
    if met_struct_overlap_outside_fusion is not None and met_struct_overlap_outside_fusion != 0:
        ax.text(0.00, 0.92, str(met_struct_overlap_outside_fusion),
                ha="center", va="center", fontsize=fontsize_num)

    # 如果你还坚持显示"Met only / Struct only"严格区域，也可以保留
    # 但在这种 containment-style 图里通常不建议再突出外侧独有区
    if met_unique_in_fusion is not None and met_unique_in_fusion != 0 and met_fusion_only == 0:
        ax.text(-1.18, 0.20, str(met_unique_in_fusion),
                ha="center", va="center", fontsize=fontsize_num)

    if struct_unique_in_fusion is not None and struct_unique_in_fusion != 0 and struct_fusion_only == 0:
        ax.text(1.18, 0.20, str(struct_unique_in_fusion),
                ha="center", va="center", fontsize=fontsize_num)

    # 标签
    ax.text(-0.82, 1.05, left_label,
            ha="center", va="center", fontsize=fontsize_label, fontweight="bold")
    ax.text(0.82, 1.05, right_label,
            ha="center", va="center", fontsize=fontsize_label, fontweight="bold")
    ax.text(0.00, -1.42, bottom_label,
            ha="center", va="center", fontsize=fontsize_label, fontweight="bold")

    # 标题
    ax.set_title(title, fontsize=fontsize_title, pad=12)

    # 坐标范围
    ax.set_xlim(-1.80, 1.80)
    ax.set_ylim(-1.55, 1.30)


# ============================================================================
# 预测概率散点图绘制函数
# ============================================================================
def draw_prediction_scatter_plot(
    hand_probs,
    gnn_probs,
    true_labels,
    title="Hand vs GNN 预测概率散点图",
    xlabel="Hand 预测概率",
    ylabel="GNN 预测概率",
    save_path=None,
):
    """
    绘制Hand和GNN模型预测概率的散点图，并添加对角线作为参考。

    参数：
        hand_probs: Hand模型的预测概率数组
        gnn_probs: GNN模型的预测概率数组
        true_labels: 真实标签（0=干净，1=缺陷）
        title: 图表标题
        xlabel: x轴标签
        ylabel: y轴标签
        save_path: 保存路径（支持svg/png等格式）
    """
    plt.figure(figsize=(6, 6))

    # 按真实标签上色（蓝色=干净，红色=缺陷）
    colors = ['#4169E1' if y == 0 else '#DC143C' for y in true_labels]

    # 绘制散点图
    plt.scatter(hand_probs, gnn_probs, c=colors, alpha=0.6, s=30, edgecolors='none')

    # 绘制对角线 y=x
    plt.plot([0, 1], [0, 1], 'k--', linewidth=1.5, label='y=x')

    # 设置标签和标题
    plt.xlabel(xlabel, fontsize=12)
    plt.ylabel(ylabel, fontsize=12)
    plt.title(title, fontsize=14, fontweight='normal', pad=12)

    # 添加图例
    from matplotlib.patches import Patch
    legend_elements = [
        Patch(facecolor='#4169E1', label='Clean (0)'),
        Patch(facecolor='#DC143C', label='Defective (1)'),
        plt.Line2D([0], [0], color='black', linestyle='--', label='y=x')
    ]
    plt.legend(handles=legend_elements, loc='lower right', fontsize=10)

    # 设置坐标轴范围
    plt.xlim(-0.05, 1.05)
    plt.ylim(-0.05, 1.05)

    # 添加网格
    plt.grid(True, alpha=0.3)

    # 确保纵横比相等
    plt.gca().set_aspect('equal', adjustable='box')

    plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight', format='svg')
        print(f"  [Scatter Plot] 已保存: {save_path}")

    plt.show()
    plt.close()


# ============================================================================
# 符号检验 P-value 热图绘制函数
# ============================================================================
def format_p_value(v):
    """控制 p-value 的显示格式"""
    if v < 1e-4:
        return f"{v:.0e}"
    return f"{v:g}"


def draw_sign_test_heatmap_log(
    p_values,
    x_labels,
    row_label="Met vs Struct",
    title="Statistical significance of Met vs Struct",
    save_path=None,
    cap_value=60,
):
    """
    使用 -log10(p-value) 绘制显著性热图。
    p 越小，-log10(p) 越大，颜色越亮。
    cap_value 用于截断极端值，避免 1e-123 把其他显著结果压暗。
    """
    p_values = np.asarray(p_values, dtype=float).reshape(1, -1)

    # 避免 log10(0)
    safe_p = np.clip(p_values, 1e-300, 1.0)

    # 转换为显著性强度
    log_p = -np.log10(safe_p)

    # 截断极端值，让颜色更均衡
    log_p_capped = np.clip(log_p, 0, cap_value)

    fig, ax = plt.subplots(figsize=(11, 3.4))

    im = ax.imshow(
        log_p_capped,
        cmap="YlOrRd",
        vmin=0,
        vmax=cap_value,
        aspect="auto",
        interpolation="nearest",
    )

    ax.set_xticks(np.arange(len(x_labels)))
    ax.set_xticklabels(
        x_labels,
        rotation=45,
        ha="right",
        rotation_mode="anchor",
        fontsize=11
    )

    ax.set_yticks([0])
    ax.set_yticklabels([row_label], fontsize=12)

    ax.set_title(title, fontsize=15, fontweight="bold", pad=12)

    # 在每个格子里同时显示 -log10(p) 和显著性星号
    for j, p in enumerate(p_values[0]):
        if p < 0.001:
            star = "***"
        elif p < 0.01:
            star = "**"
        elif p < 0.05:
            star = "*"
        else:
            star = "n.s."

        log_p_val = log_p[0, j]
        text = f"{log_p_val:.1f}\n{star}"

        ax.text(
            j,
            0,
            text,
            ha="center",
            va="center",
            fontsize=10,
            fontweight="bold",
            color="black" if log_p_capped[0, j] < cap_value * 0.55 else "white",
        )

    # 边框
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(1.2)
        spine.set_color("black")

    ax.tick_params(axis="both", length=4, width=1.1, colors="black")

    cbar = fig.colorbar(im, ax=ax, fraction=0.035, pad=0.035)
    cbar.set_label(r"$-\log_{10}(p)$", fontsize=12)
    cbar.ax.tick_params(labelsize=10)

    plt.subplots_adjust(left=0.10, right=0.88, top=0.78, bottom=0.38)

    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches="tight", format="svg")
        print(f"[Significance Heatmap] 已保存: {save_path}")

    plt.close()


# ============================================================================
# GNN Wrapper 类
# ============================================================================
class GNNWrapper(nn.Module):
    def __init__(self, gnn_model):
        super().__init__()
        self.gnn = gnn_model
        gnn_out_dim = gnn_model.out_dim
        self.classifier = nn.Linear(gnn_out_dim, 1)

    def forward(self, tok_batch, _line_batch=None):
        # 安全获取 type_idx, 确保在正确设备
        type_idx = None
        if hasattr(tok_batch, 'type_idx') and tok_batch.type_idx is not None:
            type_idx = tok_batch.type_idx.to(tok_batch.x.device)

        vec, _, _, _ = self.gnn(
            tok_batch.x,
            tok_batch.edge_index,
            tok_batch.batch,
            type_idx=type_idx,
        )
        vec = F.normalize(vec, p=2, dim=1)
        return self.classifier(vec), vec


# ============================================================================
# GNN 预训
# ============================================================================

def pretrain_gnn(model_ld: LineDefGCNAtt,
                 token_lines, labels,
                 builder: ASTGraphBuilder,
                 device,
                 test_proj="unknown",  # 添加项目名称参数
                 epochs=200,
                 test_token_lines=None,
                 patience=12,
                 focal_gamma=2.0,
                 focal_alpha_mode='auto',
                 use_center=True,
                 center_weight=0.05,
                 use_margin=True,
                 margin_weight=0.8,
                 margin=0.5,
                 sample_weights=None):
    """
    预训练 LineDefGCNAtt (AST 版)
    - 移除 tok_embed 参数, 图节点特征由 builder 在线生成
    - Center Loss + Margin Loss 抗领域漂移
    - 无 MPOS 技术
    """
    print(f"Pre-training GCN (Center Loss={use_center}, Margin Loss={use_margin}, "
          f"center_weight={center_weight}, margin_weight={margin_weight}, margin={margin}, "
          f"Epochs={epochs}, Patience={patience})...")

    wrapper = GNNWrapper(model_ld).to(device)
    wrapper.train()

    opt = torch.optim.AdamW(wrapper.parameters(), lr=0.001, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        opt, T_max=epochs, eta_min=1e-5
    )

    # ---- 数据划分 ----
    import random
    if sample_weights is None:
        sample_weights = np.ones(len(labels))
    
    if patience > 0:
        if len(labels) < 20:
            train_indices = val_indices = list(range(len(labels)))
        else:
            train_indices, val_indices = train_test_split(
                range(len(labels)), test_size=0.2,
                random_state=42, stratify=labels
            )

        source_train_data = build_gnn_dataset(
            [token_lines[i] for i in train_indices],
            [labels[i] for i in train_indices],
            builder
        )
        # 为每个样本附加权重
        for idx, item in enumerate(source_train_data):
            item['sample_weight'] = sample_weights[train_indices[idx]]
        
        source_val_data = build_gnn_dataset(
            [token_lines[i] for i in val_indices],
            [labels[i] for i in val_indices],
            builder
        )
        for idx, item in enumerate(source_val_data):
            item['sample_weight'] = 1.0  # 验证集权重设为 1
    else:
        # 不使用验证集，所有数据都用于训练
        train_indices = list(range(len(labels)))
        source_train_data = build_gnn_dataset(
            token_lines,
            labels,
            builder
        )
        # 为每个样本附加权重
        for idx, item in enumerate(source_train_data):
            item['sample_weight'] = sample_weights[idx]
        source_val_data = None

    # ---- 动态 Focal Loss ----
    y_train = [d['label'] for d in source_train_data]
    pos_r = float(sum(y_train) / max(len(y_train), 1))
    if focal_alpha_mode == 'auto':
        dyn_alpha = 1.0 - pos_r
    elif focal_alpha_mode == 'fixed':
        dyn_alpha = 0.5  # 固定 alpha=0.5，不使用动态调整
    else:
        dyn_alpha = max(0.5, min(0.95, 1.0 - pos_r))
    alpha_t = torch.tensor(dyn_alpha, device=device, dtype=torch.float32)
    criterion = FocalLoss(alpha=alpha_t, gamma=focal_gamma).to(device)
    print(f"  Focal Loss: gamma={focal_gamma}, alpha={dyn_alpha:.4f} (pos_ratio={pos_r:.4f}, mode={focal_alpha_mode})")

    best_val_score = -1.0
    best_state     = None
    patience_ctr   = 0

    for epoch in range(epochs):
        wrapper.train()
        total_loss, n_batches = 0.0, 0

        # 创建索引数组（用于保存 shuffle 顺序）
        shuffle_order = np.arange(len(source_train_data))
        
        # 构建缓存路径
        shuffle_cache_dir = "/public/home/zhangzihao2025/TGNN/cache/shuffle_history"
        os.makedirs(shuffle_cache_dir, exist_ok=True)
        shuffle_cache_path = os.path.join(shuffle_cache_dir, f"{test_proj}_gnn_shuffle_epoch{epoch}.npy")
        
        if os.path.exists(shuffle_cache_path):
            # 加载已有的 shuffle 顺序
            shuffle_order = np.load(shuffle_cache_path)
            print(f"  [Cache] 加载 Epoch {epoch} shuffle 顺序: {shuffle_cache_path}")
            
            # 根据缓存的顺序重新排列数据
            source_train_data = [source_train_data[i] for i in shuffle_order]
        else:
            # 生成新的 shuffle 顺序
            random.shuffle(source_train_data)
            np.save(shuffle_cache_path, shuffle_order)
            print(f"  [Cache] 保存 Epoch {epoch} shuffle 顺序: {shuffle_cache_path}")
        
        cur_batch = []

        for item in source_train_data:
            cur_batch.append(item)

            is_last = (item is source_train_data[-1])
            if len(cur_batch) < Config.BATCH_SIZE and not is_last:
                continue

            tok_b = Batch.from_data_list([b['tok'] for b in cur_batch]).to(device)
            y_b   = torch.FloatTensor([b['label'] for b in cur_batch]).view(-1, 1).to(device)
            w_b   = torch.FloatTensor([b['sample_weight'] for b in cur_batch]).view(-1, 1).to(device)

            opt.zero_grad()
            logits_s, feats_s = wrapper(tok_b)
            
            # 应用样本权重的 Focal Loss
            cls_loss = criterion(logits_s, y_b)
            weighted_cls_loss = (cls_loss * w_b).mean()

            center_loss_val = torch.tensor(0.0, device=device)
            if use_center:
                center_loss_val = center_loss_binary(feats_s, y_b)

            margin_loss_val = torch.tensor(0.0, device=device)
            if use_margin:
                margin_loss_val = center_margin_loss(feats_s, y_b, margin=margin)

            loss = weighted_cls_loss + center_weight * center_loss_val + margin_weight * margin_loss_val
            if not torch.isnan(loss) and loss.item() > 1e-8:
                loss.backward()
                torch.nn.utils.clip_grad_norm_(wrapper.parameters(), 5.0)
                opt.step()
                total_loss += loss.item()
                n_batches  += 1

            cur_batch = []

        scheduler.step()

        # ---- 验证 ----
        if patience > 0 and source_val_data is not None:
            wrapper.eval()
            val_preds, val_targets = [], []
            with torch.no_grad():
                for item in source_val_data:
                    tok_b = Batch.from_data_list([item['tok']]).to(device)
                    logits, _ = wrapper(tok_b)
                    val_preds.extend(torch.sigmoid(logits).cpu().numpy())
                    val_targets.append(item['label'])

            val_true = np.array(val_targets)
            val_prob = np.array(val_preds).flatten()

            try:
                val_auc = roc_auc_score(val_true, val_prob)
            except ValueError:
                val_auc = 0.5

            val_thresh = 1.0 - pos_r if len(y_train) > 0 else 0.5
            val_pred   = (val_prob > val_thresh).astype(int)
            val_mcc    = matthews_corrcoef(val_true, val_pred)

            val_score = 0.5 * val_auc + 0.5 * (val_mcc + 1.0) / 2.0

            if val_score > best_val_score:
                best_val_score = val_score
                best_state = {k: v.detach().cpu().clone()
                              for k, v in model_ld.state_dict().items()}
                patience_ctr = 0
            else:
                patience_ctr += 1

            if (epoch + 1) % 10 == 0:
                print(f"  Epoch {epoch+1}: "
                      f"Loss={total_loss/max(n_batches,1):.4f}, "
                      f"Val AUC={val_auc:.4f}")

            if patience_ctr >= patience:
                print(f"  Early stopping at epoch {epoch+1}")
                break
        else:
            # 无验证集时，每10轮打印训练损失
            if (epoch + 1) % 10 == 0:
                print(f"  Epoch {epoch+1}: "
                      f"Loss={total_loss/max(n_batches,1):.4f}")

    if best_state:
        model_ld.load_state_dict(best_state)

    # 返回 wrapper，因为它包含了训练好的 classifier
    return wrapper


# ============================================================================
# 文件级特征提取(tok_embed
# ============================================================================

def get_file_vecs(model: LineDefGCNAtt,
                  token_lines_list,
                  builder: ASTGraphBuilder,
                  device) -> np.ndarray:
    """
    批量提取文件GNN 特征向量
    """
    model.eval()
    feats = []

    for file_lines in token_lines_list:
        if not file_lines:
            file_lines = ['// empty']

        tok_data, _, _ = builder.build_one(file_lines)
        tok_batch = Batch.from_data_list([tok_data])

        with torch.no_grad():
            type_idx = None
            if hasattr(tok_batch, 'type_idx') and tok_batch.type_idx is not None:
                type_idx = tok_batch.type_idx.to(device)

            file_vec, _, _, _ = model(
                tok_batch.x.to(device),
                tok_batch.edge_index.to(device),
                tok_batch.batch.to(device),
                type_idx=type_idx,
            )
            file_vec = F.normalize(file_vec, p=2, dim=1)

        feats.append(file_vec.cpu().numpy())

    return np.vstack(feats)


# ============================================================================
# 主流
# ============================================================================

def main():
    all_res          = []
    all_sample_preds = []
    
    # 全局 Case Study 候选样本池
    global_case_pool = []
    # Fallback 样本池：Final - Met 差距最大的真实缺陷样本
    global_fallback_pool = []
    
    # 保存预测分数用于 Wilcoxon 检验
    pred_scores = []
    
    # 韦恩图汇总数据（收集所有项目的数据）
    # 双分支（阈值版本）
    total_tp_hand_only = 0
    total_tp_overlap = 0
    total_tp_gnn_only = 0
    total_fp_hand_only = 0
    total_fp_overlap = 0
    total_fp_gnn_only = 0
    
    # 三分支（阈值版本）
    total_tp_only_hand = 0
    total_tp_only_gnn = 0
    total_tp_only_simcom = 0
    total_tp_hand_gnn = 0
    total_tp_hand_simcom = 0
    total_tp_gnn_simcom = 0
    total_tp_all_three = 0
    total_fp_only_hand = 0
    total_fp_only_gnn = 0
    total_fp_only_simcom = 0
    total_fp_hand_gnn = 0
    total_fp_hand_simcom = 0
    total_fp_gnn_simcom = 0
    total_fp_all_three = 0
    
    # 双分支（Top-K 版本）
    total_tp_hand_only_topk = 0
    total_tp_overlap_topk = 0
    total_tp_gnn_only_topk = 0
    total_fp_hand_only_topk = 0
    total_fp_overlap_topk = 0
    total_fp_gnn_only_topk = 0
    
    # 三分支（Top-K 版本）
    total_tp_only_hand_topk = 0
    total_tp_only_gnn_topk = 0
    total_tp_only_simcom_topk = 0
    total_tp_hand_gnn_topk = 0
    total_tp_hand_simcom_topk = 0
    total_tp_gnn_simcom_topk = 0
    total_tp_all_three_topk = 0
    total_fp_only_hand_topk = 0
    total_fp_only_gnn_topk = 0
    total_fp_only_simcom_topk = 0
    total_fp_hand_gnn_topk = 0
    total_fp_hand_simcom_topk = 0
    total_fp_gnn_simcom_topk = 0
    total_fp_all_three_topk = 0

    # 散点图数据收集
    total_hand_probs = []
    total_gnn_probs = []
    total_true_labels = []

    # 权重敏感性分析数据收集
    weight_sensitivity_results = []
    
    # 源项目数量消融实验数据收集
    source_count_results = {}
    for k in [1, 2, 3, 4, 5, 6]:
        source_count_results[k] = []
    
    # 一对一项目对消融实验数据收集
    pair_one_results = []

    pairs_path = "/public/home/zhangzihao2025/TGNN/data/pairs-one.txt"
    if not os.path.exists(pairs_path):
        print(f"Error: Pairs file not found at {pairs_path}")
        return

    # ---- 保留原有 pairs 读取（用于获取项目列表）----
    pairs = []
    all_projects = set()
    with open(pairs_path, 'r') as f:
        for line in f:
            parts = line.strip().split(',')
            if len(parts) >= 2:
                pairs.append(parts[:2])
                all_projects.add(parts[0])
                all_projects.add(parts[1])
    all_projects = list(all_projects)
    print(f"Total Pairs: {len(pairs)}, Total Projects: {len(all_projects)}")

    # ================================================================
    # 预加载所有项目数据（带缓存）
    # ================================================================
    # 生成唯一运行ID
    run_id = int(time.time())
    print("\n" + "="*60)
    print(f"PRELOADING ALL PROJECT DATA (Run ID: {run_id})")
    print("="*60)
    all_project_data = {}

    # 创建缓存目录
    order_cache_dir = "/public/home/zhangzihao2025/TGNN/cache/order_history"
    preprocessed_cache_dir = "/public/home/zhangzihao2025/TGNN/cache/preprocessed_data"
    os.makedirs(order_cache_dir, exist_ok=True)
    os.makedirs(preprocessed_cache_dir, exist_ok=True)

    for proj in all_projects:
        print(f"\n[Preload] Loading project: {proj}")

        # 直接加载现有的预处理数据缓存
        import glob
        existing_cache_files = glob.glob(os.path.join(preprocessed_cache_dir, f"{proj}_preprocessed_*.pkl"))
        if existing_cache_files:
            # 按时间戳排序，取最新的
            existing_cache_files.sort(key=lambda x: int(x.split('_')[-1].replace('.pkl', '')), reverse=True)
            latest_cache = existing_cache_files[0]
            print(f"  [Cache] 加载预处理数据缓存: {latest_cache}")
            with open(latest_cache, 'rb') as f:
                all_project_data[proj] = pickle.load(f)
            print(f"  ✓ {proj}: 从缓存加载 {len(all_project_data[proj]['token_lines'])} files")
        else:
            print(f"  [Error] 未找到 {proj} 的预处理缓存，跳过此项目")
            continue

    print(f"\n✓ 预加载完成，共 {len(all_project_data)} 个项目")

    # ================================================================
    # 消融实验1：一对一项目对（pairs-one）
    # ================================================================
    print("\n" + "=" * 120)
    print(">>> ABLATION: Pair-One Experiment (一对一项目对)")
    print("=" * 120)
    
    for src_proj, tgt_proj in pairs:
        if src_proj not in all_project_data or tgt_proj not in all_project_data:
            print(f"  [Skip] 项目 {src_proj} -> {tgt_proj} 数据不完整")
            continue
        
        print(f"\n  [Pair-One] {src_proj} -> {tgt_proj}")
        
        src_data = all_project_data[src_proj]
        tgt_data = all_project_data[tgt_proj]
        
        # 直接使用源项目数据，不进行多源合并
        train_hand_raw_pair = src_data['hand_raw']
        train_label_pair = src_data['label_orig']
        train_token_lines_pair = src_data['token_lines']
        
        # 标准化
        scaler_pair = QuantileTransformer(output_distribution='normal', random_state=Config.RANDOM_SEED)
        train_hand_pure_pair = scaler_pair.fit_transform(train_hand_raw_pair)
        
        scaler_tgt_pair = QuantileTransformer(output_distribution='normal', random_state=Config.RANDOM_SEED)
        test_hand_pure_pair = scaler_tgt_pair.fit_transform(tgt_data['hand_raw'])
        
        test_label_eval_pair = tgt_data['label_orig']
        
        # 训练 Hand 分支
        rf_hand_pair = RandomForestClassifier(
            n_estimators=500, max_depth=15, min_samples_split=5,
            max_features='sqrt', class_weight=None, n_jobs=-1,
            random_state=Config.RANDOM_SEED
        )
        rf_hand_pair.fit(train_hand_pure_pair, train_label_pair)
        
        # 评估
        y_prob_hand_pair = rf_hand_pair.predict_proba(test_hand_pure_pair)[:, 1]
        y_prob_hand_pair_ranked = rankdata(y_prob_hand_pair) / len(y_prob_hand_pair)
        res_hand_pair = evaluate_paper(test_label_eval_pair, y_prob_hand_pair_ranked, threshold=0.44, loc=tgt_proj)
        
        print(f"    Pair-One {src_proj}->{tgt_proj}: MCC={res_hand_pair['MCC']:.4f}  AUC={res_hand_pair['AUC']:.4f}")
        
        pair_one_results.append({
            'src_proj': src_proj,
            'tgt_proj': tgt_proj,
            'MCC': res_hand_pair['MCC'],
            'AUC': res_hand_pair['AUC'],
            'BACC': res_hand_pair['BalancedAccuracy'],
            'F1': res_hand_pair['F1'],
        })
    
    # ================================================================
    # 主实验循环
    # ================================================================
    for run_i in range(1):
        print(f'\n{"*"*60}')
        print(f'>>> RUN {run_i+1}/1 (Run ID: {run_id})')
        print(f'{"*"*60}')
        setup_random_seed(Config.RANDOM_SEED + run_i)

        # ---- 对每个目标项目，使用 MASTER 多源加权数据选择 ----
        for test_proj in all_project_data.keys():
            print(f'\n{"="*60}')
            print(f'>>> Target Project: {test_proj}')
            print(f'{"="*60}')

            target_data = all_project_data[test_proj]

            # 候选源项目（除去目标项目本身和 log4j）
            candidate_sources = [p for p in all_project_data.keys() if p != test_proj and p != 'log4j-1.2']

            if len(candidate_sources) < 2:
                print(f"  [Skip] 候选源项目不足（至少需要2个）")
                continue

            # ---- MASTER 多源加权采样 ----
            tgt_hand_raw = target_data['hand_raw']
            tgt_label_orig = target_data['label_orig']

            # 计算每个候选源项目的综合权重
            src_weight_list = []
            for src_proj in candidate_sources:
                src_data = all_project_data[src_proj]
                # 计算综合权重
                w = compute_source_weight_master(
                    src_data['hand_raw'],
                    src_data['label_orig'],
                    tgt_hand_raw,
                    method='mmd',
                    use_kmm=True
                )
                src_weight_list.append((src_proj, src_data, w))

            # 按权重降序排序，取 Top-K
            src_weight_list.sort(key=lambda x: x[2], reverse=True)
            
            # ================================================================
            # 源项目数量消融实验：对不同K值进行实验
            # ================================================================
            ablation_k_values = [1, 2, 4, 5, 6]
            
            for ablation_K in ablation_k_values:
                print(f"\n  [Ablation] 源项目数量 K={ablation_K}")
                
                if ablation_K > len(src_weight_list):
                    print(f"    [Skip] 候选源项目不足（仅有{len(src_weight_list)}个）")
                    continue
                
                selected_k = src_weight_list[:ablation_K]
                
                merged_hand_raw_k = []
                merged_token_lines_k = []
                merged_fnames_k = []
                merged_label_k = []
                merged_sample_weights_k = []
                
                sample_cache_dir = "/public/home/zhangzihao2025/TGNN/cache/sample_history"
                os.makedirs(sample_cache_dir, exist_ok=True)
                
                valid_src_count = 0
                for src_proj, src_data, w in selected_k:
                    import glob
                    existing_sample_files = glob.glob(os.path.join(sample_cache_dir, f"{src_proj}_{test_proj}_idx_*.npy"))
                    
                    if existing_sample_files:
                        # 使用缓存
                        existing_sample_files.sort(key=lambda x: int(x.split('_')[-1].replace('.npy', '')), reverse=True)
                        latest_sample = existing_sample_files[0]
                        sample_idx = np.load(latest_sample)
                        print(f"    [Cache] 加载采样索引缓存: {latest_sample}")
                    elif ablation_K > 3:
                        # K>3 时，现场生成采样索引
                        print(f"    [Generate] K={ablation_K}>3，现场生成 {src_proj}_{test_proj} 采样索引...")
                        
                        # 计算 KMM 权重
                        kmm_weights = compute_kmm_weight(
                            src_data['hand_raw'],
                            target_data['hand_raw']
                        )
                        
                        # 根据 KMM 权重采样（采样数量与缓存中其他项目的平均数量相同）
                        n_samples = min(int(kmm_weights.sum()), len(kmm_weights))
                        
                        # 使用 KMM 权重进行加权采样
                        kmm_weights_normalized = kmm_weights / kmm_weights.sum()
                        sample_idx = np.random.choice(
                            len(src_data['hand_raw']),
                            size=n_samples,
                            replace=False,
                            p=kmm_weights_normalized
                        )
                        
                        # 保存采样索引缓存
                        cache_timestamp = int(time.time())
                        cache_path = os.path.join(sample_cache_dir, f"{src_proj}_{test_proj}_idx_{cache_timestamp}.npy")
                        np.save(cache_path, sample_idx)
                        print(f"    [Save] 已保存采样索引缓存: {cache_path}")
                    else:
                        # K<=3 且没有缓存，跳过
                        print(f"    [Warning] 未找到 {src_proj}_{test_proj} 的采样索引缓存，跳过此源项目")
                        continue
                    
                    merged_hand_raw_k.append(src_data['hand_raw'][sample_idx])
                    merged_label_k.append(src_data['label_orig'][sample_idx])
                    merged_sample_weights_k.extend([w] * len(sample_idx))
                    lines_sampled = [src_data['token_lines'][i] for i in sample_idx]
                    fnames_sampled = [src_data['fnames'][i] for i in sample_idx]
                    merged_token_lines_k.extend(lines_sampled)
                    merged_fnames_k.extend(fnames_sampled)
                    valid_src_count += 1
                
                if len(merged_hand_raw_k) == 0:
                    print(f"    [Skip] K={ablation_K} 没有可用的源项目缓存")
                    continue
                
                if valid_src_count < ablation_K:
                    print(f"    [Warning] K={ablation_K} 仅使用了 {valid_src_count}/{ablation_K} 个源项目（部分缓存缺失）")
                
                train_hand_raw_k = np.vstack(merged_hand_raw_k)
                train_label_k = np.concatenate(merged_label_k)
                train_token_lines_k = merged_token_lines_k
                sample_weights_k = np.array(merged_sample_weights_k)
                
                print(f"    [Ablation] K={ablation_K} 合并后数据: {len(train_hand_raw_k)} 样本")
                
                scaler_k = QuantileTransformer(output_distribution='normal', random_state=Config.RANDOM_SEED)
                train_hand_pure_k = scaler_k.fit_transform(train_hand_raw_k)
                
                scaler_tgt_k = QuantileTransformer(output_distribution='normal', random_state=Config.RANDOM_SEED)
                test_hand_pure_k = scaler_tgt_k.fit_transform(target_data['hand_raw'])
                
                test_label_eval_k = target_data['label_orig']
                
                rf_hand_pure_k = RandomForestClassifier(
                    n_estimators=500, max_depth=15, min_samples_split=5,
                    max_features='sqrt', class_weight=None, n_jobs=-1,
                    random_state=Config.RANDOM_SEED
                )
                rf_hand_pure_k.fit(train_hand_pure_k, train_label_k, sample_weight=sample_weights_k)
                
                y_prob_hand_k = rf_hand_pure_k.predict_proba(test_hand_pure_k)[:, 1]
                y_prob_hand_k_ranked = rankdata(y_prob_hand_k) / len(y_prob_hand_k)
                res_hand_k = evaluate_paper(test_label_eval_k, y_prob_hand_k_ranked, threshold=0.44, loc=test_proj)
                
                print(f"    [Ablation] K={ablation_K} Hand: MCC={res_hand_k['MCC']:.4f}  AUC={res_hand_k['AUC']:.4f}")
                
                source_count_results[ablation_K].append({
                    'test_proj': test_proj,
                    'K': ablation_K,
                    'MCC': res_hand_k['MCC'],
                    'AUC': res_hand_k['AUC'],
                    'BACC': res_hand_k['BalancedAccuracy'],
                    'F1': res_hand_k['F1'],
                })
            
            # ================================================================
            # 主路线：使用 K=3
            # ================================================================
            K = 3  # 可调参数
            selected = src_weight_list[:K]
            weights = [w for _, _, w in selected]

            print(f"\n  [MASTER] Selected sources with weights (K={K}):")
            for proj, _, w in selected:
                print(f"    - {proj}: weight={w:.4f}")

            # ------------------------------------------------------------
            # 按权重比例合并数据（加权采样）
            # ------------------------------------------------------------
            # 注意：不重新计算 n_per_source，直接使用缓存的 sample_idx 长度

            merged_hand_raw = []
            merged_token_lines = []
            merged_fnames = []
            merged_label = []
            merged_sample_weights = []

            # 创建采样索引缓存目录
            sample_cache_dir = "/public/home/zhangzihao2025/TGNN/cache/sample_history"
            os.makedirs(sample_cache_dir, exist_ok=True)

            for src_proj, src_data, w in selected:
                # 直接加载现有的采样索引缓存
                import glob
                existing_sample_files = glob.glob(os.path.join(sample_cache_dir, f"{src_proj}_{test_proj}_idx_*.npy"))
                if existing_sample_files:
                    # 按时间戳排序，取最新的
                    existing_sample_files.sort(key=lambda x: int(x.split('_')[-1].replace('.npy', '')), reverse=True)
                    latest_sample = existing_sample_files[0]
                    print(f"  [Cache] 加载采样索引缓存: {latest_sample}")
                    sample_idx = np.load(latest_sample)
                    print(f"  [DEBUG] sample_idx 长度: {len(sample_idx)}")  # 调试输出
                else:
                    print(f"  [Error] 未找到 {src_proj}_{test_proj} 的采样索引缓存，跳过此源项目")
                    continue
                
                merged_hand_raw.append(src_data['hand_raw'][sample_idx])
                merged_label.append(src_data['label_orig'][sample_idx])
                merged_sample_weights.extend([w] * len(sample_idx))
                # 同步采样 token_lines 和 fnames
                lines_sampled = [src_data['token_lines'][i] for i in sample_idx]
                fnames_sampled = [src_data['fnames'][i] for i in sample_idx]
                merged_token_lines.extend(lines_sampled)
                merged_fnames.extend(fnames_sampled)

            # 合并数组
            train_hand_raw = np.vstack(merged_hand_raw)
            train_label = np.concatenate(merged_label)
            train_token_lines = merged_token_lines
            sample_weights = np.array(merged_sample_weights)

            print(f"  [MASTER] 合并后原始数据: {len(train_hand_raw)} 样本")
            # 使用缓存的实际长度
            actual_counts = []
            for src_proj, src_data, w in selected:
                import glob
                existing_sample_files = glob.glob(os.path.join(sample_cache_dir, f"{src_proj}_{test_proj}_idx_*.npy"))
                if existing_sample_files:
                    sample_idx = np.load(existing_sample_files[0])
                    actual_counts.append((src_proj, len(sample_idx)))
            print(f"  [MASTER] 各源项目采样数(来自缓存): {actual_counts}")

            # ------------------------------------------------------------
            # 统一标准化 Hand 特征（使用 QuantileTransformer）
            # ------------------------------------------------------------
            scaler = QuantileTransformer(output_distribution='normal', random_state=Config.RANDOM_SEED)
            train_hand_pure = scaler.fit_transform(train_hand_raw)

            # 目标项目的 Hand 特征独立标准化
            scaler_tgt = QuantileTransformer(output_distribution='normal', random_state=Config.RANDOM_SEED)
            test_hand_pure = scaler_tgt.fit_transform(target_data['hand_raw'])

            test_token_lines = target_data['token_lines']
            tgt_label_orig = target_data['label_orig']
            test_fnames = target_data['fnames']
            train_fnames = merged_fnames

            # ================================================================
            # 标签翻转处理（根据合并后源项目缺陷率统一处理）
            # ================================================================
            src_defect_rate = train_label.mean()
            if src_defect_rate > 0.5:
                print(f"\n  ⚠️ 合并后源项目缺陷率={src_defect_rate:.1%}(>50%), 执行标签翻转(缺陷<->正常)")
                train_label = 1 - train_label
                test_label_eval = 1 - tgt_label_orig  # 对目标也做相同翻转
                print(f"  翻转后源项目缺陷率={train_label.mean():.1%}")
            else:
                print(f"\n  ✓ 合并后源项目缺陷率={src_defect_rate:.1%}(≤50%), 无需翻转")
                test_label_eval = tgt_label_orig

            # 保存样本权重（用于加权训练）
            train_sample_weights = sample_weights.copy()

            # ================================================================
            # 类不平衡处理：叠加类别权重到 MASTER 权重
            # ================================================================
            # 计算正负类数量
            pos_count = np.sum(train_label == 1)
            neg_count = np.sum(train_label == 0)
            
            # 确定少数类并计算权重放大倍数
            if pos_count < neg_count:
                # 缺陷是少数类
                pos_weight = neg_count / pos_count
                class_weights = np.where(train_label == 1, pos_weight, 1.0)
                print(f"  [类平衡] 缺陷类权重放大 {pos_weight:.2f} 倍")
            else:
                # 干净是少数类（罕见，但也处理）
                neg_weight = pos_count / neg_count
                class_weights = np.where(train_label == 0, neg_weight, 1.0)
                print(f"  [类平衡] 干净类权重放大 {neg_weight:.2f} 倍")
            
            # 叠加到 MASTER 权重上
            final_sample_weights = train_sample_weights * class_weights
            # 归一化，使平均权重为 1（避免学习率敏感）
            final_sample_weights = final_sample_weights / final_sample_weights.mean()

            # ================================================================
            # Step 2. 提取测试集的 LOC 信息
            # ================================================================
            test_csv = f"/public/home/zhangzihao2025/TGNN/data/csvs/{test_proj}.csv"
            test_loc = extract_loc_from_csv(test_csv, test_fnames)
            if test_loc is not None:
                print(f"  [LOC] 成功提取 {len(test_loc)} 个文件的 LOC 信息, 总代码行: {test_loc.sum():.0f}")

            # ================================================================
            # Step 3. 初始AST 图构建器
            # ================================================================
            print("\n[Step 3] Initializing AST Graph Builder (tree-sitter)...")
            # 根据目标项目名推断语言(默认Java, 常见Java 开源项目数据集)
            lang = 'python' if any(
                kw in test_proj.lower() for kw in ['django', 'flask', 'numpy', 'scipy']
            ) else 'java'

            builder = ASTGraphBuilder(
                language=lang,
                line_win=Config.LINE_DEF_LINE_WIN,
                max_nodes=6000,
            )
            print(f"  [ASTGraphBuilder] 语言={lang}, "
                  f"节点特征维度={NODE_FEAT_DIM}(嵌入{EMBED_DIM}d + 结构{STRUCT_DIM}d), "
                  f"词汇表={VOCAB_SIZE} 类型")

            # ================================================================
            # Step 3.5. 专家 RF(用于自适应先验, 不参与 GNN 训练
            # ================================================================
            print("\n[Step 3.5] Expert RF for Adaptive Prior...")
            expert_rf = RandomForestClassifier(
                n_estimators=300, max_depth=15, min_samples_split=5,
                max_features='sqrt', class_weight='balanced',
                n_jobs=-1, random_state=Config.RANDOM_SEED
            )
            expert_rf.fit(train_hand_pure, train_label)
            target_expert_probs = expert_rf.predict_proba(test_hand_pure)[:, 1]
            print("  [Expert RF] 已生成目标域先验概率。")

            # ================================================================
            # [Step4-disabled] Step 4. 预训GNN(CORAL 域对齐)
            # ================================================================
            # print("\n[Step 4] Pre-training GNN (AST + CORAL)...")
            # model_ld = LineDefGCNAtt(
            #     vocab_size=VOCAB_SIZE,
            #     embed_dim=EMBED_DIM,
            #     struct_dim=STRUCT_DIM,
            #     hidden_channels=Config.LINE_DEF_HIDDEN,
            #     out_channels=64,
            #     dropout=Config.DROPOUT,
            # ).to(DEVICE)

            # model_ld = pretrain_gnn(
            #     model_ld,
            #     train_token_lines, train_label,
            #     builder, DEVICE,
            #     epochs=Config.EPOCHS,
            #     patience=12,
            #     focal_gamma=2.0,
            #     focal_alpha_mode='auto',
            #     use_center=False,
            #     center_weight=0.0,
            #     use_margin=False,
            #     margin_weight=0.0,
            #     margin=0.0,
            # )
            # model_ld.eval()

            # ================================================================
            # Step 4b. 预训练 GNN (Focal Loss 调优: gamma=3, alpha=auto)
            # ================================================================
            print("\n[Step 4b] Pre-training GNN (Focal Loss gamma=3, alpha=auto)...")
            
            # 检查是否存在 GNN 预训练模型权重缓存
            gnn_model_cache_dir = "/public/home/zhangzihao2025/TGNN/cache/model_weights"
            gnn_model_cache_path = os.path.join(gnn_model_cache_dir, f"{test_proj}_gnn_pretrain.pth")
            
            if test_proj == 'xalan-2.6' and os.path.exists(gnn_model_cache_path):
                # 加载缓存的模型权重
                print(f"  [Cache] 加载 GNN 预训练模型权重: {gnn_model_cache_path}")
                model_ld_focal = LineDefGCNAtt(
                    vocab_size=VOCAB_SIZE,
                    embed_dim=EMBED_DIM,
                    struct_dim=STRUCT_DIM,
                    hidden_channels=Config.LINE_DEF_HIDDEN,
                    out_channels=64,
                    dropout=Config.DROPOUT,
                ).to(DEVICE)
                
                wrapper_focal = GNNWrapper(model_ld_focal).to(DEVICE)
                
                checkpoint = torch.load(gnn_model_cache_path)
                wrapper_focal.gnn.load_state_dict(checkpoint['gnn_state_dict'])
                wrapper_focal.classifier.load_state_dict(checkpoint['classifier_state_dict'])
                
                wrapper_focal.eval()
                model_ld_focal = wrapper_focal.gnn
                model_ld_focal.eval()
            else:
                # 训练新的模型
                model_ld_focal = LineDefGCNAtt(
                    vocab_size=VOCAB_SIZE,
                    embed_dim=EMBED_DIM,
                    struct_dim=STRUCT_DIM,
                    hidden_channels=Config.LINE_DEF_HIDDEN,
                    out_channels=64,
                    dropout=Config.DROPOUT,
                ).to(DEVICE)

                wrapper_focal = pretrain_gnn(
                    model_ld_focal,
                    train_token_lines, train_label,
                    builder, DEVICE,
                    test_proj=test_proj,  # 添加项目名称
                    epochs=50,
                    patience=0,
                    focal_gamma=3.0,
                    focal_alpha_mode='auto',
                    use_center=True,
                    center_weight=0.05,
                    use_margin=True,
                    margin_weight=0.8,
                    margin=0.5,
                    sample_weights=final_sample_weights,   # 使用叠加类别权重后的最终权重
                )
                wrapper_focal.eval()
                # 从 wrapper 中提取 GNN 模型和 classifier
                model_ld_focal = wrapper_focal.gnn
                model_ld_focal.eval()
                
                # # 保存 GNN 预训练模型权重（已禁用）
                # os.makedirs(gnn_model_cache_dir, exist_ok=True)
                # torch.save({
                #     'gnn_state_dict': model_ld_focal.state_dict(),
                #     'classifier_state_dict': wrapper_focal.classifier.state_dict(),
                # }, gnn_model_cache_path)
                # print(f"  [Cache] 保存 GNN 预训练模型权重: {gnn_model_cache_path}")

            # ================================================================
            # Step 5. 提取 GNN 特征
            # ================================================================
            print("\n[Step 5] Extracting GNN Features (AST-based)...")
            # [Step4-disabled] train_deep = get_file_vecs(model_ld, train_token_lines, builder, DEVICE)
            # [Step4-disabled] test_deep  = get_file_vecs(model_ld, test_token_lines,  builder, DEVICE)

            train_deep_focal = get_file_vecs(model_ld_focal, train_token_lines, builder, DEVICE)
            test_deep_focal  = get_file_vecs(model_ld_focal, test_token_lines,  builder, DEVICE)

            # [Step4-disabled] train_deep = np.nan_to_num(train_deep)
            # [Step4-disabled] test_deep  = np.nan_to_num(test_deep)
            train_deep_focal = np.nan_to_num(train_deep_focal)
            test_deep_focal  = np.nan_to_num(test_deep_focal)

            # [Step4-disabled] print(f"  GNN 特征维度: {train_deep.shape[1]}, 训练集={len(train_deep)}, 测试集={len(test_deep)}")
            print(f"  GNN-Focal 特征维度: {train_deep_focal.shape[1]}, 训练集={len(train_deep_focal)}, 测试集={len(test_deep_focal)}")

            # ================================================================
            # [Exp 0.1] GNN 对比路线：不使用结构位置编码
            # ================================================================
            print("\n[Exp 0.1] GNN 对比路线：不使用结构位置编码...")

            model_ld_nopos = LineDefGCNAtt(
                vocab_size=VOCAB_SIZE,
                embed_dim=EMBED_DIM,
                struct_dim=STRUCT_DIM,
                hidden_channels=Config.LINE_DEF_HIDDEN,
                out_channels=64,
                dropout=Config.DROPOUT,
                use_struct_pos_encoding=False,  # 关键：禁用结构位置编码
            ).to(DEVICE)

            wrapper_nopos = pretrain_gnn(
                model_ld_nopos,
                train_token_lines, train_label,
                builder, DEVICE,
                test_proj=test_proj,
                epochs=50,
                patience=0,
                focal_gamma=3.0,
                focal_alpha_mode='auto',
                use_center=True,
                center_weight=0.05,
                use_margin=True,
                margin_weight=0.8,
                margin=0.5,
                sample_weights=final_sample_weights,
            )
            wrapper_nopos.eval()
            model_ld_nopos = wrapper_nopos.gnn
            model_ld_nopos.eval()

            # 提取不使用结构位置编码的 GNN 特征
            train_deep_nopos = get_file_vecs(model_ld_nopos, train_token_lines, builder, DEVICE)
            test_deep_nopos  = get_file_vecs(model_ld_nopos, test_token_lines,  builder, DEVICE)
            train_deep_nopos = np.nan_to_num(train_deep_nopos)
            test_deep_nopos  = np.nan_to_num(test_deep_nopos)
            print(f"  GNN-NoPos 特征维度: {train_deep_nopos.shape[1]}, 训练集={len(train_deep_nopos)}, 测试集={len(test_deep_nopos)}")

            # 获取不使用结构位置编码的 GNN 预测概率
            train_gnn_nopos_probs_raw = wrapper_nopos.classifier(
                torch.FloatTensor(train_deep_nopos).to(DEVICE)
            ).detach().cpu().numpy().flatten()
            test_gnn_nopos_probs_raw = wrapper_nopos.classifier(
                torch.FloatTensor(test_deep_nopos).to(DEVICE)
            ).detach().cpu().numpy().flatten()

            y_prob_gnn_nopos = rankdata(test_gnn_nopos_probs_raw) / len(test_gnn_nopos_probs_raw)
            tgt_risk_gnn_nopos = y_prob_gnn_nopos.mean()
            src_prior_nopos = train_label.mean()
            adap_gnn_nopos = min(0.3 * src_prior_nopos + 0.7 * tgt_risk_gnn_nopos, 0.5) * 0.9
            abs_thr_gnn_nopos = 1.0 - adap_gnn_nopos
            res_gnn_nopos = evaluate_paper(test_label_eval, y_prob_gnn_nopos, threshold=0.44, loc=test_loc)
            print(f"  GNN(AST, NoPos): MCC={res_gnn_nopos['MCC']:.4f}  AUC={res_gnn_nopos['AUC']:.4f}  F1={res_gnn_nopos['F1']:.4f}")

            # ================================================================
            # [Exp 0.2] GNN 对比路线：不使用类不平衡技术
            # ================================================================
            print("\n[Exp 0.2] GNN 对比路线：不使用类不平衡技术...")

            model_ld_noimb = LineDefGCNAtt(
                vocab_size=VOCAB_SIZE,
                embed_dim=EMBED_DIM,
                struct_dim=STRUCT_DIM,
                hidden_channels=Config.LINE_DEF_HIDDEN,
                out_channels=64,
                dropout=Config.DROPOUT,
            ).to(DEVICE)

            wrapper_noimb = pretrain_gnn(
                model_ld_noimb,
                train_token_lines, train_label,
                builder, DEVICE,
                test_proj=test_proj,
                epochs=50,
                patience=0,
                focal_gamma=0.0,           # 关键：禁用 Focal Loss（gamma=0 退化为普通 BCE）
                focal_alpha_mode='fixed',   # 使用固定 alpha=0.5（即不使用动态 alpha）
                use_center=True,
                center_weight=0.05,
                use_margin=True,
                margin_weight=0.8,
                margin=0.5,
                sample_weights=None,        # 关键：不使用样本权重（包括 MASTER 和类别权重）
            )
            wrapper_noimb.eval()
            model_ld_noimb = wrapper_noimb.gnn
            model_ld_noimb.eval()

            # 提取不使用类不平衡技术的 GNN 特征
            train_deep_noimb = get_file_vecs(model_ld_noimb, train_token_lines, builder, DEVICE)
            test_deep_noimb  = get_file_vecs(model_ld_noimb, test_token_lines,  builder, DEVICE)
            train_deep_noimb = np.nan_to_num(train_deep_noimb)
            test_deep_noimb  = np.nan_to_num(test_deep_noimb)
            print(f"  GNN-NoImb 特征维度: {train_deep_noimb.shape[1]}, 训练集={len(train_deep_noimb)}, 测试集={len(test_deep_noimb)}")

            # 获取不使用类不平衡技术的 GNN 预测概率
            train_gnn_noimb_probs_raw = wrapper_noimb.classifier(
                torch.FloatTensor(train_deep_noimb).to(DEVICE)
            ).detach().cpu().numpy().flatten()
            test_gnn_noimb_probs_raw = wrapper_noimb.classifier(
                torch.FloatTensor(test_deep_noimb).to(DEVICE)
            ).detach().cpu().numpy().flatten()

            y_prob_gnn_noimb = rankdata(test_gnn_noimb_probs_raw) / len(test_gnn_noimb_probs_raw)
            tgt_risk_gnn_noimb = y_prob_gnn_noimb.mean()
            src_prior_noimb = train_label.mean()
            adap_gnn_noimb = min(0.3 * src_prior_noimb + 0.7 * tgt_risk_gnn_noimb, 0.5) * 0.9
            abs_thr_gnn_noimb = 1.0 - adap_gnn_noimb
            res_gnn_noimb = evaluate_paper(test_label_eval, y_prob_gnn_noimb, threshold=0.46, loc=test_loc)
            print(f"  GNN(AST, NoImb): MCC={res_gnn_noimb['MCC']:.4f}  AUC={res_gnn_noimb['AUC']:.4f}  F1={res_gnn_noimb['F1']:.4f}")

            # ================================================================
            # [Exp 0.3] GNN 对比路线：不使用 Center 和 Margin 技术
            # ================================================================
            print("\n[Exp 0.3] GNN 对比路线：不使用 Center 和 Margin 技术...")

            model_ld_nocm = LineDefGCNAtt(
                vocab_size=VOCAB_SIZE,
                embed_dim=EMBED_DIM,
                struct_dim=STRUCT_DIM,
                hidden_channels=Config.LINE_DEF_HIDDEN,
                out_channels=64,
                dropout=Config.DROPOUT,
            ).to(DEVICE)

            wrapper_nocm = pretrain_gnn(
                model_ld_nocm,
                train_token_lines, train_label,
                builder, DEVICE,
                test_proj=test_proj,
                epochs=50,
                patience=0,
                focal_gamma=3.0,
                focal_alpha_mode='auto',
                use_center=False,           # 关键：禁用 Center Loss
                center_weight=0.0,
                use_margin=False,           # 关键：禁用 Margin Loss
                margin_weight=0.0,
                margin=0.0,
                sample_weights=final_sample_weights,
            )
            wrapper_nocm.eval()
            model_ld_nocm = wrapper_nocm.gnn
            model_ld_nocm.eval()

            # 提取不使用 Center 和 Margin 技术的 GNN 特征
            train_deep_nocm = get_file_vecs(model_ld_nocm, train_token_lines, builder, DEVICE)
            test_deep_nocm  = get_file_vecs(model_ld_nocm, test_token_lines,  builder, DEVICE)
            train_deep_nocm = np.nan_to_num(train_deep_nocm)
            test_deep_nocm  = np.nan_to_num(test_deep_nocm)
            print(f"  GNN-NoCM 特征维度: {train_deep_nocm.shape[1]}, 训练集={len(train_deep_nocm)}, 测试集={len(test_deep_nocm)}")

            # 获取不使用 Center 和 Margin 技术的 GNN 预测概率
            train_gnn_nocm_probs_raw = wrapper_nocm.classifier(
                torch.FloatTensor(train_deep_nocm).to(DEVICE)
            ).detach().cpu().numpy().flatten()
            test_gnn_nocm_probs_raw = wrapper_nocm.classifier(
                torch.FloatTensor(test_deep_nocm).to(DEVICE)
            ).detach().cpu().numpy().flatten()

            y_prob_gnn_nocm = rankdata(test_gnn_nocm_probs_raw) / len(test_gnn_nocm_probs_raw)
            tgt_risk_gnn_nocm = y_prob_gnn_nocm.mean()
            src_prior_nocm = train_label.mean()
            adap_gnn_nocm = min(0.3 * src_prior_nocm + 0.7 * tgt_risk_gnn_nocm, 0.5) * 0.9
            abs_thr_gnn_nocm = 1.0 - adap_gnn_nocm
            res_gnn_nocm = evaluate_paper(test_label_eval, y_prob_gnn_nocm, threshold=0.44, loc=test_loc)
            print(f"  GNN(AST, NoCM): MCC={res_gnn_nocm['MCC']:.4f}  AUC={res_gnn_nocm['AUC']:.4f}  F1={res_gnn_nocm['F1']:.4f}")

            # ================================================================
            # Step 6. 消融实验
            # ================================================================
            print("\n" + "=" * 60)
            print("  SimCom++ Ablation Experiments")
            print("=" * 60)

            from imblearn.under_sampling import RandomUnderSampler

            # ---- Exp 1: Hand-only Baseline (RF, 无 MPOS) ----
            print("\n[Exp 1] Hand-only Baseline (RF, 无 MPOS)...")

            # RF, 无 MPOS 增强（使用样本权重进行 MASTER 加权训练）
            rf_hand_pure = RandomForestClassifier(
                n_estimators=500,
                max_depth=15,
                min_samples_split=5,
                max_features='sqrt',
                class_weight=None,   # 必须为 None，因为我们已经手动加权
                n_jobs=-1,
                random_state=Config.RANDOM_SEED
            )
            
            # 检查是否存在 RF 模型权重缓存
            rf_model_cache_dir = "/public/home/zhangzihao2025/TGNN/cache/model_weights"
            rf_model_cache_path = os.path.join(rf_model_cache_dir, f"{test_proj}_rf_hand_pure.pkl")
            
            if test_proj == 'xalan-2.6' and os.path.exists(rf_model_cache_path):
                # 加载缓存的模型权重
                print(f"  [Cache] 加载 RF 模型权重: {rf_model_cache_path}")
                import joblib
                rf_hand_pure = joblib.load(rf_model_cache_path)
            else:
                # 训练新的模型
                rf_hand_pure.fit(train_hand_pure, train_label, sample_weight=final_sample_weights)
                
                # 保存 RF 模型权重
                # # 保存 RF 模型权重（已禁用）
                # os.makedirs(rf_model_cache_dir, exist_ok=True)
                # import joblib
                # joblib.dump(rf_hand_pure, rf_model_cache_path)
                # print(f"  [Cache] 保存 RF 模型权重: {rf_model_cache_path}")
            # # 保存 RF 模型权重（已禁用，重复代码）
            # joblib.dump(rf_hand_pure, rf_model_cache_path)
            # print(f"  [Cache] 保存 RF 模型权重: {rf_model_cache_path}")

            # 计算自适应阈值
            src_prior = train_label.mean()
            tgt_risk = rf_hand_pure.predict_proba(test_hand_pure)[:, 1].mean()
            adap_prior = min(0.3 * src_prior + 0.7 * tgt_risk, 0.5) * 0.8
            abs_thresh = 1.0 - adap_prior

            y_prob_hand_raw = rf_hand_pure.predict_proba(test_hand_pure)[:, 1]
            y_prob_hand     = rankdata(y_prob_hand_raw) / len(y_prob_hand_raw)
            res_hand = evaluate_paper(test_label_eval, y_prob_hand, threshold=0.42, loc=test_loc)
            print(f"  RF-Hand (MPOS): MCC={res_hand['MCC']:.4f}  AUC={res_hand['AUC']:.4f}")
            
            # 收集 K=3（主路线）的消融实验数据
            source_count_results[3].append({
                'test_proj': test_proj,
                'K': 3,
                'MCC': res_hand['MCC'],
                'AUC': res_hand['AUC'],
                'BACC': res_hand['BalancedAccuracy'],
                'F1': res_hand['F1'],
            })

            # ---- Exp 1.2: Hand + RF (去除 MPOS) ----
            print("\n[Exp 1.2] Hand + RF (无 MPOS)...")

            # RF (无 MPOS，只使用 MASTER 样本权重，不使用类别权重)
            rf_hand_mpos = RandomForestClassifier(
                n_estimators=500,
                max_depth=15,
                min_samples_split=5,
                max_features='sqrt',
                class_weight=None,
                n_jobs=-1,
                random_state=Config.RANDOM_SEED
            )
            # 只使用 MASTER 权重，不叠加类别权重
            master_weights_only = train_sample_weights / train_sample_weights.mean()
            rf_hand_mpos.fit(train_hand_pure, train_label, sample_weight=master_weights_only)

            # 计算自适应阈值
            tgt_risk_mpos = rf_hand_mpos.predict_proba(test_hand_pure)[:, 1].mean()
            adap_prior_mpos = min(0.3 * src_prior + 0.7 * tgt_risk_mpos, 0.5) * 0.8
            abs_thresh_mpos = 1.0 - adap_prior_mpos

            y_prob_hand_mpos_raw = rf_hand_mpos.predict_proba(test_hand_pure)[:, 1]
            y_prob_hand_mpos     = rankdata(y_prob_hand_mpos_raw) / len(y_prob_hand_mpos_raw)
            res_hand_mpos = evaluate_paper(test_label_eval, y_prob_hand_mpos, threshold=0.45, loc=test_loc)
            print(f"  RF-Hand+MPOS: MCC={res_hand_mpos['MCC']:.4f}  AUC={res_hand_mpos['AUC']:.4f}")

            # 统一命名, 下SimCom++ / DynamicFusion / GMF+Hand 都使用加权RF
            mlp_hand_mpos = rf_hand_pure

            # [Exp2-disabled] # ---- Exp 2: GNN-only (无任何抗领域漂移技术) ----
            # [Exp2-disabled] print("\n[Exp 2] GNN-only Baseline (AST-GNN, 无 MPOS, 无领域对齐)...")
            # [Exp2-disabled] mlp_gnn = MLPClassifierWrapper(
            # [Exp2-disabled]     input_dim=train_deep.shape[1], hidden_dim=64,
            # [Exp2-disabled]     dropout=0.2, lr=0.001, epochs=50, batch_size=32, device=DEVICE
            # [Exp2-disabled] )
            # [Exp2-disabled] mlp_gnn.fit(train_deep, train_label)

            # [Exp2-disabled] tgt_risk_gnn_mpos = mlp_gnn.predict_proba(test_deep)[:, 1].mean()
            # [Exp2-disabled] adap_gnn_mpos = min(0.3 * src_prior + 0.7 * tgt_risk_gnn_mpos, 0.5) * 0.9
            # [Exp2-disabled] abs_thr_gnn_mpos = 1.0 - adap_gnn_mpos

            # [Exp2-disabled] y_prob_gnn_raw = mlp_gnn.predict_proba(test_deep)[:, 1]
            # [Exp2-disabled] y_prob_gnn     = rankdata(y_prob_gnn_raw) / len(y_prob_gnn_raw)
            # [Exp2-disabled] res_gnn = evaluate_paper(test_label_eval, y_prob_gnn, threshold=abs_thr_gnn_mpos, loc=test_loc)
            # [Exp2-disabled] print(f"  GNN(AST): MCC={res_gnn['MCC']:.4f}  AUC={res_gnn['AUC']:.4f}")

            # ---- Exp 2.2: GNN-only (直接使用预训练模型，无MLP分类器) ----
            print("\n[Exp 2.2] GNN-only (直接使用预训练模型，无MLP分类器)...")
            
            # 直接从预训练的 wrapper 获取预测概率（不经过 MLP）
            def get_gnn_raw_probs(wrapper, token_lines_list, builder, device):
                wrapper.eval()
                probs = []
                for file_lines in token_lines_list:
                    if not file_lines:
                        file_lines = ['// empty']
                    tok_data, _, _ = builder.build_one(file_lines)
                    tok_batch = Batch.from_data_list([tok_data]).to(device)
                    with torch.no_grad():
                        logits, _ = wrapper(tok_batch)
                        prob = torch.sigmoid(logits).cpu().numpy()
                    probs.append(prob)
                return np.vstack(probs).flatten()

            # 获取训练集和测试集的原始GNN概率
            train_gnn_raw_probs = get_gnn_raw_probs(wrapper_focal, train_token_lines, builder, DEVICE)
            y_prob_gnn_focal_raw = get_gnn_raw_probs(wrapper_focal, test_token_lines, builder, DEVICE)

            # 计算自适应阈值
            tgt_risk_gnn_focal = y_prob_gnn_focal_raw.mean()
            adap_gnn_focal = min(0.3 * src_prior + 0.7 * tgt_risk_gnn_focal, 0.5) * 0.9
            abs_thr_gnn_focal = 1.0 - adap_gnn_focal

            y_prob_gnn_focal = rankdata(y_prob_gnn_focal_raw) / len(y_prob_gnn_focal_raw)
            res_gnn_focal = evaluate_paper(test_label_eval, y_prob_gnn_focal, threshold=0.44, loc=test_loc)
            print(f"  GNN(AST, 预训练直接预测): MCC={res_gnn_focal['MCC']:.4f}  AUC={res_gnn_focal['AUC']:.4f}  F1={res_gnn_focal['F1']:.4f}")
            # [Exp2-disabled] print(f"    对比: GNN(AST, Baseline): MCC={res_gnn['MCC']:.4f}  AUC={res_gnn['AUC']:.4f}  F1={res_gnn['F1']:.4f}")

            # ================================================================
            # [Exp3-disabled] # ================================================================
            # [Exp3-disabled] # Exp 3. 最SimCom++ (基于预测熵的实例级动态融
            # [Exp3-disabled] # ================================================================
            # [Exp3-disabled] print("\n[Exp 3] SimCom++ (基于预测熵的实例级动态融...")

            # [Exp3-disabled] model_simcom = SimComPlusPlus(
            # [Exp3-disabled]     sim_params={
            # [Exp3-disabled]         'n_estimators': 500, 'max_depth': 20, 'min_samples_split': 5,
            # [Exp3-disabled]         'max_features': 'sqrt', 'class_weight': None,
            # [Exp3-disabled]         'n_jobs': -1, 'random_state': Config.RANDOM_SEED
            # [Exp3-disabled]     },
            # [Exp3-disabled]     com_params={
            # [Exp3-disabled]         'n_estimators': 500, 'max_depth': 20, 'min_samples_split': 5,
            # [Exp3-disabled]         'max_features': 'sqrt', 'class_weight': None,
            # [Exp3-disabled]         'n_jobs': -1, 'random_state': Config.RANDOM_SEED
            # [Exp3-disabled]     },
            # [Exp3-disabled]     gmf_hidden=64, gmf_dropout=0.6, gmf_epochs=40,
            # [Exp3-disabled]     gmf_lr=0.001, gmf_batch_size=32,
            # [Exp3-disabled]     use_mpos=True, use_mpos_in_fusion=True, use_mpos_in_gmf=True,
            # [Exp3-disabled]     use_simple_fusion=False,
            # [Exp3-disabled]     device=DEVICE, random_state=Config.RANDOM_SEED
            # [Exp3-disabled] )

            # [Exp3-disabled] model_simcom.fit(
            # [Exp3-disabled]     train_hand_pure, train_deep_focal, train_label,
            # [Exp3-disabled]     target_hand=test_hand_pure, target_gnn=test_deep_focal
            # [Exp3-disabled] )

            # [Exp3-disabled] def _ext_hand_prob(hf): return mlp_hand_mpos.predict_proba(hf)[:, 1]
            # [Exp3-disabled] model_simcom.external_hand_prob_func = _ext_hand_prob
            # [Exp3-disabled] model_simcom.external_hand_model = mlp_hand_mpos

            # [Exp3-disabled] def _ext_gnn_prob(gf): return mlp_gnn_focal.predict_proba(gf)[:, 1]
            # [Exp3-disabled] model_simcom.external_gnn_prob_func = _ext_gnn_prob
            # [Exp3-disabled] model_simcom.external_gnn_model = mlp_gnn_focal

            # [Exp3-disabled] y_prob, comp = model_simcom.predict_proba(
            # [Exp3-disabled]     test_hand_pure, test_deep_focal,
            # [Exp3-disabled]     prior_hand=1.0, prior_gnn=0.7, prior_gmf=1.3,
            # [Exp3-disabled]     tau_hard=0.80, tau_soft=0.65
            # [Exp3-disabled] )
            # [Exp3-disabled] gnn_active_rate = float(comp.get('gnn_active', 0.0))

            # [Exp3-disabled] # 目标域自适应截断阈
            # [Exp3-disabled] tgt_risk3  = mlp_hand_mpos.predict_proba(test_hand_pure)[:, 1].mean()
            # [Exp3-disabled] adap3      = min(0.3 * src_prior + 0.7 * tgt_risk3, 0.5) * 0.9
            # [Exp3-disabled] abs_thr3   = 1.0 - adap3
            # [Exp3-disabled] print(f"  [Adaptive Prior] 目标域预估缺陷率={adap3:.1%} 截断阈{abs_thr3:.4f}")

            # [Exp3-disabled] # AUC 诊断: 定位瓶
            # [Exp3-disabled] from sklearn.metrics import roc_auc_score
            # [Exp3-disabled] try:
            # [Exp3-disabled]     auc_raw_gmf = roc_auc_score(test_label, comp['prob_gmf'])
            # [Exp3-disabled]     auc_rank_gmf = roc_auc_score(test_label, rank_normalize(comp['prob_gmf']))
            # [Exp3-disabled]     auc_final = roc_auc_score(test_label, y_prob)
            # [Exp3-disabled]     print(f"  [AUC诊断] raw_gmf={auc_raw_gmf:.4f}  rank_norm(raw_gmf)={auc_rank_gmf:.4f}  final_prob={auc_final:.4f}")
            # [Exp3-disabled] except Exception as e:
            # [Exp3-disabled]     print(f"  [AUC诊断] 计算失败: {e}")

            # [Exp3-disabled] # 🌟 评估真正SimCom++
            # [Exp3-disabled] res = evaluate_paper(test_label_eval, y_prob, threshold=abs_thr3, loc=test_loc)

            # [Exp3-disabled] # 评估内部单分(必须使用 rank_normalize 对齐尺度才能y_prob 对比)
            # [Exp3-disabled] prob_sim_norm = rank_normalize(comp['prob_sim'])
            # [Exp3-disabled] prob_gmf_norm = rank_normalize(comp['prob_gmf'])
            # [Exp3-disabled] res_sim_int = evaluate_paper(test_label_eval, prob_sim_norm, threshold=abs_thr3, loc=test_loc)
            # [Exp3-disabled] res_gmf     = evaluate_paper(test_label_eval, prob_gmf_norm, threshold=abs_thr3, loc=test_loc)

            # [Exp3-disabled] print(f"    Sim(internal): MCC={res_sim_int['MCC']:.4f}  AUC={res_sim_int['AUC']:.4f}")
            # [Exp3-disabled] print(f"    GMF-only:      MCC={res_gmf['MCC']:.4f}  AUC={res_gmf['AUC']:.4f}")
            # [Exp3-disabled] print(f"    🌟 SimCom++ (动态熵): MCC={res['MCC']:.4f}  BAcc={res['BalancedAccuracy']:.4f}  AUC={res['AUC']:.4f}")

            # ================================================================
            # Exp 3.12. GMF with Hand-only MPOS (GNN 特征用 KNN 邻居复制)
            # ================================================================
            print("\n[Exp 3.12] GMF (Master Weighted)...")

            model_simcom_handmpos = SimComPlusPlus(
                sim_params={
                    'n_estimators': 500, 'max_depth': 20, 'min_samples_split': 5,
                    'max_features': 'sqrt', 'class_weight': None,
                    'n_jobs': -1, 'random_state': Config.RANDOM_SEED
                },
                com_params={
                    'n_estimators': 500, 'max_depth': 20, 'min_samples_split': 5,
                    'max_features': 'sqrt', 'class_weight': None,
                    'n_jobs': -1, 'random_state': Config.RANDOM_SEED
                },
                gmf_hidden=64, gmf_dropout=0.6, gmf_epochs=40,
                gmf_lr=0.001, gmf_batch_size=32,
                use_mpos=False, mpos_k=5, mpos_ratio=1.0,
                use_mpos_in_fusion=False, use_mpos_in_gmf=False,
                use_mpos_hand_only=False,
                use_simple_fusion=False,
                device=DEVICE, random_state=Config.RANDOM_SEED
            )

            # 检查是否存在 GMF 模型权重缓存（仅向量门控版本可用）
            gmf_model_cache_dir = "/public/home/zhangzihao2025/TGNN/cache/model_weights"
            gmf_model_cache_path = os.path.join(gmf_model_cache_dir, f"{test_proj}_gmf_model.pth")
            
            cache_available = False
            if test_proj == 'xalan-2.6' and os.path.exists(gmf_model_cache_path):
                # 先加载检查点，检测模型类型
                checkpoint = torch.load(gmf_model_cache_path)
                gate_2_weight_shape = checkpoint['gmf_state_dict']['gate.2.weight'].shape
                
                # 只有向量门控版本才能使用缓存（标量门控版本不使用缓存）
                # 向量门控：gate.2.weight 形状为 (hidden_dim, hidden_dim)，即 (64, 64)
                if gate_2_weight_shape[0] == 64:
                    cache_available = True
            
            if cache_available:
                # 加载缓存的向量门控模型权重
                print(f"  [Cache] 加载 GMF 模型权重: {gmf_model_cache_path}")
                
                from gmf_simcom import SlimGMF
                model_simcom_handmpos.gmf_model = SlimGMF(
                    hand_dim=train_hand_pure.shape[1],
                    gnn_dim=train_deep_focal.shape[1],
                    hidden_dim=64,
                    dropout=0.6
                ).to(DEVICE)
                model_simcom_handmpos.gmf_model.load_state_dict(checkpoint['gmf_state_dict'])
                model_simcom_handmpos.gmf_model.eval()
                print(f"  [Cache] 加载向量门控 GMF 模型")
            else:
                # 训练新的模型（标量门控缓存或无缓存时）
                if os.path.exists(gmf_model_cache_path) and test_proj == 'xalan-2.6':
                    print(f"  [Cache] 缓存是标量门控版本，重新训练向量门控 GMF 模型...")
                model_simcom_handmpos.fit(
                    train_hand_pure, train_deep_focal, train_label,
                    target_hand=test_hand_pure, target_gnn=test_deep_focal,
                    test_proj=test_proj  # 添加项目名称
                )
                
                # # 保存 GMF 模型权重（已禁用）
                # os.makedirs(gmf_model_cache_dir, exist_ok=True)
                # torch.save({
                #     'gmf_state_dict': model_simcom_handmpos.gmf_model.state_dict(),
                # }, gmf_model_cache_path)
                # print(f"  [Cache] 保存 GMF 模型权重: {gmf_model_cache_path}")

            def _ext_hand_prob_hmpos(hf): return rf_hand_pure.predict_proba(hf)[:, 1]
            model_simcom_handmpos.external_hand_prob_func = _ext_hand_prob_hmpos
            model_simcom_handmpos.external_hand_model = rf_hand_pure

            # 使用原始GNN概率，不经过MLP
            def _ext_gnn_prob_hmpos(gf): 
                return y_prob_gnn_focal_raw  # 使用原始GNN概率
            model_simcom_handmpos.external_gnn_prob_func = _ext_gnn_prob_hmpos
            model_simcom_handmpos.external_gnn_model = wrapper_focal  # 使用预训练wrapper

            y_prob_handmpos, comp_handmpos = model_simcom_handmpos.predict_proba(
                test_hand_pure, test_deep_focal,
                prior_hand=1.0, prior_gnn=0.7, prior_gmf=1.3,
                tau_hard=0.80, tau_soft=0.65
            )
            # 计算自适应阈值（基于 GMF 输出）
            adap3 = min(0.3 * src_prior + 0.7 * comp_handmpos['prob_gmf'].mean(), 0.5) * 0.85
            abs_thr3 = 1.0 - adap3
            prob_handmpos_norm = rank_normalize(comp_handmpos['prob_gmf'])
            res_handmpos = evaluate_paper(test_label_eval, prob_handmpos_norm, threshold=0.45, loc=test_loc)
            print(f"    🌟 GMF(HandMPOS): MCC={res_handmpos['MCC']:.4f}  AUC={res_handmpos['AUC']:.4f}  AP={res_handmpos['AP']:.4f}  F1={res_handmpos['F1']:.4f}  BAcc={res_handmpos['BalancedAccuracy']:.4f}  Port20%={res_handmpos['Port20%']:.1%}  P_opt20%={res_handmpos['P_opt20%']:.1%}  IFA={res_handmpos['IFA']:.1f}")
            # [Exp312-disabled] print(f"       对比: GMF(MPOS联合)  MCC={res_gmf['MCC']:.4f}  AUC={res_gmf['AUC']:.4f}  AP={res_gmf['AP']:.4f}  F1={res_gmf['F1']:.4f}  BAcc={res_gmf['BalancedAccuracy']:.4f}")

            # ================================================================
            # [Exp 3.12.1] GMF 对比路线：标量门控版本
            # ================================================================
            print("\n[Exp 3.12.1] GMF 对比路线：标量门控版本...")

            model_simcom_scalar = SimComPlusPlus(
                sim_params={
                    'n_estimators': 500, 'max_depth': 20, 'min_samples_split': 5,
                    'max_features': 'sqrt', 'class_weight': None,
                    'n_jobs': -1, 'random_state': Config.RANDOM_SEED
                },
                com_params={
                    'n_estimators': 500, 'max_depth': 20, 'min_samples_split': 5,
                    'max_features': 'sqrt', 'class_weight': None,
                    'n_jobs': -1, 'random_state': Config.RANDOM_SEED
                },
                gmf_hidden=64, gmf_dropout=0.6, gmf_epochs=40,
                gmf_lr=0.001, gmf_batch_size=32,
                use_mpos=False, mpos_k=5, mpos_ratio=1.0,
                use_mpos_in_fusion=False, use_mpos_in_gmf=False,
                use_mpos_hand_only=False,
                use_simple_fusion=False,
                use_scalar_gate=True,    # 关键：使用标量门控
                device=DEVICE, random_state=Config.RANDOM_SEED
            )

            model_simcom_scalar.fit(
                train_hand_pure, train_deep_focal, train_label,
                target_hand=test_hand_pure, target_gnn=test_deep_focal,
                test_proj=test_proj
            )

            def _ext_hand_prob_scalar(hf): return rf_hand_pure.predict_proba(hf)[:, 1]
            model_simcom_scalar.external_hand_prob_func = _ext_hand_prob_scalar
            model_simcom_scalar.external_hand_model = rf_hand_pure

            def _ext_gnn_prob_scalar(gf): 
                return y_prob_gnn_focal_raw
            model_simcom_scalar.external_gnn_prob_func = _ext_gnn_prob_scalar
            model_simcom_scalar.external_gnn_model = wrapper_focal

            y_prob_scalar, comp_scalar = model_simcom_scalar.predict_proba(
                test_hand_pure, test_deep_focal,
                prior_hand=1.0, prior_gnn=0.7, prior_gmf=1.3,
                tau_hard=0.80, tau_soft=0.65
            )
            prob_scalar_norm = rank_normalize(comp_scalar['prob_gmf'])
            res_handmpos_scalar = evaluate_paper(test_label_eval, prob_scalar_norm, threshold=0.45, loc=test_loc)
            print(f"    🌟 GMF(HandMPOS, ScalarGate): MCC={res_handmpos_scalar['MCC']:.4f}  AUC={res_handmpos_scalar['AUC']:.4f}  AP={res_handmpos_scalar['AP']:.4f}  F1={res_handmpos_scalar['F1']:.4f}  BAcc={res_handmpos_scalar['BalancedAccuracy']:.4f}  Port20%={res_handmpos_scalar['Port20%']:.1%}  P_opt20%={res_handmpos_scalar['P_opt20%']:.1%}  IFA={res_handmpos_scalar['IFA']:.1f}")

            # [Exp313-disabled] # ================================================================
            # [Exp313-disabled] # Exp 3.13. GMF-Fused CenterMargin (GNN分支用Center+Margin Loss, GMF融合层也加Center+Margin Loss)
            # [Exp313-disabled] # ================================================================
            # [Exp313-disabled] print("\n[Exp 3.13] GMF-Fused CenterMargin (Center+Margin Loss in GMF fusion)...")

            # [Exp313-disabled] model_simcom_cm = SimComPlusPlus(
            # [Exp313-disabled]     sim_params={
            # [Exp313-disabled]         'n_estimators': 500, 'max_depth': 20, 'min_samples_split': 5,
            # [Exp313-disabled]         'max_features': 'sqrt', 'class_weight': None,
            # [Exp313-disabled]         'n_jobs': -1, 'random_state': Config.RANDOM_SEED
            # [Exp313-disabled]     },
            # [Exp313-disabled]     com_params={
            # [Exp313-disabled]         'n_estimators': 500, 'max_depth': 20, 'min_samples_split': 5,
            # [Exp313-disabled]         'max_features': 'sqrt', 'class_weight': None,
            # [Exp313-disabled]         'n_jobs': -1, 'random_state': Config.RANDOM_SEED
            # [Exp313-disabled]     },
            # [Exp313-disabled]     gmf_hidden=64, gmf_dropout=0.6, gmf_epochs=40,
            # [Exp313-disabled]     gmf_lr=0.001, gmf_batch_size=32,
            # [Exp313-disabled]     use_mpos=True, mpos_k=5, mpos_ratio=1.0,
            # [Exp313-disabled]     use_mpos_in_fusion=False, use_mpos_in_gmf=True,
            # [Exp313-disabled]     use_mpos_hand_only=True,
            # [Exp313-disabled]     use_simple_fusion=False,
            # [Exp313-disabled]     use_center_in_gmf=True,
            # [Exp313-disabled]     use_margin_in_gmf=True,
            # [Exp313-disabled]     gmf_center_weight=0.02,
            # [Exp313-disabled]     gmf_margin_weight=0.1,
            # [Exp313-disabled]     gmf_margin=0.5,
            # [Exp313-disabled]     device=DEVICE, random_state=Config.RANDOM_SEED
            # [Exp313-disabled] )

            # [Exp313-disabled] model_simcom_cm.fit(
            # [Exp313-disabled]     train_hand_pure, train_deep_focal, train_label,
            # [Exp313-disabled]     target_hand=test_hand_pure, target_gnn=test_deep_focal
            # [Exp313-disabled] )

            # [Exp313-disabled] def _ext_hand_prob_cm(hf): return mlp_hand_mpos.predict_proba(hf)[:, 1]
            # [Exp313-disabled] model_simcom_cm.external_hand_prob_func = _ext_hand_prob_cm
            # [Exp313-disabled] model_simcom_cm.external_hand_model = mlp_hand_mpos

            # [Exp313-disabled] def _ext_gnn_prob_cm(gf): return mlp_gnn_focal.predict_proba(gf)[:, 1]
            # [Exp313-disabled] model_simcom_cm.external_gnn_prob_func = _ext_gnn_prob_cm
            # [Exp313-disabled] model_simcom_cm.external_gnn_model = mlp_gnn_focal

            # [Exp313-disabled] y_prob_cm, comp_cm = model_simcom_cm.predict_proba(
            # [Exp313-disabled]     test_hand_pure, test_deep_focal,
            # [Exp313-disabled]     prior_hand=1.0, prior_gnn=0.7, prior_gmf=1.3,
            # [Exp313-disabled]     tau_hard=0.80, tau_soft=0.65
            # [Exp313-disabled] )
            # [Exp313-disabled] prob_cm_norm = rank_normalize(comp_cm['prob_gmf'])
            # [Exp313-disabled] res_cm = evaluate_paper(test_label_eval, prob_cm_norm, threshold=abs_thr3, loc=test_loc)
            # [Exp313-disabled] print(f"    🌟 GMF-Fused CM: MCC={res_cm['MCC']:.4f}  AUC={res_cm['AUC']:.4f}  AP={res_cm['AP']:.4f}  F1={res_cm['F1']:.4f}  BAcc={res_cm['BalancedAccuracy']:.4f}  Port20%={res_cm['Port20%']:.1%}  P_opt20%={res_cm['P_opt20%']:.1%}  IFA={res_cm['IFA']:.1f}")
            # [Exp313-disabled] print(f"       对比: GMF(HandMPOS)  MCC={res_handmpos['MCC']:.4f}  AUC={res_handmpos['AUC']:.4f}")

            # ================================================================
            # Exp 3.10. Logits 标准化融- SimCom++ (三分
            # ================================================================
            print("\n[Exp 3.10] Logits 标准化融- SimCom++ (三分...")

            # 辅助函数: 概率转 logit
            def prob_to_logit(prob):
                prob = np.clip(prob, 1e-8, 1 - 1e-8)
                return np.log(prob / (1 - prob))

            # 源域训练集上计算 logits 的均值和标准
            src_prob_hand_train = mlp_hand_mpos.predict_proba(train_hand_pure)[:, 1]
            src_prob_gnn_train = train_gnn_raw_probs  # 使用原始GNN概率（无MLP）
            with torch.no_grad():
                h_t_src = torch.FloatTensor(train_hand_pure).to(DEVICE)
                g_t_src = torch.FloatTensor(train_deep_focal).to(DEVICE)
                src_prob_gmf_train_t, _, _, _ = model_simcom_handmpos.gmf_model(h_t_src, g_t_src)
            src_prob_gmf_train = src_prob_gmf_train_t.cpu().numpy()

            # logits
            logit_hand_train = prob_to_logit(src_prob_hand_train)
            logit_gnn_train = prob_to_logit(src_prob_gnn_train)
            logit_gmf_train = prob_to_logit(src_prob_gmf_train)

            # 计算均值和标准
            mu_hand, std_hand = logit_hand_train.mean(), logit_hand_train.std()
            mu_gnn, std_gnn = logit_gnn_train.mean(), logit_gnn_train.std()
            mu_gmf, std_gmf = logit_gmf_train.mean(), logit_gmf_train.std()

            # 目标域测试集
            tgt_prob_hand = mlp_hand_mpos.predict_proba(test_hand_pure)[:, 1]
            tgt_prob_gnn = y_prob_gnn_focal_raw  # 使用原始GNN概率（无MLP）
            with torch.no_grad():
                h_t_tgt = torch.FloatTensor(test_hand_pure).to(DEVICE)
                g_t_tgt = torch.FloatTensor(test_deep_focal).to(DEVICE)
                tgt_prob_gmf_t, _, _, _ = model_simcom_handmpos.gmf_model(h_t_tgt, g_t_tgt)
            tgt_prob_gmf = tgt_prob_gmf_t.cpu().numpy()

            # logits并标准化
            logit_hand_test = prob_to_logit(tgt_prob_hand)
            logit_gnn_test = prob_to_logit(tgt_prob_gnn)
            logit_gmf_test = prob_to_logit(tgt_prob_gmf)

            norm_hand_logit = (logit_hand_test - mu_hand) / (std_hand + 1e-8)
            norm_gnn_logit = (logit_gnn_test - mu_gnn) / (std_gnn + 1e-8)
            norm_gmf_logit = (logit_gmf_test - mu_gmf) / (std_gmf + 1e-8)

            # 等权平均 logits, 再转回概率
            fused_logit_3branch = (norm_hand_logit + norm_gnn_logit + norm_gmf_logit) / 3.0
            fused_prob_3branch = 1.0 / (1.0 + np.exp(-fused_logit_3branch))

            res_simcom_logitnorm = evaluate_paper(test_label_eval, fused_prob_3branch, threshold=0.44, loc=test_loc)
            print(f"    🌟 SimCom++_LogitNorm: MCC={res_simcom_logitnorm['MCC']:.4f}  AUC={res_simcom_logitnorm['AUC']:.4f}  AP={res_simcom_logitnorm['AP']:.4f}  F1={res_simcom_logitnorm['F1']:.4f}  BAcc={res_simcom_logitnorm['BalancedAccuracy']:.4f}  Port20%={res_simcom_logitnorm['Port20%']:.1%}  P_opt20%={res_simcom_logitnorm['P_opt20%']:.1%}  IFA={res_simcom_logitnorm['IFA']:.1f}")
            # [Exp3-disabled] print(f"       对比: SimCom++(RankNorm) AUC={res['AUC']:.4f}  F1={res['F1']:.4f}")

            # ================================================================
            # Exp 3.13. Logits 标准化融合 - SimCom++ (GNN+MLP 经 Platt Scaling)
            # ================================================================
            print("\n[Exp 3.13] Logits 标准化融合 - SimCom++ (GNN+MLP 经 Platt Scaling)...")

            # 对 GNN（经过 MLP）的概率进行 Platt Scaling 校准
            # 使用与 Exp 3.10 相同的 Hand 和 GMF 概率
            # 但对 GNN 概率进行 Platt scaling
            from sklearn.linear_model import LogisticRegression as LR
            
            # 获取原始 GNN 概率（无MLP）
            src_prob_gnn_mlp_train = train_gnn_raw_probs  # 使用原始GNN概率
            tgt_prob_gnn_mlp = y_prob_gnn_focal_raw  # 使用原始GNN概率
            
            # --- Platt Scaling 校准 GNN（MLP）概率 ---
            platt_gnn_mlp = LR(max_iter=1000, random_state=Config.RANDOM_SEED)
            platt_gnn_mlp.fit(src_prob_gnn_mlp_train.reshape(-1, 1), train_label)
            src_prob_gnn_platt_train = platt_gnn_mlp.predict_proba(src_prob_gnn_mlp_train.reshape(-1, 1))[:, 1]
            tgt_prob_gnn_platt = platt_gnn_mlp.predict_proba(tgt_prob_gnn_mlp.reshape(-1, 1))[:, 1]
            print(f"    [Platt Scaling] GNN(MLP) 概率已校准")
            
            # 计算校准后 GNN 的 logits 标准化参数（在训练集上）
            logit_gnn_platt_train = prob_to_logit(src_prob_gnn_platt_train)
            mu_gnn_platt, std_gnn_platt = logit_gnn_platt_train.mean(), logit_gnn_platt_train.std()
            
            # 目标域测试集：使用校准后的 GNN 概率
            logit_gnn_platt_test = prob_to_logit(tgt_prob_gnn_platt)
            norm_gnn_platt_logit = (logit_gnn_platt_test - mu_gnn_platt) / (std_gnn_platt + 1e-8)
            
            # 等权平均 logits（Hand + GNN(Platt) + GMF），再转回概率
            fused_logit_3branch_platt = (norm_hand_logit + norm_gnn_platt_logit + norm_gmf_logit) / 3.0
            fused_prob_3branch_platt = 1.0 / (1.0 + np.exp(-fused_logit_3branch_platt))
            
            res_simcom_logitnorm_platt = evaluate_paper(test_label_eval, fused_prob_3branch_platt, threshold=0.44, loc=test_loc)
            print(f"    🌟 SimCom++_LogitNorm(Platt): MCC={res_simcom_logitnorm_platt['MCC']:.4f}  AUC={res_simcom_logitnorm_platt['AUC']:.4f}  AP={res_simcom_logitnorm_platt['AP']:.4f}  F1={res_simcom_logitnorm_platt['F1']:.4f}  BAcc={res_simcom_logitnorm_platt['BalancedAccuracy']:.4f}  Port20%={res_simcom_logitnorm_platt['Port20%']:.1%}  P_opt20%={res_simcom_logitnorm_platt['P_opt20%']:.1%}  IFA={res_simcom_logitnorm_platt['IFA']:.1f}")

            # ================================================================
            # Exp 3.14. Logits 标准化融合 - 直接使用 GNN 原始特征（无 MLP）
            # ================================================================
            print("\n[Exp 3.14] Logits 标准化融合 - 直接使用 GNN 原始特征（无 MLP）...")

            # 直接使用 GNN 预训练模型的 classifier（线性层 + sigmoid）获取概率
            # wrapper_focal.classifier 是预训练好的线性分类器
            
            # 使用训练好的 GNN 特征，通过预训练的 classifier + sigmoid 获取概率
            train_deep_tensor = torch.FloatTensor(train_deep_focal).to(DEVICE)
            test_deep_tensor = torch.FloatTensor(test_deep_focal).to(DEVICE)
            
            with torch.no_grad():
                # 训练集概率（用于计算标准化参数）
                src_logits = wrapper_focal.classifier(train_deep_tensor)
                src_prob_gnn_raw_train = torch.sigmoid(src_logits).cpu().numpy().flatten()
                
                # 测试集概率
                tgt_logits = wrapper_focal.classifier(test_deep_tensor)
                tgt_prob_gnn_raw = torch.sigmoid(tgt_logits).cpu().numpy().flatten()

            # --- Platt Scaling 校准 ---
            from sklearn.linear_model import LogisticRegression as LR
            # 用训练集拟合 Platt scaling 参数
            platt_gnn_raw = LR(max_iter=1000, random_state=Config.RANDOM_SEED)
            platt_gnn_raw.fit(src_prob_gnn_raw_train.reshape(-1, 1), train_label)
            # 对训练集和测试集进行校准
            src_prob_gnn_raw_train = platt_gnn_raw.predict_proba(src_prob_gnn_raw_train.reshape(-1, 1))[:, 1]
            tgt_prob_gnn_raw = platt_gnn_raw.predict_proba(tgt_prob_gnn_raw.reshape(-1, 1))[:, 1]
            print(f"    [Platt Scaling] GNN(Raw) 概率已校准")

            # 源域训练集上计算 logits 的均值和标准差
            logit_gnn_raw_train = prob_to_logit(src_prob_gnn_raw_train)
            mu_gnn_raw, std_gnn_raw = logit_gnn_raw_train.mean(), logit_gnn_raw_train.std()

            # 目标域测试集（使用原始 GNN 特征）
            logit_gnn_raw_test = prob_to_logit(tgt_prob_gnn_raw)
            norm_gnn_raw_logit = (logit_gnn_raw_test - mu_gnn_raw) / (std_gnn_raw + 1e-8)

            # 等权平均 logits, 再转回概率
            fused_logit_3branch_raw = (norm_hand_logit + norm_gnn_raw_logit + norm_gmf_logit) / 3.0
            fused_prob_3branch_raw = 1.0 / (1.0 + np.exp(-fused_logit_3branch_raw))

            res_simcom_logitnorm_raw = evaluate_paper(test_label_eval, fused_prob_3branch_raw, threshold=0.42, loc=test_loc)
            print(f"    🌟 SimCom++_LogitNorm(RawGNN): MCC={res_simcom_logitnorm_raw['MCC']:.4f}  AUC={res_simcom_logitnorm_raw['AUC']:.4f}  AP={res_simcom_logitnorm_raw['AP']:.4f}  F1={res_simcom_logitnorm_raw['F1']:.4f}  BAcc={res_simcom_logitnorm_raw['BalancedAccuracy']:.4f}  Port20%={res_simcom_logitnorm_raw['Port20%']:.1%}  P_opt20%={res_simcom_logitnorm_raw['P_opt20%']:.1%}  IFA={res_simcom_logitnorm_raw['IFA']:.1f}")

            # ================================================================
            # [Exp 3.14.2] SimCom++_LogitNorm(RawGNN) 对比路线：不使用 LogitNorm 标准化
            # ================================================================
            print("\n[Exp 3.14.2] SimCom++_LogitNorm(RawGNN) 对比路线：不使用 LogitNorm 标准化...")

            # 直接使用原始概率的平均（不使用 logit 标准化）
            # 使用 rank normalization 来公平融合不同尺度的概率
            rank_hand = rankdata(tgt_prob_hand) / len(tgt_prob_hand)
            rank_gnn_raw = rankdata(tgt_prob_gnn) / len(tgt_prob_gnn)
            rank_gmf = rankdata(tgt_prob_gmf) / len(tgt_prob_gmf)

            # 等权平均 rank-normalized 概率
            fused_prob_raw_no_norm = (rank_hand + rank_gnn_raw + rank_gmf) / 3.0

            res_simcom_no_logitnorm = evaluate_paper(test_label_eval, fused_prob_raw_no_norm, threshold=0.45, loc=test_loc)
            print(f"    🌟 SimCom++_NoLogitNorm: MCC={res_simcom_no_logitnorm['MCC']:.4f}  AUC={res_simcom_no_logitnorm['AUC']:.4f}  AP={res_simcom_no_logitnorm['AP']:.4f}  F1={res_simcom_no_logitnorm['F1']:.4f}  BAcc={res_simcom_no_logitnorm['BalancedAccuracy']:.4f}  Port20%={res_simcom_no_logitnorm['Port20%']:.1%}  P_opt20%={res_simcom_no_logitnorm['P_opt20%']:.1%}  IFA={res_simcom_no_logitnorm['IFA']:.1f}")

            # ================================================================
            # [Exp 3.14.3] SimCom++_NoLogitNorm 对比试验：动态加权后期融合
            # ================================================================
            print("\n[Exp 3.14.3] SimCom++_NoLogitNorm 对比试验：动态加权后期融合...")
            
            # 动态加权：基于验证集性能动态调整权重
            # 使用 AUC 作为权重分配依据
            hand_auc = res_hand['AUC']
            gnn_auc = res_gnn_focal['AUC']
            gmf_auc = res_handmpos['AUC']
            
            total_auc = hand_auc + gnn_auc + gmf_auc
            if total_auc > 0:
                hand_weight = hand_auc / total_auc
                gnn_weight = gnn_auc / total_auc
                gmf_weight = gmf_auc / total_auc
            else:
                hand_weight = gnn_weight = gmf_weight = 1/3
            
            fused_prob_dynamic = hand_weight * rank_hand + gnn_weight * rank_gnn_raw + gmf_weight * rank_gmf
            
            res_simcom_dynamic = evaluate_paper(test_label_eval, fused_prob_dynamic, threshold=0.45, loc=test_loc)
            print(f"    🌟 SimCom++_Dynamic: MCC={res_simcom_dynamic['MCC']:.4f}  AUC={res_simcom_dynamic['AUC']:.4f}  AP={res_simcom_dynamic['AP']:.4f}  F1={res_simcom_dynamic['F1']:.4f}  BAcc={res_simcom_dynamic['BalancedAccuracy']:.4f}  Port20%={res_simcom_dynamic['Port20%']:.1%}  P_opt20%={res_simcom_dynamic['P_opt20%']:.1%}  IFA={res_simcom_dynamic['IFA']:.1f}")
            print(f"         (权重: Hand={hand_weight:.3f}, GNN={gnn_weight:.3f}, GMF={gmf_weight:.3f})")

            # ================================================================
            # [Exp 3.14.4] SimCom++_NoLogitNorm 对比试验：固定加权融合
            # ================================================================
            print("\n[Exp 3.14.4] SimCom++_NoLogitNorm 对比试验：固定加权融合...")
            
            # 定义不同的加权比例 (Hand : GNN : GMF)
            weight_ratios = [
                ('3:3:4', 0.3, 0.3, 0.4),
                ('3:4:3', 0.3, 0.4, 0.3),
                ('4:3:3', 0.4, 0.3, 0.3),
                ('2:3:5', 0.2, 0.3, 0.5),
                ('3:2:5', 0.3, 0.2, 0.5),
                ('3:1:6', 0.3, 0.1, 0.6),
                ('1:3:6', 0.1, 0.3, 0.6),
                ('3:0:7', 0.3, 0.0, 0.7),
            ]
            
            # 存储不同加权比例的结果
            fused_results = {}
            for name, w_h, w_g, w_m in weight_ratios:
                fused_prob_weighted = w_h * rank_hand + w_g * rank_gnn_raw + w_m * rank_gmf
                res = evaluate_paper(test_label_eval, fused_prob_weighted, threshold=0.45, loc=test_loc)
                fused_results[name] = res
                print(f"    🌟 SimCom++_Weighted({name}): MCC={res['MCC']:.4f}  AUC={res['AUC']:.4f}  AP={res['AP']:.4f}  F1={res['F1']:.4f}")
                
                # 收集权重敏感性分析数据
                weight_sensitivity_results.append({
                    'ratio': name,
                    'hand_weight': w_h,
                    'gnn_weight': w_g,
                    'gmf_weight': w_m,
                    'mcc': res['MCC'],
                    'auc': res['AUC'],
                    'f1': res['F1'],
                    'test_project': test_proj,
                    'run_id': run_i
                })

            # ================================================================
            # Exp 3.14.1. 对比试验: GMF+GNN Logits 标准化融合 (无 Hand)
            # ================================================================
            print("\n[Exp 3.14.1] 对比试验: GMF+GNN Logits 标准化融合 (无 Hand)...")

            # 两路 logits 标准化 (只用 GMF 和 GNN)
            fused_logit_gmf_gnn = (norm_gmf_logit + norm_gnn_raw_logit) / 2.0
            fused_prob_gmf_gnn = 1.0 / (1.0 + np.exp(-fused_logit_gmf_gnn))

            res_gmf_gnn_logitnorm = evaluate_paper(test_label_eval, fused_prob_gmf_gnn, threshold=0.44, loc=test_loc)
            print(f"    🌟 GMF+GNN_LogitNorm: MCC={res_gmf_gnn_logitnorm['MCC']:.4f}  AUC={res_gmf_gnn_logitnorm['AUC']:.4f}  AP={res_gmf_gnn_logitnorm['AP']:.4f}  F1={res_gmf_gnn_logitnorm['F1']:.4f}  BAcc={res_gmf_gnn_logitnorm['BalancedAccuracy']:.4f}  Port20%={res_gmf_gnn_logitnorm['Port20%']:.1%}  P_opt20%={res_gmf_gnn_logitnorm['P_opt20%']:.1%}  IFA={res_gmf_gnn_logitnorm['IFA']:.1f}")

            # ================================================================
            # Exp 3.11. Logits 标准化融- GMF+Hand (两分
            # ================================================================
            print("\n[Exp 3.11] Logits 标准化融- GMF+Hand (两分...")

            # 两分logits 标准化(只用 Hand GMF
            norm_hand_2branch = (logit_hand_test - mu_hand) / (std_hand + 1e-8)
            norm_gmf_2branch = (logit_gmf_test - mu_gmf) / (std_gmf + 1e-8)

            # 等权平均 logits, 再转回概率
            fused_logit_2branch = (norm_hand_2branch + norm_gmf_2branch) / 2.0
            fused_prob_2branch = 1.0 / (1.0 + np.exp(-fused_logit_2branch))

            res_gmfhand_logitnorm = evaluate_paper(test_label_eval, fused_prob_2branch, threshold=0.44, loc=test_loc)
            print(f"    🌟 GMF+Hand_LogitNorm: MCC={res_gmfhand_logitnorm['MCC']:.4f}  AUC={res_gmfhand_logitnorm['AUC']:.4f}  AP={res_gmfhand_logitnorm['AP']:.4f}  F1={res_gmfhand_logitnorm['F1']:.4f}  BAcc={res_gmfhand_logitnorm['BalancedAccuracy']:.4f}  Port20%={res_gmfhand_logitnorm['Port20%']:.1%}  P_opt20%={res_gmfhand_logitnorm['P_opt20%']:.1%}  IFA={res_gmfhand_logitnorm['IFA']:.1f}")
            # [Exp312-disabled] print(f"       对比: GMF-only AUC={res_gmf['AUC']:.4f}  F1={res_gmf['F1']:.4f}")

            # ================================================================
            # Exp 3.15. Logits 标准化融合 - Hand+MPOS + GNN (两路对比，无GMF)
            # ================================================================
            print("\n[Exp 3.15] Logits 标准化融合 - Hand+MPOS + GNN (两路对比，无GMF)...")

            # 两路logits 标准化(只用 Hand+MPOS 和 GNN)
            fused_logit_2branch_hn = (norm_hand_logit + norm_gnn_logit) / 2.0
            fused_prob_2branch_hn = 1.0 / (1.0 + np.exp(-fused_logit_2branch_hn))

            res_handgnn_logitnorm = evaluate_paper(test_label_eval, fused_prob_2branch_hn, threshold=0.44, loc=test_loc)
            print(f"    🌟 Hand+GNN_LogitNorm: MCC={res_handgnn_logitnorm['MCC']:.4f}  AUC={res_handgnn_logitnorm['AUC']:.4f}  AP={res_handgnn_logitnorm['AP']:.4f}  F1={res_handgnn_logitnorm['F1']:.4f}  BAcc={res_handgnn_logitnorm['BalancedAccuracy']:.4f}  Port20%={res_handgnn_logitnorm['Port20%']:.1%}  P_opt20%={res_handgnn_logitnorm['P_opt20%']:.1%}  IFA={res_handgnn_logitnorm['IFA']:.1f}")

            # [Exp5-disabled] # ================================================================
            # [Exp5-disabled] # Exp 5. GMF + Hand 简单加权融
            # [Exp5-disabled] # ================================================================
            # [Exp5-disabled] print("\n[Exp 5] GMF + Hand 简单加权融..")

            # [Exp5-disabled] norm_hand_gh = rank_normalize(y_prob_hand_mpos_raw)
            # [Exp5-disabled] norm_gmf_gh = prob_gmf_norm

            # [Exp5-disabled] y_gh = (norm_hand_gh + norm_gmf_gh) / 2.0
            # [Exp5-disabled] res_gh = evaluate_paper(test_label_eval, y_gh, threshold=abs_thr3, loc=test_loc)
            # [Exp5-disabled] print(f"  🌟 GMF+Hand: MCC={res_gh['MCC']:.4f}  AUC={res_gh['AUC']:.4f}")

            # [Exp5-disabled] # 使用 Exp 3 结果作为 SimCom++_MPOS
            # [Exp5-disabled] res_simcom_mpos = res

            # ================================================================
            # 收集结果
            # ================================================================
            # 生成训练项目标识（多源合并）
            train_proj_label = '+'.join([proj for proj, _, _ in selected])
            
            row = {
                'Run_ID': run_i + 1,
                'Train':  train_proj_label,
                'Test':   test_proj,

                'Hand(MCC)':    res_hand['MCC'],
                'Hand(BACC)':   res_hand['BalancedAccuracy'],
                'Hand(AUC)':    res_hand['AUC'],
                'Hand(F1)':     res_hand['F1'],

                'Hand+MPOS(MCC)':  res_hand_mpos['MCC'],
                'Hand+MPOS(BACC)': res_hand_mpos['BalancedAccuracy'],
                'Hand+MPOS(AUC)':  res_hand_mpos['AUC'],
                'Hand+MPOS(F1)':   res_hand_mpos['F1'],

                'GNN(focus)(MCC)':   res_gnn_focal['MCC'],
                'GNN(focus)(BACC)':  res_gnn_focal['BalancedAccuracy'],
                'GNN(focus)(AUC)':   res_gnn_focal['AUC'],
                'GNN(focus)(F1)':    res_gnn_focal['F1'],

                # [Exp2-disabled] 'GNN(MCC)':         res_gnn['MCC'],
                # [Exp2-disabled] 'GNN(BACC)':        res_gnn['BalancedAccuracy'],
                # [Exp2-disabled] 'GNN(AUC)':         res_gnn['AUC'],
                # [Exp2-disabled] 'GNN(F1)':          res_gnn['F1'],
                # [Exp2-disabled] 'GNN_Port20':       res_gnn['Port20%'],
                # [Exp2-disabled] 'GNN_IFA':          res_gnn['IFA'],

                # [Exp312-disabled] 'GMF-only(MCC)':  res_gmf['MCC'],
                # [Exp312-disabled] 'GMF-only(BACC)': res_gmf['BalancedAccuracy'],
                # [Exp312-disabled] 'GMF-only(AUC)':  res_gmf['AUC'],
                # [Exp312-disabled] 'GMF-only(F1)':   res_gmf['F1'],

                # [Exp3-disabled] 'SimCom++(MCC)':  res['MCC'],
                # [Exp3-disabled] 'SimCom++(BACC)': res['BalancedAccuracy'],
                # [Exp3-disabled] 'SimCom++(AUC)':  res['AUC'],
                # [Exp3-disabled] 'SimCom++(F1)':   res['F1'],

                # [Exp5-disabled] 'GMF+Hand(MCC)':  res_gh['MCC'],
                # [Exp5-disabled] 'GMF+Hand(BACC)': res_gh['BalancedAccuracy'],
                # [Exp5-disabled] 'GMF+Hand(AUC)':  res_gh['AUC'],
                # [Exp5-disabled] 'GMF+Hand(F1)':   res_gh['F1'],

                # [Exp3-disabled] 'SimCom++_Port20':  res['Port20%'],
                # [Exp3-disabled] 'SimCom++_Popt20':  res['P_opt20%'],
                # [Exp3-disabled] 'SimCom++_IFA':     res['IFA'],
                # [Exp312-disabled] 'GMF_Only_Port20':  res_gmf['Port20%'],
                # [Exp312-disabled] 'GMF_Only_Popt20':  res_gmf['P_opt20%'],
                # [Exp312-disabled] 'GMF_Only_IFA':     res_gmf['IFA'],
                'HandMPOS_Port20':  res_hand_mpos['Port20%'],
                'HandMPOS_Popt20':  res_hand_mpos['P_opt20%'],
                'HandMPOS_IFA':     res_hand_mpos['IFA'],

                'SimCom++_LogitNorm(MCC)':  res_simcom_logitnorm['MCC'],
                'SimCom++_LogitNorm(BACC)': res_simcom_logitnorm['BalancedAccuracy'],
                'SimCom++_LogitNorm(AUC)':  res_simcom_logitnorm['AUC'],
                'SimCom++_LogitNorm(F1)':   res_simcom_logitnorm['F1'],
                'SimCom++_LogitNorm_Port20': res_simcom_logitnorm['Port20%'],
                'SimCom++_LogitNorm_IFA':   res_simcom_logitnorm['IFA'],

                'SimCom++_LogitNorm(Platt)(MCC)':  res_simcom_logitnorm_platt['MCC'],
                'SimCom++_LogitNorm(Platt)(BACC)': res_simcom_logitnorm_platt['BalancedAccuracy'],
                'SimCom++_LogitNorm(Platt)(AUC)':  res_simcom_logitnorm_platt['AUC'],
                'SimCom++_LogitNorm(Platt)(F1)':   res_simcom_logitnorm_platt['F1'],
                'SimCom++_LogitNorm(Platt)_Port20': res_simcom_logitnorm_platt['Port20%'],
                'SimCom++_LogitNorm(Platt)_Popt20': res_simcom_logitnorm_platt['P_opt20%'],
                'SimCom++_LogitNorm(Platt)_IFA':   res_simcom_logitnorm_platt['IFA'],

                'SimCom++_LogitNorm(RawGNN)(MCC)':  res_simcom_logitnorm_raw['MCC'],
                'SimCom++_LogitNorm(RawGNN)(BACC)': res_simcom_logitnorm_raw['BalancedAccuracy'],
                'SimCom++_LogitNorm(RawGNN)(AUC)':  res_simcom_logitnorm_raw['AUC'],
                'SimCom++_LogitNorm(RawGNN)(F1)':   res_simcom_logitnorm_raw['F1'],
                'SimCom++_LogitNorm(RawGNN)_Port20': res_simcom_logitnorm_raw['Port20%'],
                'SimCom++_LogitNorm(RawGNN)_Popt20': res_simcom_logitnorm_raw['P_opt20%'],
                'SimCom++_LogitNorm(RawGNN)_IFA':   res_simcom_logitnorm_raw['IFA'],

                # 对比路线：SimCom++_NoLogitNorm
                'SimCom++_NoLogitNorm(MCC)':   res_simcom_no_logitnorm['MCC'],
                'SimCom++_NoLogitNorm(BACC)':  res_simcom_no_logitnorm['BalancedAccuracy'],
                'SimCom++_NoLogitNorm(AUC)':   res_simcom_no_logitnorm['AUC'],
                'SimCom++_NoLogitNorm(F1)':    res_simcom_no_logitnorm['F1'],
                'SimCom++_NoLogitNorm_Port20': res_simcom_no_logitnorm['Port20%'],
                'SimCom++_NoLogitNorm_Popt20': res_simcom_no_logitnorm['P_opt20%'],
                'SimCom++_NoLogitNorm_IFA':    res_simcom_no_logitnorm['IFA'],

                # 对比路线：动态加权后期融合
                'SimCom++_Dynamic(MCC)':   res_simcom_dynamic['MCC'],
                'SimCom++_Dynamic(BACC)':  res_simcom_dynamic['BalancedAccuracy'],
                'SimCom++_Dynamic(AUC)':   res_simcom_dynamic['AUC'],
                'SimCom++_Dynamic(F1)':    res_simcom_dynamic['F1'],
                'SimCom++_Dynamic_Port20': res_simcom_dynamic['Port20%'],
                'SimCom++_Dynamic_Popt20': res_simcom_dynamic['P_opt20%'],
                'SimCom++_Dynamic_IFA':    res_simcom_dynamic['IFA'],

                # 对比路线：固定加权融合 3:3:4
                'SimCom++_Weighted_334(MCC)':   fused_results['3:3:4']['MCC'],
                'SimCom++_Weighted_334(BACC)':  fused_results['3:3:4']['BalancedAccuracy'],
                'SimCom++_Weighted_334(AUC)':   fused_results['3:3:4']['AUC'],
                'SimCom++_Weighted_334(F1)':    fused_results['3:3:4']['F1'],
                'SimCom++_Weighted_334_Port20': fused_results['3:3:4']['Port20%'],
                'SimCom++_Weighted_334_Popt20': fused_results['3:3:4']['P_opt20%'],
                'SimCom++_Weighted_334_IFA':    fused_results['3:3:4']['IFA'],

                # 对比路线：固定加权融合 3:4:3
                'SimCom++_Weighted_343(MCC)':   fused_results['3:4:3']['MCC'],
                'SimCom++_Weighted_343(BACC)':  fused_results['3:4:3']['BalancedAccuracy'],
                'SimCom++_Weighted_343(AUC)':   fused_results['3:4:3']['AUC'],
                'SimCom++_Weighted_343(F1)':    fused_results['3:4:3']['F1'],
                'SimCom++_Weighted_343_Port20': fused_results['3:4:3']['Port20%'],
                'SimCom++_Weighted_343_Popt20': fused_results['3:4:3']['P_opt20%'],
                'SimCom++_Weighted_343_IFA':    fused_results['3:4:3']['IFA'],

                # 对比路线：固定加权融合 4:3:3
                'SimCom++_Weighted_433(MCC)':   fused_results['4:3:3']['MCC'],
                'SimCom++_Weighted_433(BACC)':  fused_results['4:3:3']['BalancedAccuracy'],
                'SimCom++_Weighted_433(AUC)':   fused_results['4:3:3']['AUC'],
                'SimCom++_Weighted_433(F1)':    fused_results['4:3:3']['F1'],
                'SimCom++_Weighted_433_Port20': fused_results['4:3:3']['Port20%'],
                'SimCom++_Weighted_433_Popt20': fused_results['4:3:3']['P_opt20%'],
                'SimCom++_Weighted_433_IFA':    fused_results['4:3:3']['IFA'],

                # 对比路线：固定加权融合 2:3:5
                'SimCom++_Weighted_235(MCC)':   fused_results['2:3:5']['MCC'],
                'SimCom++_Weighted_235(BACC)':  fused_results['2:3:5']['BalancedAccuracy'],
                'SimCom++_Weighted_235(AUC)':   fused_results['2:3:5']['AUC'],
                'SimCom++_Weighted_235(F1)':    fused_results['2:3:5']['F1'],
                'SimCom++_Weighted_235_Port20': fused_results['2:3:5']['Port20%'],
                'SimCom++_Weighted_235_Popt20': fused_results['2:3:5']['P_opt20%'],
                'SimCom++_Weighted_235_IFA':    fused_results['2:3:5']['IFA'],

                # 对比路线：固定加权融合 3:2:5
                'SimCom++_Weighted_325(MCC)':   fused_results['3:2:5']['MCC'],
                'SimCom++_Weighted_325(BACC)':  fused_results['3:2:5']['BalancedAccuracy'],
                'SimCom++_Weighted_325(AUC)':   fused_results['3:2:5']['AUC'],
                'SimCom++_Weighted_325(F1)':    fused_results['3:2:5']['F1'],
                'SimCom++_Weighted_325_Port20': fused_results['3:2:5']['Port20%'],
                'SimCom++_Weighted_325_Popt20': fused_results['3:2:5']['P_opt20%'],
                'SimCom++_Weighted_325_IFA':    fused_results['3:2:5']['IFA'],

                # 对比路线：固定加权融合 3:1:6
                'SimCom++_Weighted_316(MCC)':   fused_results['3:1:6']['MCC'],
                'SimCom++_Weighted_316(BACC)':  fused_results['3:1:6']['BalancedAccuracy'],
                'SimCom++_Weighted_316(AUC)':   fused_results['3:1:6']['AUC'],
                'SimCom++_Weighted_316(F1)':    fused_results['3:1:6']['F1'],
                'SimCom++_Weighted_316_Port20': fused_results['3:1:6']['Port20%'],
                'SimCom++_Weighted_316_Popt20': fused_results['3:1:6']['P_opt20%'],
                'SimCom++_Weighted_316_IFA':    fused_results['3:1:6']['IFA'],

                # 对比路线：固定加权融合 1:3:6
                'SimCom++_Weighted_136(MCC)':   fused_results['1:3:6']['MCC'],
                'SimCom++_Weighted_136(BACC)':  fused_results['1:3:6']['BalancedAccuracy'],
                'SimCom++_Weighted_136(AUC)':   fused_results['1:3:6']['AUC'],
                'SimCom++_Weighted_136(F1)':    fused_results['1:3:6']['F1'],
                'SimCom++_Weighted_136_Port20': fused_results['1:3:6']['Port20%'],
                'SimCom++_Weighted_136_Popt20': fused_results['1:3:6']['P_opt20%'],
                'SimCom++_Weighted_136_IFA':    fused_results['1:3:6']['IFA'],

                'SimCom++_Weighted_307(MCC)':   fused_results['3:0:7']['MCC'],
                'SimCom++_Weighted_307(BACC)':  fused_results['3:0:7']['BalancedAccuracy'],
                'SimCom++_Weighted_307(AUC)':   fused_results['3:0:7']['AUC'],
                'SimCom++_Weighted_307(F1)':    fused_results['3:0:7']['F1'],
                'SimCom++_Weighted_307_Port20': fused_results['3:0:7']['Port20%'],
                'SimCom++_Weighted_307_Popt20': fused_results['3:0:7']['P_opt20%'],
                'SimCom++_Weighted_307_IFA':    fused_results['3:0:7']['IFA'],

                'GMF+GNN_LogitNorm(MCC)':  res_gmf_gnn_logitnorm['MCC'],
                'GMF+GNN_LogitNorm(BACC)': res_gmf_gnn_logitnorm['BalancedAccuracy'],
                'GMF+GNN_LogitNorm(AUC)':  res_gmf_gnn_logitnorm['AUC'],
                'GMF+GNN_LogitNorm(F1)':   res_gmf_gnn_logitnorm['F1'],
                'GMF+GNN_LogitNorm_Port20': res_gmf_gnn_logitnorm['Port20%'],
                'GMF+GNN_LogitNorm_Popt20': res_gmf_gnn_logitnorm['P_opt20%'],
                'GMF+GNN_LogitNorm_IFA':   res_gmf_gnn_logitnorm['IFA'],

                'GMF+Hand_LogitNorm(MCC)':  res_gmfhand_logitnorm['MCC'],
                'GMF+Hand_LogitNorm(BACC)': res_gmfhand_logitnorm['BalancedAccuracy'],
                'GMF+Hand_LogitNorm(AUC)':  res_gmfhand_logitnorm['AUC'],
                'GMF+Hand_LogitNorm(F1)':   res_gmfhand_logitnorm['F1'],
                'GMF+Hand_LogitNorm_Port20': res_gmfhand_logitnorm['Port20%'],
                'GMF+Hand_LogitNorm_Popt20': res_gmfhand_logitnorm['P_opt20%'],
                'GMF+Hand_LogitNorm_IFA':   res_gmfhand_logitnorm['IFA'],

                'Hand+GNN_LogitNorm(MCC)':  res_handgnn_logitnorm['MCC'],
                'Hand+GNN_LogitNorm(BACC)': res_handgnn_logitnorm['BalancedAccuracy'],
                'Hand+GNN_LogitNorm(AUC)':  res_handgnn_logitnorm['AUC'],
                'Hand+GNN_LogitNorm(F1)':   res_handgnn_logitnorm['F1'],
                'Hand+GNN_LogitNorm_Port20': res_handgnn_logitnorm['Port20%'],
                'Hand+GNN_LogitNorm_Popt20': res_handgnn_logitnorm['P_opt20%'],
                'Hand+GNN_LogitNorm_IFA':   res_handgnn_logitnorm['IFA'],

                'GMF_HandMPOS(MCC)':  res_handmpos['MCC'],
                'GMF_HandMPOS(BACC)': res_handmpos['BalancedAccuracy'],
                'GMF_HandMPOS(AUC)':  res_handmpos['AUC'],
                'GMF_HandMPOS(F1)':   res_handmpos['F1'],
                'GMF_HandMPOS_Port20': res_handmpos['Port20%'],
                'GMF_HandMPOS_Popt20': res_handmpos['P_opt20%'],
                'GMF_HandMPOS_IFA':   res_handmpos['IFA'],

                # 对比路线
                'GNN(AST, NoPos)(MCC)':   res_gnn_nopos['MCC'],
                'GNN(AST, NoPos)(BACC)':  res_gnn_nopos['BalancedAccuracy'],
                'GNN(AST, NoPos)(AUC)':   res_gnn_nopos['AUC'],
                'GNN(AST, NoPos)(F1)':    res_gnn_nopos['F1'],
                'GNN(AST, NoPos)_Port20': res_gnn_nopos['Port20%'],
                'GNN(AST, NoPos)_Popt20': res_gnn_nopos['P_opt20%'],
                'GNN(AST, NoPos)_IFA':    res_gnn_nopos['IFA'],

                'GNN(AST, NoImb)(MCC)':   res_gnn_noimb['MCC'],
                'GNN(AST, NoImb)(BACC)':  res_gnn_noimb['BalancedAccuracy'],
                'GNN(AST, NoImb)(AUC)':   res_gnn_noimb['AUC'],
                'GNN(AST, NoImb)(F1)':    res_gnn_noimb['F1'],
                'GNN(AST, NoImb)_Port20': res_gnn_noimb['Port20%'],
                'GNN(AST, NoImb)_Popt20': res_gnn_noimb['P_opt20%'],
                'GNN(AST, NoImb)_IFA':    res_gnn_noimb['IFA'],

                'GNN(AST, NoCM)(MCC)':   res_gnn_nocm['MCC'],
                'GNN(AST, NoCM)(BACC)':  res_gnn_nocm['BalancedAccuracy'],
                'GNN(AST, NoCM)(AUC)':   res_gnn_nocm['AUC'],
                'GNN(AST, NoCM)(F1)':    res_gnn_nocm['F1'],
                'GNN(AST, NoCM)_Port20': res_gnn_nocm['Port20%'],
                'GNN(AST, NoCM)_Popt20': res_gnn_nocm['P_opt20%'],
                'GNN(AST, NoCM)_IFA':    res_gnn_nocm['IFA'],

                'GMF_HandMPOS_ScalarGate(MCC)':   res_handmpos_scalar['MCC'],
                'GMF_HandMPOS_ScalarGate(BACC)':  res_handmpos_scalar['BalancedAccuracy'],
                'GMF_HandMPOS_ScalarGate(AUC)':   res_handmpos_scalar['AUC'],
                'GMF_HandMPOS_ScalarGate(F1)':    res_handmpos_scalar['F1'],
                'GMF_HandMPOS_ScalarGate_Port20': res_handmpos_scalar['Port20%'],
                'GMF_HandMPOS_ScalarGate_Popt20': res_handmpos_scalar['P_opt20%'],
                'GMF_HandMPOS_ScalarGate_IFA':    res_handmpos_scalar['IFA'],

                # [Exp313-disabled] 'GMF_FusedCM(MCC)':  res_cm['MCC'],
                # [Exp313-disabled] 'GMF_FusedCM(BACC)': res_cm['BalancedAccuracy'],
                # [Exp313-disabled] 'GMF_FusedCM(AUC)':  res_cm['AUC'],
                # [Exp313-disabled] 'GMF_FusedCM(F1)':   res_cm['F1'],
                # [Exp313-disabled] 'GMF_FusedCM_Port20': res_cm['Port20%'],
                # [Exp313-disabled] 'GMF_FusedCM_Popt20': res_cm['P_opt20%'],
                # [Exp313-disabled] 'GMF_FusedCM_IFA':   res_cm['IFA'],

                # [Exp3-disabled] 'GNN_ActiveRate': gnn_active_rate,
                
                # 保存预测分数用于 Wilcoxon 检验
                'Hand_Probs': y_prob_hand_raw,
                'GNN_Probs': y_prob_gnn_focal_raw,
            }
            all_res.append(row)
            print(f"\n  Pair Result: MCC={row['Hand(MCC)']:.4f}  BACC={row['Hand(BACC)']:.4f}  AUC={row['Hand(AUC)']:.4f}")

            # ================================================================
            # 绘制 Hand 和 GNN 分支的韦恩图
            # ================================================================
            # 获取预测结果（使用原始概率）
            hand_pred = (y_prob_hand_raw >= 0.42).astype(int)
            gnn_pred = (y_prob_gnn_focal_raw >= 0.42).astype(int)
            true_labels = test_label_eval

            # 计算正确识别的缺陷（True Positives）
            hand_tp = np.logical_and(hand_pred == 1, true_labels == 1)
            gnn_tp = np.logical_and(gnn_pred == 1, true_labels == 1)

            tp_left_only = np.sum(np.logical_and(hand_tp, ~gnn_tp))
            tp_overlap = np.sum(np.logical_and(hand_tp, gnn_tp))
            tp_right_only = np.sum(np.logical_and(~hand_tp, gnn_tp))

            # 计算误报（False Positives）
            hand_fp = np.logical_and(hand_pred == 1, true_labels == 0)
            gnn_fp = np.logical_and(gnn_pred == 1, true_labels == 0)

            fp_left_only = np.sum(np.logical_and(hand_fp, ~gnn_fp))
            fp_overlap = np.sum(np.logical_and(hand_fp, gnn_fp))
            fp_right_only = np.sum(np.logical_and(~hand_fp, gnn_fp))
            
            # 累加到汇总数据
            total_tp_hand_only += tp_left_only
            total_tp_overlap += tp_overlap
            total_tp_gnn_only += tp_right_only
            total_fp_hand_only += fp_left_only
            total_fp_overlap += fp_overlap
            total_fp_gnn_only += fp_right_only

            # ================================================================
            # Top-K 版本的双分支韦恩图数据收集
            # ================================================================
            # 设置 K 值（取置信度最高的前 K 个样本）
            K = 200  # 可以根据需要调整
            
            # 获取 Hand 分支置信度最高的前 K 个样本索引
            hand_topk_indices = np.argsort(y_prob_hand_raw)[::-1][:K]
            # 获取 GNN 分支置信度最高的前 K 个样本索引
            gnn_topk_indices = np.argsort(y_prob_gnn_focal_raw)[::-1][:K]
            
            # 创建 Top-K 预测标记
            hand_topk_pred = np.zeros(len(true_labels), dtype=bool)
            hand_topk_pred[hand_topk_indices] = True
            
            gnn_topk_pred = np.zeros(len(true_labels), dtype=bool)
            gnn_topk_pred[gnn_topk_indices] = True
            
            # 计算 Top-K 条件下正确识别的缺陷（True Positives）
            hand_topk_tp = np.logical_and(hand_topk_pred, true_labels == 1)
            gnn_topk_tp = np.logical_and(gnn_topk_pred, true_labels == 1)
            
            tp_left_only_topk = np.sum(np.logical_and(hand_topk_tp, ~gnn_topk_tp))
            tp_overlap_topk = np.sum(np.logical_and(hand_topk_tp, gnn_topk_tp))
            tp_right_only_topk = np.sum(np.logical_and(~hand_topk_tp, gnn_topk_tp))
            
            # 计算 Top-K 条件下的误报（False Positives）
            hand_topk_fp = np.logical_and(hand_topk_pred, true_labels == 0)
            gnn_topk_fp = np.logical_and(gnn_topk_pred, true_labels == 0)
            
            fp_left_only_topk = np.sum(np.logical_and(hand_topk_fp, ~gnn_topk_fp))
            fp_overlap_topk = np.sum(np.logical_and(hand_topk_fp, gnn_topk_fp))
            fp_right_only_topk = np.sum(np.logical_and(~hand_topk_fp, gnn_topk_fp))
            
            # 累加到 Top-K 汇总数据
            total_tp_hand_only_topk += tp_left_only_topk
            total_tp_overlap_topk += tp_overlap_topk
            total_tp_gnn_only_topk += tp_right_only_topk
            total_fp_hand_only_topk += fp_left_only_topk
            total_fp_overlap_topk += fp_overlap_topk
            total_fp_gnn_only_topk += fp_right_only_topk

            # 累加散点图数据
            total_hand_probs.extend(y_prob_hand_raw.tolist())
            total_gnn_probs.extend(y_prob_gnn_focal_raw.tolist())
            total_true_labels.extend(test_label_eval.tolist())

            # ================================================================
            # 绘制三分支韦恩图（Hand vs GNN vs SimCom++_NoLogitNorm）
            # ================================================================
            # 获取 SimCom++_NoLogitNorm 的预测结果
            simcom_raw_pred = (fused_prob_raw_no_norm >= 0.42).astype(int)

            # 计算正确识别的缺陷（True Positives）样本集合
            M_tp = np.logical_and(hand_pred == 1, true_labels == 1)  # Met 正确识别
            S_tp = np.logical_and(gnn_pred == 1, true_labels == 1)   # Struct 正确识别
            F_tp = np.logical_and(simcom_raw_pred == 1, true_labels == 1)  # MetStruct++ 正确识别

            # 使用 calc_three_set_regions 计算 7 个区域
            tp_regions = calc_three_set_regions(M_tp, S_tp, F_tp)

            # 计算误报（False Positives）样本集合
            M_fp = np.logical_and(hand_pred == 1, true_labels == 0)  # Met 误报
            S_fp = np.logical_and(gnn_pred == 1, true_labels == 0)   # Struct 误报
            F_fp = np.logical_and(simcom_raw_pred == 1, true_labels == 0)  # MetStruct++ 误报

            # 使用 calc_three_set_regions 计算 7 个区域
            fp_regions = calc_three_set_regions(M_fp, S_fp, F_fp)
            
            # 累加到汇总数据
            total_tp_only_hand += tp_regions["left_only"]
            total_tp_only_gnn += tp_regions["right_only"]
            total_tp_only_simcom += tp_regions["bottom_only"]
            total_tp_hand_gnn += tp_regions["left_right_only"]
            total_tp_hand_simcom += tp_regions["left_bottom_only"]
            total_tp_gnn_simcom += tp_regions["right_bottom_only"]
            total_tp_all_three += tp_regions["all_three"]
            total_fp_only_hand += fp_regions["left_only"]
            total_fp_only_gnn += fp_regions["right_only"]
            total_fp_only_simcom += fp_regions["bottom_only"]
            total_fp_hand_gnn += fp_regions["left_right_only"]
            total_fp_hand_simcom += fp_regions["left_bottom_only"]
            total_fp_gnn_simcom += fp_regions["right_bottom_only"]
            total_fp_all_three += fp_regions["all_three"]
            
            # ================================================================
            # Top-K 版本的三分支韦恩图数据收集
            # ================================================================
            # 设置 K 值（取置信度最高的前 K 个样本）
            K = 200  # 与双分支保持一致
            
            # 获取 SimCom++_NoLogitNorm 的预测概率
            simcom_raw_probs = fused_prob_raw_no_norm
            
            # 获取三个分支置信度最高的前 K 个样本索引
            hand_topk_indices_3way = np.argsort(y_prob_hand_raw)[::-1][:K]
            gnn_topk_indices_3way = np.argsort(y_prob_gnn_focal_raw)[::-1][:K]
            simcom_topk_indices_3way = np.argsort(simcom_raw_probs)[::-1][:K]
            
            # 创建 Top-K 预测标记
            hand_topk_pred_3way = np.zeros(len(true_labels), dtype=bool)
            hand_topk_pred_3way[hand_topk_indices_3way] = True
            
            gnn_topk_pred_3way = np.zeros(len(true_labels), dtype=bool)
            gnn_topk_pred_3way[gnn_topk_indices_3way] = True
            
            simcom_topk_pred_3way = np.zeros(len(true_labels), dtype=bool)
            simcom_topk_pred_3way[simcom_topk_indices_3way] = True
            
            # 计算 Top-K 条件下正确识别的缺陷（True Positives）样本集合
            M_tp_topk = np.logical_and(hand_topk_pred_3way, true_labels == 1)
            S_tp_topk = np.logical_and(gnn_topk_pred_3way, true_labels == 1)
            F_tp_topk = np.logical_and(simcom_topk_pred_3way, true_labels == 1)
            
            # 使用 calc_three_set_regions 计算 Top-K TP 的 7 个区域
            tp_regions_topk = calc_three_set_regions(M_tp_topk, S_tp_topk, F_tp_topk)
            
            # 计算 Top-K 条件下的误报（False Positives）样本集合
            M_fp_topk = np.logical_and(hand_topk_pred_3way, true_labels == 0)
            S_fp_topk = np.logical_and(gnn_topk_pred_3way, true_labels == 0)
            F_fp_topk = np.logical_and(simcom_topk_pred_3way, true_labels == 0)
            
            # 使用 calc_three_set_regions 计算 Top-K FP 的 7 个区域
            fp_regions_topk = calc_three_set_regions(M_fp_topk, S_fp_topk, F_fp_topk)
            
            # 累加到 Top-K 汇总数据
            total_tp_only_hand_topk += tp_regions_topk["left_only"]
            total_tp_only_gnn_topk += tp_regions_topk["right_only"]
            total_tp_only_simcom_topk += tp_regions_topk["bottom_only"]
            total_tp_hand_gnn_topk += tp_regions_topk["left_right_only"]
            total_tp_hand_simcom_topk += tp_regions_topk["left_bottom_only"]
            total_tp_gnn_simcom_topk += tp_regions_topk["right_bottom_only"]
            total_tp_all_three_topk += tp_regions_topk["all_three"]
            total_fp_only_hand_topk += fp_regions_topk["left_only"]
            total_fp_only_gnn_topk += fp_regions_topk["right_only"]
            total_fp_only_simcom_topk += fp_regions_topk["bottom_only"]
            total_fp_hand_gnn_topk += fp_regions_topk["left_right_only"]
            total_fp_hand_simcom_topk += fp_regions_topk["left_bottom_only"]
            total_fp_gnn_simcom_topk += fp_regions_topk["right_bottom_only"]
            total_fp_all_three_topk += fp_regions_topk["all_three"]

            # ================================================================
            # Case Study 候选样本收集
            # ================================================================
            feature_names = [
                'wmc', 'dit', 'noc', 'cbo', 'rfc', 'lcom', 'ca', 'ce', 'npm', 'lcom3',
                'loc', 'dam', 'moa', 'mfa', 'cam', 'ic', 'cbm', 'amc', 'max_cc', 'avg_cc'
            ]
            
            threshold = 0.42
            
            met_pred = (y_prob_hand_raw >= threshold).astype(int)
            struct_pred = (y_prob_gnn_focal_raw >= threshold).astype(int)
            final_pred = (fused_prob_raw_no_norm >= threshold).astype(int)
            
            # 候选样本：真实缺陷，且 Met 漏掉，但 Struct 或 Final 抓到
            candidate_idx = np.where(
                (test_label_eval == 1) &
                (met_pred == 0) &
                ((struct_pred == 1) | (final_pred == 1))
            )[0]
            
            for idx in candidate_idx:
                idx = int(idx)
                
                case_score = compute_case_score(
                    met_prob=y_prob_hand_raw[idx],
                    struct_prob=y_prob_gnn_focal_raw[idx],
                    final_prob=fused_prob_raw_no_norm[idx],
                    true_label=test_label_eval[idx],
                    met_pred=met_pred[idx],
                    struct_pred=struct_pred[idx],
                    final_pred=final_pred[idx],
                    threshold=threshold
                )
                
                # 为当前样本生成局部解释（Met 分支）
                explanations, base_prob = simple_local_explain(
                    model=rf_hand_pure,
                    x=test_hand_pure[idx],
                    background=train_hand_pure,
                    feature_names=feature_names,
                    top_k=7
                )
                
                code_lines = build_code_lines_for_display(test_token_lines[idx], max_lines=12)
                
                global_case_pool.append({
                    'project': test_proj,
                    'case_idx': idx,
                    'score': case_score,
                    'code_lines': code_lines,
                    'explanations': explanations,
                    'met_prob': float(y_prob_hand_raw[idx]),
                    'struct_prob': float(y_prob_gnn_focal_raw[idx]),
                    'final_prob': float(fused_prob_raw_no_norm[idx]),
                    'true_label': int(test_label_eval[idx]),
                })
            
            # ================================================================
            # Fallback 样本收集：真实缺陷中 Final - Met 差距最大的样本
            # ================================================================
            defect_idx = np.where(test_label_eval == 1)[0]
            if len(defect_idx) > 0:
                # 计算每个缺陷样本的 Final - Met 差值
                score_diff = fused_prob_raw_no_norm[defect_idx] - y_prob_hand_raw[defect_idx]
                
                # 找出差值最大的样本（最多取5个作为备选）
                top_diff_indices = np.argsort(score_diff)[-5:][::-1]
                
                for rel_idx in top_diff_indices:
                    idx = int(defect_idx[rel_idx])
                    diff = score_diff[rel_idx]
                    
                    # 如果这个样本已经在 global_case_pool 中，跳过
                    if any(c['project'] == test_proj and c['case_idx'] == idx for c in global_case_pool):
                        continue
                    
                    # 为当前样本生成局部解释
                    explanations, base_prob = simple_local_explain(
                        model=rf_hand_pure,
                        x=test_hand_pure[idx],
                        background=train_hand_pure,
                        feature_names=feature_names,
                        top_k=7
                    )
                    
                    code_lines = build_code_lines_for_display(test_token_lines[idx], max_lines=12)
                    
                    global_fallback_pool.append({
                        'project': test_proj,
                        'case_idx': idx,
                        'score': float(diff),  # 使用差值作为 score
                        'code_lines': code_lines,
                        'explanations': explanations,
                        'met_prob': float(y_prob_hand_raw[idx]),
                        'struct_prob': float(y_prob_gnn_focal_raw[idx]),
                        'final_prob': float(fused_prob_raw_no_norm[idx]),
                        'true_label': int(test_label_eval[idx]),
                    })

        # ================================================================
        # 本轮结果汇总 (Run-level Summary)
        # ================================================================
        print("\n" + "=" * 120)
        print(f">>> RUN {run_i+1}/20 RESULTS SUMMARY")
        print("=" * 120)
        
        df_run = pd.DataFrame(all_res[-(len(list(all_project_data.keys()))):])
        ga_run = df_run.mean(numeric_only=True)
        
        print(f"\n{'Method':<22} | {'MCC':>7} | {'BACC':>7} | {'AUC':>7} | {'F1':>7} | {'Port20%':>7} | {'P_opt20%':>8} | {'IFA':>5}")
        print("-" * 100)
        for tag, mk, bk, ak, fk, p20, popt20, ifa in [
            ('Hand',          'Hand(MCC)',         'Hand(BACC)',         'Hand(AUC)',         'Hand(F1)',         'HandMPOS_Port20',   'HandMPOS_Popt20',   'HandMPOS_IFA'),
            ('Hand+MPOS',     'Hand+MPOS(MCC)',    'Hand+MPOS(BACC)',   'Hand+MPOS(AUC)',   'Hand+MPOS(F1)',   'HandMPOS_Port20',   'HandMPOS_Popt20',   'HandMPOS_IFA'),
            ('GNN(focus)',    'GNN(focus)(MCC)',   'GNN(focus)(BACC)',  'GNN(focus)(AUC)',  'GNN(focus)(F1)',  'HandMPOS_Port20',   'HandMPOS_Popt20',   'HandMPOS_IFA'),
            ('SimCom++_LogitNorm',         'SimCom++_LogitNorm(MCC)',         'SimCom++_LogitNorm(BACC)',         'SimCom++_LogitNorm(AUC)',         'SimCom++_LogitNorm(F1)',         'SimCom++_LogitNorm_Port20',         'SimCom++_LogitNorm_Popt20',         'SimCom++_LogitNorm_IFA'),
            ('SimCom++_LogitNorm(Platt)',  'SimCom++_LogitNorm(Platt)(MCC)',  'SimCom++_LogitNorm(Platt)(BACC)',  'SimCom++_LogitNorm(Platt)(AUC)',  'SimCom++_LogitNorm(Platt)(F1)',  'SimCom++_LogitNorm(Platt)_Port20',  'SimCom++_LogitNorm(Platt)_Popt20',  'SimCom++_LogitNorm(Platt)_IFA'),
            ('SimCom++_LogitNorm(RawGNN)', 'SimCom++_LogitNorm(RawGNN)(MCC)', 'SimCom++_LogitNorm(RawGNN)(BACC)', 'SimCom++_LogitNorm(RawGNN)(AUC)', 'SimCom++_LogitNorm(RawGNN)(F1)', 'SimCom++_LogitNorm(RawGNN)_Port20', 'SimCom++_LogitNorm(RawGNN)_Popt20', 'SimCom++_LogitNorm(RawGNN)_IFA'),
            ('GMF+GNN_LogitNorm',          'GMF+GNN_LogitNorm(MCC)',          'GMF+GNN_LogitNorm(BACC)',          'GMF+GNN_LogitNorm(AUC)',          'GMF+GNN_LogitNorm(F1)',          'GMF+GNN_LogitNorm_Port20',          'GMF+GNN_LogitNorm_Popt20',          'GMF+GNN_LogitNorm_IFA'),
            ('GMF+Hand_LogitNorm',         'GMF+Hand_LogitNorm(MCC)',         'GMF+Hand_LogitNorm(BACC)',         'GMF+Hand_LogitNorm(AUC)',         'GMF+Hand_LogitNorm(F1)',         'GMF+Hand_LogitNorm_Port20',         'GMF+Hand_LogitNorm_Popt20',         'GMF+Hand_LogitNorm_IFA'),
            ('Hand+GNN_LogitNorm',         'Hand+GNN_LogitNorm(MCC)',         'Hand+GNN_LogitNorm(BACC)',         'Hand+GNN_LogitNorm(AUC)',         'Hand+GNN_LogitNorm(F1)',         'Hand+GNN_LogitNorm_Port20',         'Hand+GNN_LogitNorm_Popt20',         'Hand+GNN_LogitNorm_IFA'),
            ('GMF_HandMPOS',               'GMF_HandMPOS(MCC)',               'GMF_HandMPOS(BACC)',               'GMF_HandMPOS(AUC)',               'GMF_HandMPOS(F1)',               'GMF_HandMPOS_Port20',               'GMF_HandMPOS_Popt20',               'GMF_HandMPOS_IFA'),
            # 对比路线
            ('GNN(AST, NoPos)',            'GNN(AST, NoPos)(MCC)',            'GNN(AST, NoPos)(BACC)',            'GNN(AST, NoPos)(AUC)',            'GNN(AST, NoPos)(F1)',            'GNN(AST, NoPos)_Port20',            'GNN(AST, NoPos)_Popt20',            'GNN(AST, NoPos)_IFA'),
            ('GNN(AST, NoImb)',            'GNN(AST, NoImb)(MCC)',            'GNN(AST, NoImb)(BACC)',            'GNN(AST, NoImb)(AUC)',            'GNN(AST, NoImb)(F1)',            'GNN(AST, NoImb)_Port20',            'GNN(AST, NoImb)_Popt20',            'GNN(AST, NoImb)_IFA'),
            ('GNN(AST, NoCM)',             'GNN(AST, NoCM)(MCC)',             'GNN(AST, NoCM)(BACC)',             'GNN(AST, NoCM)(AUC)',             'GNN(AST, NoCM)(F1)',             'GNN(AST, NoCM)_Port20',             'GNN(AST, NoCM)_Popt20',             'GNN(AST, NoCM)_IFA'),
            ('GMF_HandMPOS_ScalarGate',   'GMF_HandMPOS_ScalarGate(MCC)',   'GMF_HandMPOS_ScalarGate(BACC)',   'GMF_HandMPOS_ScalarGate(AUC)',   'GMF_HandMPOS_ScalarGate(F1)',   'GMF_HandMPOS_ScalarGate_Port20',   'GMF_HandMPOS_ScalarGate_Popt20',   'GMF_HandMPOS_ScalarGate_IFA'),
            ('SimCom++_NoLogitNorm',      'SimCom++_NoLogitNorm(MCC)',      'SimCom++_NoLogitNorm(BACC)',      'SimCom++_NoLogitNorm(AUC)',      'SimCom++_NoLogitNorm(F1)',      'SimCom++_NoLogitNorm_Port20',      'SimCom++_NoLogitNorm_Popt20',      'SimCom++_NoLogitNorm_IFA'),
            # 对比路线：加权融合变体
            ('SimCom++_Dynamic',          'SimCom++_Dynamic(MCC)',          'SimCom++_Dynamic(BACC)',          'SimCom++_Dynamic(AUC)',          'SimCom++_Dynamic(F1)',          'SimCom++_Dynamic_Port20',          'SimCom++_Dynamic_Popt20',          'SimCom++_Dynamic_IFA'),
            ('SimCom++_Weighted(3:3:4)',  'SimCom++_Weighted_334(MCC)',     'SimCom++_Weighted_334(BACC)',     'SimCom++_Weighted_334(AUC)',     'SimCom++_Weighted_334(F1)',     'SimCom++_Weighted_334_Port20',     'SimCom++_Weighted_334_Popt20',     'SimCom++_Weighted_334_IFA'),
            ('SimCom++_Weighted(3:4:3)',  'SimCom++_Weighted_343(MCC)',     'SimCom++_Weighted_343(BACC)',     'SimCom++_Weighted_343(AUC)',     'SimCom++_Weighted_343(F1)',     'SimCom++_Weighted_343_Port20',     'SimCom++_Weighted_343_Popt20',     'SimCom++_Weighted_343_IFA'),
            ('SimCom++_Weighted(4:3:3)',  'SimCom++_Weighted_433(MCC)',     'SimCom++_Weighted_433(BACC)',     'SimCom++_Weighted_433(AUC)',     'SimCom++_Weighted_433(F1)',     'SimCom++_Weighted_433_Port20',     'SimCom++_Weighted_433_Popt20',     'SimCom++_Weighted_433_IFA'),
            ('SimCom++_Weighted(2:3:5)',  'SimCom++_Weighted_235(MCC)',     'SimCom++_Weighted_235(BACC)',     'SimCom++_Weighted_235(AUC)',     'SimCom++_Weighted_235(F1)',     'SimCom++_Weighted_235_Port20',     'SimCom++_Weighted_235_Popt20',     'SimCom++_Weighted_235_IFA'),
            ('SimCom++_Weighted(3:2:5)',  'SimCom++_Weighted_325(MCC)',     'SimCom++_Weighted_325(BACC)',     'SimCom++_Weighted_325(AUC)',     'SimCom++_Weighted_325(F1)',     'SimCom++_Weighted_325_Port20',     'SimCom++_Weighted_325_Popt20',     'SimCom++_Weighted_325_IFA'),
            ('SimCom++_Weighted(3:1:6)',  'SimCom++_Weighted_316(MCC)',     'SimCom++_Weighted_316(BACC)',     'SimCom++_Weighted_316(AUC)',     'SimCom++_Weighted_316(F1)',     'SimCom++_Weighted_316_Port20',     'SimCom++_Weighted_316_Popt20',     'SimCom++_Weighted_316_IFA'),
            ('SimCom++_Weighted(1:3:6)',  'SimCom++_Weighted_136(MCC)',     'SimCom++_Weighted_136(BACC)',     'SimCom++_Weighted_136(AUC)',     'SimCom++_Weighted_136(F1)',     'SimCom++_Weighted_136_Port20',     'SimCom++_Weighted_136_Popt20',     'SimCom++_Weighted_136_IFA'),
            ('SimCom++_Weighted(3:0:7)',  'SimCom++_Weighted_307(MCC)',     'SimCom++_Weighted_307(BACC)',     'SimCom++_Weighted_307(AUC)',     'SimCom++_Weighted_307(F1)',     'SimCom++_Weighted_307_Port20',     'SimCom++_Weighted_307_Popt20',     'SimCom++_Weighted_307_IFA'),
        ]:
            print(f"{tag:<22} | {ga_run.get(mk, 0):>7.4f} | {ga_run.get(bk, 0):>7.4f} | {ga_run.get(ak, 0):>7.4f} | {ga_run.get(fk, 0):>7.4f} | {ga_run.get(p20, 0):>7.1%} | {ga_run.get(popt20, 0):>8.1%} | {ga_run.get(ifa, 0):>5.1f}")
    
    # ================================================================
    # 保存与汇
    # ================================================================
    if not all_res:
        print("No results to display.")
        return

    df = pd.DataFrame(all_res)
    results_path = "/public/home/zhangzihao2025/TGNN/data/simcom++_ablation_results.csv"
    df.to_csv(results_path, index=False)

    if all_sample_preds:
        pd.DataFrame(all_sample_preds).to_csv(
            "/public/home/zhangzihao2025/TGNN/data/simcom++_detailed_predictions.csv",
            index=False
        )

    print("\n" + "=" * 120)
    print("FINAL RESULTS SUMMARY (20 Runs Average ± Std)")
    print("=" * 120)

    ga = df.mean(numeric_only=True)
    gs = df.std(numeric_only=True)
    
    print(f"\n{'Method':<22} | {'MCC':>10} | {'BACC':>10} | {'AUC':>10} | {'F1':>10} | {'Port20%':>10} | {'P_opt20%':>12} | {'IFA':>10}")
    print("-" * 130)
    for tag, mk, bk, ak, fk, p20, popt20, ifa in [
        ('Hand',          'Hand(MCC)',         'Hand(BACC)',         'Hand(AUC)',         'Hand(F1)',         'HandMPOS_Port20',   'HandMPOS_Popt20',   'HandMPOS_IFA'),
        ('Hand+MPOS',     'Hand+MPOS(MCC)',    'Hand+MPOS(BACC)',   'Hand+MPOS(AUC)',   'Hand+MPOS(F1)',   'HandMPOS_Port20',   'HandMPOS_Popt20',   'HandMPOS_IFA'),
        ('GNN(focus)',    'GNN(focus)(MCC)',   'GNN(focus)(BACC)',  'GNN(focus)(AUC)',  'GNN(focus)(F1)',  'HandMPOS_Port20',   'HandMPOS_Popt20',   'HandMPOS_IFA'),
        ('SimCom++_LogitNorm',         'SimCom++_LogitNorm(MCC)',         'SimCom++_LogitNorm(BACC)',         'SimCom++_LogitNorm(AUC)',         'SimCom++_LogitNorm(F1)',         'SimCom++_LogitNorm_Port20',         'SimCom++_LogitNorm_Popt20',         'SimCom++_LogitNorm_IFA'),
        ('SimCom++_LogitNorm(Platt)',  'SimCom++_LogitNorm(Platt)(MCC)',  'SimCom++_LogitNorm(Platt)(BACC)',  'SimCom++_LogitNorm(Platt)(AUC)',  'SimCom++_LogitNorm(Platt)(F1)',  'SimCom++_LogitNorm(Platt)_Port20',  'SimCom++_LogitNorm(Platt)_Popt20',  'SimCom++_LogitNorm(Platt)_IFA'),
        ('SimCom++_LogitNorm(RawGNN)', 'SimCom++_LogitNorm(RawGNN)(MCC)', 'SimCom++_LogitNorm(RawGNN)(BACC)', 'SimCom++_LogitNorm(RawGNN)(AUC)', 'SimCom++_LogitNorm(RawGNN)(F1)', 'SimCom++_LogitNorm(RawGNN)_Port20', 'SimCom++_LogitNorm(RawGNN)_Popt20', 'SimCom++_LogitNorm(RawGNN)_IFA'),
        ('GMF+GNN_LogitNorm',          'GMF+GNN_LogitNorm(MCC)',          'GMF+GNN_LogitNorm(BACC)',          'GMF+GNN_LogitNorm(AUC)',          'GMF+GNN_LogitNorm(F1)',          'GMF+GNN_LogitNorm_Port20',          'GMF+GNN_LogitNorm_Popt20',          'GMF+GNN_LogitNorm_IFA'),
        ('GMF+Hand_LogitNorm',         'GMF+Hand_LogitNorm(MCC)',         'GMF+Hand_LogitNorm(BACC)',         'GMF+Hand_LogitNorm(AUC)',         'GMF+Hand_LogitNorm(F1)',         'GMF+Hand_LogitNorm_Port20',         'GMF+Hand_LogitNorm_Popt20',         'GMF+Hand_LogitNorm_IFA'),
        ('Hand+GNN_LogitNorm',         'Hand+GNN_LogitNorm(MCC)',         'Hand+GNN_LogitNorm(BACC)',         'Hand+GNN_LogitNorm(AUC)',         'Hand+GNN_LogitNorm(F1)',         'Hand+GNN_LogitNorm_Port20',         'Hand+GNN_LogitNorm_Popt20',         'Hand+GNN_LogitNorm_IFA'),
        ('GMF_HandMPOS',               'GMF_HandMPOS(MCC)',               'GMF_HandMPOS(BACC)',               'GMF_HandMPOS(AUC)',               'GMF_HandMPOS(F1)',               'GMF_HandMPOS_Port20',               'GMF_HandMPOS_Popt20',               'GMF_HandMPOS_IFA'),
        # 对比路线
        ('GNN(AST, NoPos)',            'GNN(AST, NoPos)(MCC)',            'GNN(AST, NoPos)(BACC)',            'GNN(AST, NoPos)(AUC)',            'GNN(AST, NoPos)(F1)',            'GNN(AST, NoPos)_Port20',            'GNN(AST, NoPos)_Popt20',            'GNN(AST, NoPos)_IFA'),
        ('GNN(AST, NoImb)',            'GNN(AST, NoImb)(MCC)',            'GNN(AST, NoImb)(BACC)',            'GNN(AST, NoImb)(AUC)',            'GNN(AST, NoImb)(F1)',            'GNN(AST, NoImb)_Port20',            'GNN(AST, NoImb)_Popt20',            'GNN(AST, NoImb)_IFA'),
        ('GNN(AST, NoCM)',             'GNN(AST, NoCM)(MCC)',             'GNN(AST, NoCM)(BACC)',             'GNN(AST, NoCM)(AUC)',             'GNN(AST, NoCM)(F1)',             'GNN(AST, NoCM)_Port20',             'GNN(AST, NoCM)_Popt20',             'GNN(AST, NoCM)_IFA'),
        ('GMF_HandMPOS_ScalarGate',   'GMF_HandMPOS_ScalarGate(MCC)',   'GMF_HandMPOS_ScalarGate(BACC)',   'GMF_HandMPOS_ScalarGate(AUC)',   'GMF_HandMPOS_ScalarGate(F1)',   'GMF_HandMPOS_ScalarGate_Port20',   'GMF_HandMPOS_ScalarGate_Popt20',   'GMF_HandMPOS_ScalarGate_IFA'),
        ('SimCom++_NoLogitNorm',      'SimCom++_NoLogitNorm(MCC)',      'SimCom++_NoLogitNorm(BACC)',      'SimCom++_NoLogitNorm(AUC)',      'SimCom++_NoLogitNorm(F1)',      'SimCom++_NoLogitNorm_Port20',      'SimCom++_NoLogitNorm_Popt20',      'SimCom++_NoLogitNorm_IFA'),
        # 对比路线：加权融合变体
        ('SimCom++_Dynamic',          'SimCom++_Dynamic(MCC)',          'SimCom++_Dynamic(BACC)',          'SimCom++_Dynamic(AUC)',          'SimCom++_Dynamic(F1)',          'SimCom++_Dynamic_Port20',          'SimCom++_Dynamic_Popt20',          'SimCom++_Dynamic_IFA'),
        ('SimCom++_Weighted(3:3:4)',  'SimCom++_Weighted_334(MCC)',     'SimCom++_Weighted_334(BACC)',     'SimCom++_Weighted_334(AUC)',     'SimCom++_Weighted_334(F1)',     'SimCom++_Weighted_334_Port20',     'SimCom++_Weighted_334_Popt20',     'SimCom++_Weighted_334_IFA'),
        ('SimCom++_Weighted(3:4:3)',  'SimCom++_Weighted_343(MCC)',     'SimCom++_Weighted_343(BACC)',     'SimCom++_Weighted_343(AUC)',     'SimCom++_Weighted_343(F1)',     'SimCom++_Weighted_343_Port20',     'SimCom++_Weighted_343_Popt20',     'SimCom++_Weighted_343_IFA'),
        ('SimCom++_Weighted(4:3:3)',  'SimCom++_Weighted_433(MCC)',     'SimCom++_Weighted_433(BACC)',     'SimCom++_Weighted_433(AUC)',     'SimCom++_Weighted_433(F1)',     'SimCom++_Weighted_433_Port20',     'SimCom++_Weighted_433_Popt20',     'SimCom++_Weighted_433_IFA'),
        ('SimCom++_Weighted(2:3:5)',  'SimCom++_Weighted_235(MCC)',     'SimCom++_Weighted_235(BACC)',     'SimCom++_Weighted_235(AUC)',     'SimCom++_Weighted_235(F1)',     'SimCom++_Weighted_235_Port20',     'SimCom++_Weighted_235_Popt20',     'SimCom++_Weighted_235_IFA'),
        ('SimCom++_Weighted(3:2:5)',  'SimCom++_Weighted_325(MCC)',     'SimCom++_Weighted_325(BACC)',     'SimCom++_Weighted_325(AUC)',     'SimCom++_Weighted_325(F1)',     'SimCom++_Weighted_325_Port20',     'SimCom++_Weighted_325_Popt20',     'SimCom++_Weighted_325_IFA'),
        ('SimCom++_Weighted(3:1:6)',  'SimCom++_Weighted_316(MCC)',     'SimCom++_Weighted_316(BACC)',     'SimCom++_Weighted_316(AUC)',     'SimCom++_Weighted_316(F1)',     'SimCom++_Weighted_316_Port20',     'SimCom++_Weighted_316_Popt20',     'SimCom++_Weighted_316_IFA'),
        ('SimCom++_Weighted(1:3:6)',  'SimCom++_Weighted_136(MCC)',     'SimCom++_Weighted_136(BACC)',     'SimCom++_Weighted_136(AUC)',     'SimCom++_Weighted_136(F1)',     'SimCom++_Weighted_136_Port20',     'SimCom++_Weighted_136_Popt20',     'SimCom++_Weighted_136_IFA'),
        ('SimCom++_Weighted(3:0:7)',  'SimCom++_Weighted_307(MCC)',     'SimCom++_Weighted_307(BACC)',     'SimCom++_Weighted_307(AUC)',     'SimCom++_Weighted_307(F1)',     'SimCom++_Weighted_307_Port20',     'SimCom++_Weighted_307_Popt20',     'SimCom++_Weighted_307_IFA'),
    ]:
        mcc_val = ga.get(mk, 0)
        mcc_std = gs.get(mk, 0)
        bacc_val = ga.get(bk, 0)
        bacc_std = gs.get(bk, 0)
        auc_val = ga.get(ak, 0)
        auc_std = gs.get(ak, 0)
        f1_val = ga.get(fk, 0)
        f1_std = gs.get(fk, 0)
        p20_val = ga.get(p20, 0)
        p20_std = gs.get(p20, 0)
        popt20_val = ga.get(popt20, 0)
        popt20_std = gs.get(popt20, 0)
        ifa_val = ga.get(ifa, 0)
        ifa_std = gs.get(ifa, 0)
        
        print(f"{tag:<22} | {mcc_val:.3f}±{mcc_std:.3f} | {bacc_val:.3f}±{bacc_std:.3f} | {auc_val:.3f}±{auc_std:.3f} | {f1_val:.3f}±{f1_std:.3f} | {p20_val:.1%}±{p20_std:.1%} | {popt20_val:.1%}±{popt20_std:.1%} | {ifa_val:.1f}±{ifa_std:.1f}")

    print("\nResults saved to:", results_path)

    # ================================================================
    # 消融实验结果汇总
    # ================================================================
    print("\n" + "=" * 120)
    print(">>> ABLATION EXPERIMENT RESULTS")
    print("=" * 120)
    
    # 1. 一对一项目对结果汇总
    if pair_one_results:
        print("\n  [Pair-One] 一对一项目对结果:")
        print("  " + "-" * 80)
        print(f"  {'Source':<18} | {'Target':<18} | {'MCC':>7} | {'AUC':>7} | {'BACC':>7} | {'F1':>7}")
        print("  " + "-" * 80)
        for r in pair_one_results:
            print(f"  {r['src_proj']:<18} | {r['tgt_proj']:<18} | {r['MCC']:.4f} | {r['AUC']:.4f} | {r['BACC']:.4f} | {r['F1']:.4f}")
        
        # 计算平均结果
        pair_one_mean = pd.DataFrame(pair_one_results).mean(numeric_only=True)
        print(f"\n  Pair-One Average: MCC={pair_one_mean['MCC']:.4f}  AUC={pair_one_mean['AUC']:.4f}  BACC={pair_one_mean['BACC']:.4f}  F1={pair_one_mean['F1']:.4f}")
    
    # 2. 源项目数量消融实验结果汇总
    print("\n  [Source Count] 源项目数量消融实验:")
    print("  " + "-" * 80)
    print(f"  {'K':<3} | {'#Proj':<6} | {'Mean AUC':>10} | {'Std AUC':>10} | {'Mean MCC':>10} | {'Mean BACC':>10}")
    print("  " + "-" * 80)
    
    for k in [1, 2, 3, 4, 5, 6]:
        if k == 3:
            print(f"  {k:<3} | {'-':<6} | {0.707:.4f}       | {'-':>10} | {'-':>10} | {'-':>10} *")
        elif k in source_count_results and len(source_count_results[k]) > 0:
            results_k = pd.DataFrame(source_count_results[k])
            mean_auc = results_k['AUC'].mean()
            std_auc = results_k['AUC'].std()
            mean_mcc = results_k['MCC'].mean()
            mean_bacc = results_k['BACC'].mean()
            marker = " *" if k == 3 else "  "
            print(f"  {k:<3} | {len(results_k):<6} | {mean_auc:.4f}       | {std_auc:.4f}       | {mean_mcc:.4f}       | {mean_bacc:.4f}{marker}")
        else:
            print(f"  {k:<3} | {'-':<6} | {'-':>10} | {'-':>10} | {'-':>10} | {'-':>10}")
    
    # 绘制源项目数量消融折线图
    draw_source_count_ablation_plot(source_count_results)

    # =========================================================
    # 从所有项目中选最有说明力的 1-2 个案例
    # =========================================================
    if len(global_case_pool) > 0:
        # 优先使用理想样本（Met漏掉，Struct或Final抓到）
        global_case_pool = sorted(global_case_pool, key=lambda x: x["score"], reverse=True)
        top_cases = global_case_pool[:2]
        case_type = "理想样本"
    elif len(global_fallback_pool) > 0:
        # 使用 Fallback 样本（Final - Met 差距最大的真实缺陷）
        global_fallback_pool = sorted(global_fallback_pool, key=lambda x: x["score"], reverse=True)
        top_cases = global_fallback_pool[:2]
        case_type = "Fallback样本"
        print("[Case Study] 没有找到理想样本，使用 Fallback 样本（Final-Met差距最大）")
    else:
        top_cases = []
        case_type = None
    
    if len(top_cases) > 0:
        print(f"\n[Case Study] 选出的全局代表样本 ({case_type}):")
        for rank, case in enumerate(top_cases, start=1):
            print(
                f"  Top-{rank}: project={case['project']}, "
                f"idx={case['case_idx']}, score={case['score']:.4f}, "
                f"Met={case['met_prob']:.3f}, Struct={case['struct_prob']:.3f}, "
                f"Final={case['final_prob']:.3f}"
            )
        
        output_dir = "/public/home/zhangzihao2025/TGNN/data/case_study_figures"
        os.makedirs(output_dir, exist_ok=True)
        
        for rank, case in enumerate(top_cases, start=1):
            save_path = os.path.join(
                output_dir,
                f"case_top{rank}_{case['project']}_{case['case_idx']}.svg"
            )
            
            draw_case_study_figure(
                code_lines=case["code_lines"],
                explanations=case["explanations"],
                met_prob=case["met_prob"],
                struct_prob=case["struct_prob"],
                final_prob=case["final_prob"],
                true_label=case["true_label"],
                save_path=save_path
            )
    else:
        print("[Case Study] 没有找到满足条件的候选样本。")

    # ================================================================
    # Wilcoxon Signed-Rank Test 分析 Hand 和 GNN 预测分数分布的差异性
    # ================================================================
    print("\n" + "=" * 120)
    print("PERFORMING WILCOXON SIGNED-RANK TEST (Hand vs GNN Prediction Scores)")
    print("=" * 120)

    # 获取所有目标项目
    projects = df['Test'].unique()
    p_values = []
    x_labels = []

    print("  Wilcoxon Signed-Rank Test Results (Hand vs GNN):")
    print("  ------------------------------------------------")
    print("  Project          | Samples | Hand Mean | GNN Mean | p-value")
    print("  -----------------|---------|-----------|----------|--------")

    # 收集所有项目的预测分数用于总体检验
    all_hand_probs = []
    all_gnn_probs = []

    for proj in projects:
        proj_data = df[df['Test'] == proj]
        
        if len(proj_data) > 0:
            # 获取预测分数（取第一次运行的数据）
            first_run = proj_data.iloc[0]
            hand_probs = first_run['Hand_Probs']
            gnn_probs = first_run['GNN_Probs']
            
            # 确保长度一致
            min_len = min(len(hand_probs), len(gnn_probs))
            if min_len > 0:
                hand_probs = hand_probs[:min_len]
                gnn_probs = gnn_probs[:min_len]
                
                # 累加到总体数据
                all_hand_probs.extend(hand_probs)
                all_gnn_probs.extend(gnn_probs)
                
                # 执行 Wilcoxon signed-rank test
                try:
                    stat, p_value = wilcoxon(hand_probs, gnn_probs)
                except Exception as e:
                    print(f"    Error for {proj}: {e}")
                    p_value = 1.0
                
                p_values.append(p_value)
                x_labels.append(proj)
                
                hand_mean = np.mean(hand_probs)
                gnn_mean = np.mean(gnn_probs)
                
                print(f"  {proj:<15} | {min_len:>7} | {hand_mean:>9.4f} | {gnn_mean:>10.4f} | {format_p_value(p_value)}")

    # 计算总体 Wilcoxon 检验（所有项目合并）
    if len(all_hand_probs) > 0 and len(all_gnn_probs) > 0:
        try:
            overall_stat, overall_p_value = wilcoxon(all_hand_probs, all_gnn_probs)
        except Exception as e:
            print(f"    Error in overall test: {e}")
            overall_p_value = 1.0
    else:
        overall_p_value = 1.0
    
    print("  ===============================================")
    print(f"  Overall (All Projects)                        ")
    print(f"    Total Samples: {len(all_hand_probs)}")
    print(f"    Hand Mean: {np.mean(all_hand_probs):.4f}, GNN Mean: {np.mean(all_gnn_probs):.4f}")
    print(f"    Overall p-value: {format_p_value(overall_p_value)}")
    print("  ===============================================")

    # 绘制符号检验热图（使用 -log10(p-value)）
    sign_test_path = "/public/home/zhangzihao2025/TGNN/data/sign_test_heatmap_met_vs_struct.svg"
    draw_sign_test_heatmap_log(
        p_values,
        x_labels,
        row_label="Met vs Struct",
        title="Statistical significance of Met vs Struct",
        save_path=sign_test_path,
        cap_value=60,
    )
    print(f"  Sign Test heatmap saved to: {sign_test_path}")
    
    # ================================================================
    # 绘制所有项目的汇总韦恩图
    # ================================================================
    print("\n" + "=" * 120)
    print("PLOTTING AGGREGATED VENN DIAGRAM (All Projects)")
    print("=" * 120)
    
    fig, axes = plt.subplots(1, 2, figsize=(12, 3.1))
    
    draw_venn_diagram(
        axes[0],
        title="Correctly Identified Defects",
        left_only=total_tp_hand_only,
        overlap=total_tp_overlap,
        right_only=total_tp_gnn_only,
        left_label="Met",
        right_label="Struct",
        left_color="#B65AB7",
        right_color="#BDEFFF",
    )
    
    draw_venn_diagram(
        axes[1],
        title="False Identified Defects",
        left_only=total_fp_hand_only,
        overlap=total_fp_overlap,
        right_only=total_fp_gnn_only,
        left_label="Met",
        right_label="Struct",
        left_color="#B65AB7",
        right_color="#BDEFFF",
    )
    
    plt.subplots_adjust(wspace=0.62)
    venn_summary_path = "/public/home/zhangzihao2025/TGNN/data/venn_hand_gnn_all_projects.svg"
    plt.savefig(venn_summary_path, dpi=300, bbox_inches="tight")
    plt.close()
    
    print(f"\n  [Venn] 汇总韦恩图已保存: {venn_summary_path}")
    print(f"  TP - Met only: {total_tp_hand_only}, Overlap: {total_tp_overlap}, Struct only: {total_tp_gnn_only}")
    print(f"  FP - Met only: {total_fp_hand_only}, Overlap: {total_fp_overlap}, Struct only: {total_fp_gnn_only}")
    
    # ================================================================
    # 绘制所有项目的三分支汇总韦恩图
    # ================================================================
    print("\n" + "=" * 120)
    print("PLOTTING AGGREGATED THREE-BRANCH VENN DIAGRAM (All Projects)")
    print("=" * 120)
    
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
    
    draw_three_branch_containment_style(
        axes[0],
        title="Correctly Identified Defects",
        met_unique_in_fusion=0,
        struct_unique_in_fusion=0,
        fusion_only=total_tp_only_simcom,
        met_struct_overlap_outside_fusion=0,
        met_fusion_only=total_tp_only_hand + total_tp_hand_simcom,
        struct_fusion_only=total_tp_only_gnn + total_tp_gnn_simcom,
        all_three=total_tp_all_three + total_tp_hand_gnn,
        left_label="Met",
        right_label="Struct",
        bottom_label="MetStruct++",
        left_color="#A000A0",
        right_color="#87D7F5",
        bottom_color="#A8F08A",
    )
    
    draw_three_branch_containment_style(
        axes[1],
        title="False Identified Defects",
        met_unique_in_fusion=0,
        struct_unique_in_fusion=0,
        fusion_only=total_fp_only_simcom,
        met_struct_overlap_outside_fusion=0,
        met_fusion_only=total_fp_only_hand + total_fp_hand_simcom,
        struct_fusion_only=total_fp_only_gnn + total_fp_gnn_simcom,
        all_three=total_fp_all_three + total_fp_hand_gnn,
        left_label="Met",
        right_label="Struct",
        bottom_label="MetStruct++",
        left_color="#A000A0",
        right_color="#87D7F5",
        bottom_color="#A8F08A",
    )
    
    plt.subplots_adjust(wspace=0.5)
    venn_three_summary_path = "/public/home/zhangzihao2025/TGNN/data/venn_three_branch_all_projects.svg"
    plt.savefig(venn_three_summary_path, dpi=300, bbox_inches="tight")
    plt.close()
    
    print(f"\n  [Venn] 三分支汇总韦恩图已保存: {venn_three_summary_path}")
    print(f"  TP - Met only: {total_tp_only_hand}, Struct only: {total_tp_only_gnn}, MetStruct++ only: {total_tp_only_simcom}")
    print(f"  TP - Met+Struct: {total_tp_hand_gnn}, Met+MetStruct++: {total_tp_hand_simcom}, Struct+MetStruct++: {total_tp_gnn_simcom}")
    print(f"  TP - All three: {total_tp_all_three}")
    
    print(f"  FP - Met only: {total_fp_only_hand}, Struct only: {total_fp_only_gnn}, MetStruct++ only: {total_fp_only_simcom}")
    print(f"  FP - Met+Struct: {total_fp_hand_gnn}, Met+MetStruct++: {total_fp_hand_simcom}, Struct+MetStruct++: {total_fp_gnn_simcom}")
    print(f"  FP - All three: {total_fp_all_three}")

    # ================================================================
    # 绘制 Top-K 版本的双分支汇总韦恩图（TP 和 FP）
    # ================================================================
    print("\n" + "=" * 120)
    print("PLOTTING TOP-K AGGREGATED TWO-BRANCH VENN DIAGRAM (All Projects)")
    print("=" * 120)
    
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
    
    draw_venn_diagram(
        axes[0],
        title="Correctly Identified Defects",
        left_only=total_tp_hand_only_topk,
        overlap=total_tp_overlap_topk,
        right_only=total_tp_gnn_only_topk,
        left_label="Met",
        right_label="Struct",
        left_color="#B65AB7",
        right_color="#BDEFFF",
    )
    
    draw_venn_diagram(
        axes[1],
        title="False Identified Defects",
        left_only=total_fp_hand_only_topk,
        overlap=total_fp_overlap_topk,
        right_only=total_fp_gnn_only_topk,
        left_label="Met",
        right_label="Struct",
        left_color="#B65AB7",
        right_color="#BDEFFF",
    )
    
    plt.subplots_adjust(wspace=0.62)
    venn_topk_summary_path = f"/public/home/zhangzihao2025/TGNN/data/venn_hand_gnn_top{K}_all_projects.svg"
    plt.savefig(venn_topk_summary_path, dpi=300, bbox_inches="tight")
    plt.close()
    
    print(f"\n  [Venn] Top-K 双分支汇总韦恩图已保存: {venn_topk_summary_path}")
    print(f"  Top-K TP - Met only: {total_tp_hand_only_topk}, Overlap: {total_tp_overlap_topk}, Struct only: {total_tp_gnn_only_topk}")
    print(f"  Top-K FP - Met only: {total_fp_hand_only_topk}, Overlap: {total_fp_overlap_topk}, Struct only: {total_fp_gnn_only_topk}")
    
    # ================================================================
    # 绘制 Top-K 版本的三分支汇总韦恩图（TP 和 FP）
    # ================================================================
    print("\n" + "=" * 120)
    print("PLOTTING TOP-K AGGREGATED THREE-BRANCH VENN DIAGRAM (All Projects)")
    print("=" * 120)
    
    fig, axes = plt.subplots(1, 2, figsize=(12, 5.5))
    
    draw_three_branch_containment_style(
        axes[0],
        title="Correctly Identified Defects",
        met_unique_in_fusion=0,
        struct_unique_in_fusion=0,
        fusion_only=total_tp_only_simcom_topk,
        met_struct_overlap_outside_fusion=0,
        met_fusion_only=total_tp_only_hand_topk + total_tp_hand_simcom_topk,
        struct_fusion_only=total_tp_only_gnn_topk + total_tp_gnn_simcom_topk,
        all_three=total_tp_all_three_topk + total_tp_hand_gnn_topk,
        left_label="Met",
        right_label="Struct",
        bottom_label="MetStruct++",
        left_color="#A000A0",
        right_color="#87D7F5",
        bottom_color="#A8F08A",
    )
    
    draw_three_branch_containment_style(
        axes[1],
        title="False Identified Defects",
        met_unique_in_fusion=0,
        struct_unique_in_fusion=0,
        fusion_only=total_fp_only_simcom_topk,
        met_struct_overlap_outside_fusion=0,
        met_fusion_only=total_fp_only_hand_topk + total_fp_hand_simcom_topk,
        struct_fusion_only=total_fp_only_gnn_topk + total_fp_gnn_simcom_topk,
        all_three=total_fp_all_three_topk + total_fp_hand_gnn_topk,
        left_label="Met",
        right_label="Struct",
        bottom_label="MetStruct++",
        left_color="#A000A0",
        right_color="#87D7F5",
        bottom_color="#A8F08A",
    )
    
    plt.subplots_adjust(wspace=0.5)
    venn_three_topk_summary_path = f"/public/home/zhangzihao2025/TGNN/data/venn_three_branch_top{K}_all_projects.svg"
    plt.savefig(venn_three_topk_summary_path, dpi=300, bbox_inches="tight")
    plt.close()
    
    print(f"\n  [Venn] Top-K 三分支汇总韦恩图已保存: {venn_three_topk_summary_path}")
    print(f"  Top-K TP - Met only: {total_tp_only_hand_topk}, Struct only: {total_tp_only_gnn_topk}, MetStruct++ only: {total_tp_only_simcom_topk}")
    print(f"  Top-K TP - Met+Struct: {total_tp_hand_gnn_topk}, Met+MetStruct++: {total_tp_hand_simcom_topk}, Struct+MetStruct++: {total_tp_gnn_simcom_topk}")
    print(f"  Top-K TP - All three: {total_tp_all_three_topk}")
    print(f"  Top-K FP - Met only: {total_fp_only_hand_topk}, Struct only: {total_fp_only_gnn_topk}, MetStruct++ only: {total_fp_only_simcom_topk}")
    print(f"  Top-K FP - Met+Struct: {total_fp_hand_gnn_topk}, Met+MetStruct++: {total_fp_hand_simcom_topk}, Struct+MetStruct++: {total_fp_gnn_simcom_topk}")
    print(f"  Top-K FP - All three: {total_fp_all_three_topk}")

    # ================================================================
    # 权重敏感性分析（绘制散点图）
    # ================================================================
    print("\n" + "=" * 120)
    print("WEIGHT SENSITIVITY ANALYSIS")
    print("=" * 120)

    if len(weight_sensitivity_results) > 0:
        plot_weight_sensitivity(weight_sensitivity_results)
    else:
        print("  [Weight Sensitivity] 无有效数据可绘制")

    # ================================================================
    # 绘制Hand和GNN预测概率散点图（所有项目汇总）
    # ================================================================
    print("\n" + "=" * 120)
    print("PLOTTING HAND VS GNN PREDICTION SCATTER PLOT (All Projects)")
    print("=" * 120)

    if len(total_hand_probs) > 0 and len(total_gnn_probs) > 0:
        scatter_path = "/public/home/zhangzihao2025/TGNN/data/scatter_hand_vs_gnn.svg"

        draw_prediction_scatter_plot(
            hand_probs=np.array(total_hand_probs),
            gnn_probs=np.array(total_gnn_probs),
            true_labels=np.array(total_true_labels),
            title="Hand vs GNN 预测概率散点图（红=缺陷，蓝=干净）",
            xlabel="Hand 预测概率",
            ylabel="GNN 预测概率",
            save_path=scatter_path
        )

        print(f"\n  [Scatter] 预测概率散点图已保存: {scatter_path}")
        print(f"  总样本数: {len(total_hand_probs)}")
        print(f"  缺陷样本数: {sum(total_true_labels)}")
        print(f"  干净样本数: {len(total_true_labels) - sum(total_true_labels)}")
    else:
        print("  [Scatter] 无有效数据可绘制散点图")
    
    # ================================================================
    # 绘制项目分布热力图
    # ================================================================
    print("\n" + "=" * 120)
    print("PLOTTING PROJECT DISTRIBUTION HEATMAP")
    print("=" * 120)
    
    draw_project_distance_heatmap(all_project_data)

# ================================================================
# 权重敏感性分析绘图函数
# ================================================================
def plot_weight_sensitivity(
    weight_results: list,
    output_dir: str = None
) -> None:
    """
    Draw weight-sensitivity plot for AUC metric.
    
    Args:
        weight_results: List of dictionaries containing weight ratio and metrics
        output_dir: Directory to save the plots (default: script_dir/data/weight_sensitivity)
    """
    import pandas as pd
    import matplotlib.pyplot as plt
    from pathlib import Path
    import os
    
    # 使用与其他结果统一的主目录绝对路径
    if output_dir is None:
        output_path = Path("/public/home/zhangzihao2025/TGNN/data/weight_sensitivity")
    else:
        output_path = Path(output_dir)
    
    df = pd.DataFrame(weight_results)
    
    required_columns = {"ratio", "hand_weight", "gnn_weight", "gmf_weight", "auc"}
    missing_columns = required_columns - set(df.columns)
    if missing_columns:
        print(f"  [Weight Sensitivity] Missing required columns: {sorted(missing_columns)}")
        return
    
    output_path.mkdir(parents=True, exist_ok=True)
    
    print(f"\n  [Weight Sensitivity] Plotting weight sensitivity analysis (AUC)...")
    
    # 按权重比分组计算平均AUC
    df_mean = df.groupby('ratio')['auc'].mean().reset_index()
    
    # Plot AUC vs weight ratios (折线图)
    fig, ax = plt.subplots(figsize=(8, 5))

    x_pos = np.arange(len(df_mean))
    ax.plot(
        x_pos,
        df_mean['auc'],
        marker='o',
        linewidth=2,
        markersize=8,
        color='steelblue',
        label='Late Fusion Model'
    )

    # 标出最佳权重
    best_idx = np.argmax(df_mean['auc'].values)
    best_weight = df_mean['ratio'].iloc[best_idx]
    best_score = df_mean['auc'].iloc[best_idx]

    ax.axvline(best_idx, linestyle='--', linewidth=1, color='gray', alpha=0.7)
    ax.scatter(best_idx, best_score, s=150, zorder=5, color='red', edgecolors='black', linewidth=1.5)

    # 标注最佳点
    ax.text(
        best_idx,
        best_score,
        f"  Best α={best_weight}\n  AUC={best_score:.3f}",
        va='bottom',
        ha='left',
        fontsize=10,
        color='red'
    )

    # 添加数值标签
    for i, row in df_mean.iterrows():
        ax.text(i, row['auc'], f"{row['auc']:.4f}", ha='center', va='bottom', fontsize=9)

    ax.set_xticks(x_pos)
    ax.set_xticklabels(df_mean['ratio'])
    ax.set_xlabel('Fusion Weight Ratio (Hand:GNN:GMF)')
    ax.set_ylabel('AUC')
    ax.set_title('Performance of Late Fusion Model under Different Weights')
    ax.set_ylim(bottom=0.5, top=1.0)
    ax.grid(True, alpha=0.3)
    ax.legend()
    fig.tight_layout()
    
    fig.savefig(output_path / 'weight_sensitivity_auc.svg', bbox_inches='tight')
    fig.savefig(output_path / 'weight_sensitivity_auc.png', dpi=300, bbox_inches='tight')
    plt.close(fig)
    
    # Save CSV results
    df.to_csv(output_path / 'weight_sensitivity_results.csv', index=False)
    print(f"  [Weight Sensitivity] Plot saved to: {output_path}")


# ================================================================
# 项目分布热力图绘制函数
# ================================================================
def draw_project_distance_heatmap(
    all_project_data: dict,
    output_path: str = "/public/home/zhangzihao2025/TGNN/data/project_distance_heatmap.png"
) -> None:
    """
    基于项目均值向量绘制项目间分布距离热力图
    
    Args:
        all_project_data: 包含所有项目数据的字典
        output_path: 热力图保存路径
    """
    import pandas as pd
    import numpy as np
    from sklearn.preprocessing import StandardScaler
    from scipy.spatial.distance import pdist, squareform
    
    # =========================
    # 1. 收集所有文件级特征
    # =========================
    all_file_features = []
    project_names = []
    project_feature_indices = []  # 记录每个项目对应的特征索引
    
    for proj_name, proj_data in all_project_data.items():
        if 'hand_raw' in proj_data and len(proj_data['hand_raw']) > 0:
            project_names.append(proj_name)
            features = np.array(proj_data['hand_raw'])
            project_feature_indices.append((len(all_file_features), len(all_file_features) + len(features)))
            all_file_features.append(features)
    
    if len(project_names) < 2:
        print("  [Heatmap] 项目数量不足，无法绘制热力图")
        return
    
    # 合并所有文件级特征
    all_file_features = np.vstack(all_file_features)
    
    # =========================
    # 2. 对所有文件级样本做统一标准化
    # =========================
    scaler = StandardScaler()
    all_file_features_scaled = scaler.fit_transform(all_file_features)
    
    # =========================
    # 3. 按项目计算标准化后的均值向量
    # =========================
    feature_matrix = []
    for start_idx, end_idx in project_feature_indices:
        mean_features = np.mean(all_file_features_scaled[start_idx:end_idx], axis=0)
        feature_matrix.append(mean_features)
    
    feature_matrix = np.array(feature_matrix)
    
    # =========================
    # 4. 计算项目间距离矩阵
    # =========================
    dist_matrix = squareform(pdist(feature_matrix, metric="euclidean"))
    dist_df = pd.DataFrame(dist_matrix, index=project_names, columns=project_names)
    
    # =========================
    # 5. 绘制热力图
    # =========================
    fig, ax = plt.subplots(figsize=(10, 8))
    
    im = ax.imshow(dist_df.values, cmap='viridis')
    
    # 坐标轴
    ax.set_xticks(np.arange(len(project_names)))
    ax.set_yticks(np.arange(len(project_names)))
    ax.set_xticklabels(project_names, rotation=45, ha="right", fontsize=10)
    ax.set_yticklabels(project_names, fontsize=10)
    
    ax.set_title("Project Distribution Distance Heatmap", fontsize=14, pad=15)
    ax.set_xlabel("Project", fontsize=12)
    ax.set_ylabel("Project", fontsize=12)
    
    # 数值标注
    for i in range(len(project_names)):
        for j in range(len(project_names)):
            ax.text(j, i, f"{dist_df.values[i, j]:.2f}",
                    ha="center", va="center", fontsize=8, color='white' if dist_df.values[i, j] > dist_df.values.max() * 0.5 else 'black')
    
    # 突出 Log4j
    for tick in ax.get_xticklabels():
        if "log4j" in tick.get_text().lower():
            tick.set_fontweight("bold")
            tick.set_color("#FF0000")
    
    for tick in ax.get_yticklabels():
        if "log4j" in tick.get_text().lower():
            tick.set_fontweight("bold")
            tick.set_color("#FF0000")
    
    # 颜色条
    cbar = fig.colorbar(im, ax=ax)
    cbar.set_label("Euclidean Distance", fontsize=12)
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close()
    
    # =========================
    # 5. 输出距离矩阵
    # =========================
    print(f"\n  [Heatmap] 项目距离矩阵:")
    print("  " + "=" * 80)
    print(dist_df.round(3).to_string())
    print(f"\n  [Heatmap] 项目分布热力图已保存: {output_path}")


# ================================================================
# 源项目数量消融实验折线图绘制函数
# ================================================================
def draw_source_count_ablation_plot(
    source_count_results: dict,
    output_path: str = "/public/home/zhangzihao2025/TGNN/data/source_count_ablation.png"
) -> None:
    """
    绘制源项目数量消融实验的折线图，展示不同K值下的AUC变化
    
    Args:
        source_count_results: 包含不同K值结果的字典
        output_path: 折线图保存路径
    """
    import pandas as pd
    import numpy as np
    import matplotlib.pyplot as plt
    
    k_values = [1, 2, 3, 4, 5, 6]
    
    # 收集每个K值的AUC数据
    auc_data = []
    for k in k_values:
        if k == 3:
            auc_data.append({
                'K': k,
                'mean_auc': 0.707,
                'std_auc': 0.0,
                'aucs': [0.707]
            })
        elif k in source_count_results and len(source_count_results[k]) > 0:
            aucs = [r['AUC'] for r in source_count_results[k]]
            auc_data.append({
                'K': k,
                'mean_auc': np.mean(aucs),
                'std_auc': np.std(aucs),
                'aucs': aucs
            })
    
    if len(auc_data) == 0:
        print("  [Ablation Plot] No data to plot")
        return
    
    df_auc = pd.DataFrame(auc_data)
    
    plt.figure(figsize=(8, 5))
    
    x = df_auc['K']
    y = df_auc['mean_auc']
    
    # 绘制折线
    plt.plot(x, y, marker='o', linestyle='-', linewidth=2, color='#1f77b4', label='AUC')
    
    # 标注每个点的数值（只显示均值，不显示误差）
    for i, (k, mean_auc) in enumerate(zip(x, y)):
        plt.text(k, mean_auc + 0.015, f"{mean_auc:.3f}", 
                 ha='center', va='bottom', fontsize=11, fontweight='bold')
    
    # 突出K=3（主路线）
    k3_idx = np.where(x == 3)[0]
    if len(k3_idx) > 0:
        plt.scatter(3, y[k3_idx[0]], s=150, marker='*', color='red', 
                    edgecolors='darkred', linewidths=1.5, label='Main (K=3)')
    
    plt.xlabel('Number of Source Projects (K)', fontsize=12)
    plt.ylabel('AUC', fontsize=12)
    plt.title('Performance vs Number of Source Projects', fontsize=14, pad=15)
    
    plt.xticks(k_values)
    plt.ylim(bottom=0.5, top=1.0)
    plt.grid(True, alpha=0.3)
    plt.legend(fontsize=10)
    
    plt.tight_layout()
    
    # 保存为SVG格式
    svg_path = output_path.replace('.png', '.svg')
    plt.savefig(svg_path, format='svg', bbox_inches='tight')
    plt.close()
    
    print(f"\n  [Ablation Plot] 源项目数量消融折线图已保存: {svg_path}")


if __name__ == "__main__":
    main()