# [file name]: mpos.py
# [file content begin]
"""
MPOS (Modified Preprocessing Oversampling Sampling)
在特征空间进行过采样，处理类不平衡问题
保持与sklearn相似的接口
"""

import numpy as np
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')


class MPOSAugmenter:
    """
    特征空间过采样器 - 修复类不平衡问题
    
    参数:
        k_neighbors: 最近邻数量，用于插值
        target_ratio: 目标少数类比例 (少数类/多数类)
        random_state: 随机种子
        scale_features: 是否标准化特征
    """
    
    def __init__(self, k_neighbors=5, target_ratio=0.5, 
                 random_state=42, scale_features=True):
        self.k_neighbors = k_neighbors
        self.target_ratio = target_ratio
        self.random_state = random_state
        self.scale_features = scale_features
        self.scaler = StandardScaler() if scale_features else None
        self._fit_called = False
        
        np.random.seed(random_state)
    
    def fit_resample(self, X, y):
        """
        主函数：在特征空间过采样
        
        参数:
            X: 特征矩阵 [n_samples, n_features]
            y: 标签向量 [n_samples]
            
        返回:
            X_resampled: 过采样后的特征
            y_resampled: 过采样后的标签
        """
        # 转换为numpy数组
        X = np.array(X) if not isinstance(X, np.ndarray) else X
        y = np.array(y).flatten() if not isinstance(y, np.ndarray) else y.flatten()
        
        # 验证输入
        self._validate_input(X, y)
        
        print(f"MPOS开始: 原始样本数={len(y)}, 特征维度={X.shape[1]}")
        
        # 1. 标准化特征
        if self.scale_features and self.scaler is not None:
            X_processed = self.scaler.fit_transform(X)
        else:
            X_processed = X.copy()
        
        # 2. 分析类别分布
        unique_labels, counts = np.unique(y, return_counts=True)
        
        if len(unique_labels) < 2:
            print("只有一个类别，跳过MPOS")
            return X_processed, y
        
        # 识别少数类和多数类
        minority_label = unique_labels[np.argmin(counts)]
        majority_label = unique_labels[np.argmax(counts)]
        
        minority_indices = np.where(y == minority_label)[0]
        majority_indices = np.where(y == majority_label)[0]
        
        n_minority = len(minority_indices)
        n_majority = len(majority_indices)
        
        imbalance_ratio = n_majority / max(n_minority, 1)
        print(f"   类别分布: 少数类({minority_label})={n_minority}, "
              f"多数类({majority_label})={n_majority}, 失衡比={imbalance_ratio:.1f}:1")
        
        # 3. 检查是否需要过采样
        target_minority = int(n_majority * self.target_ratio)
        n_to_generate = max(0, target_minority - n_minority)
        
        if n_to_generate <= 0:
            print(f"   数据已平衡(少数类≥{target_minority})，跳过过采样")
            return X_processed, y
        
        print(f"   需要生成 {n_to_generate} 个少数类样本")
        
        # 4. 检查是否有足够的少数类样本进行kNN
        if n_minority <= 1:
            print(f"少数类样本太少({n_minority})，无法进行kNN，使用随机复制")
            return self._random_oversample(X_processed, y, minority_label, n_to_generate)
        
        # 5. 准备kNN
        actual_k = min(self.k_neighbors, n_minority - 1)
        if actual_k < self.k_neighbors:
            print(f"   调整k值: {self.k_neighbors} → {actual_k} (少数类样本不足)")
        
        minority_features = X_processed[minority_indices]
        
        try:
            knn = NearestNeighbors(n_neighbors=actual_k, metric='euclidean')
            knn.fit(minority_features)
        except Exception as e:
            print(f"   kNN构建失败: {e}，使用随机复制")
            return self._random_oversample(X_processed, y, minority_label, n_to_generate)
        
        # 6. 生成合成样本
        synthetic_samples = []
        synthetic_labels = []
        
        generated = 0
        max_attempts = n_to_generate * 3  # 防止无限循环
        attempts = 0
        
        while generated < n_to_generate and attempts < max_attempts:
            attempts += 1
            
            # 随机选择源样本
            src_idx = np.random.choice(minority_indices)
            src_feature = X_processed[src_idx].reshape(1, -1)
            
            try:
                # 找到最近邻
                distances, neighbor_indices = knn.kneighbors(src_feature)
                
                # 随机选择邻居（排除第一个，因为它是自己）
                if neighbor_indices.shape[1] > 1:
                    # 随机选择一个邻居
                    neighbor_local_idx = np.random.choice(neighbor_indices[0][1:])
                    neighbor_global_idx = minority_indices[neighbor_local_idx]
                else:
                    # 没有邻居，使用自己（但这种情况不应该发生）
                    neighbor_global_idx = src_idx
                
                # 线性插值
                alpha = np.random.random()
                synthetic = (
                    alpha * X_processed[src_idx] + 
                    (1 - alpha) * X_processed[neighbor_global_idx]
                )
                
                synthetic_samples.append(synthetic)
                synthetic_labels.append(minority_label)
                generated += 1
                
                if generated % 100 == 0 and generated > 0:
                    print(f"     生成进度: {generated}/{n_to_generate}")
                    
            except Exception as e:
                print(f"   生成样本失败: {e}")
                continue
        
        if generated < n_to_generate:
            print(f"   只成功生成 {generated}/{n_to_generate} 个样本")
        
        # 7. 合并结果
        X_resampled = np.vstack([X_processed, synthetic_samples])
        y_resampled = np.concatenate([y, synthetic_labels])
        
        # 打乱顺序
        shuffle_indices = np.random.permutation(len(y_resampled))
        X_resampled = X_resampled[shuffle_indices]
        y_resampled = y_resampled[shuffle_indices]
        
        # 统计信息
        final_minority = np.sum(y_resampled == minority_label)
        final_majority = len(y_resampled) - final_minority
        final_ratio = final_minority / max(final_majority, 1)
        
        print(f"MPOS完成: 总样本={len(y_resampled)}, "
              f"少数类={final_minority}, 多数类={final_majority}, "
              f"比例={final_ratio:.2f}:1")
        
        self._fit_called = True
        return X_resampled, y_resampled
    
    def _random_oversample(self, X, y, minority_label, n_to_generate):
        """随机过采样（kNN失败时的后备方案）"""
        minority_indices = np.where(y == minority_label)[0]
        
        if len(minority_indices) == 0:
            print("   没有少数类样本，无法过采样")
            return X, y
        
        # 随机复制少数类样本
        selected_indices = np.random.choice(minority_indices, size=n_to_generate, 
                                          replace=True)
        synthetic_samples = X[selected_indices]
        synthetic_labels = [minority_label] * n_to_generate
        
        X_resampled = np.vstack([X, synthetic_samples])
        y_resampled = np.concatenate([y, synthetic_labels])
        
        # 打乱顺序
        shuffle_indices = np.random.permutation(len(y_resampled))
        X_resampled = X_resampled[shuffle_indices]
        y_resampled = y_resampled[shuffle_indices]
        
        print(f"   使用随机复制生成 {n_to_generate} 个样本")
        
        return X_resampled, y_resampled
    
    def _validate_input(self, X, y):
        """验证输入数据"""
        if len(X) != len(y):
            raise ValueError(f"特征和标签数量不匹配: X={len(X)}, y={len(y)}")
        
        if len(X) == 0:
            raise ValueError("输入数据为空")
        
        if len(X.shape) != 2:
            raise ValueError(f"特征应该是2D数组，但得到 shape={X.shape}")
    
    def transform(self, X):
        """转换特征（标准化）"""
        if self.scaler is None or not self.scale_features:
            return X
        
        if not self._fit_called:
            warnings.warn("transform被调用但fit_resample未调用，标准化可能不一致")
        
        return self.scaler.transform(X) if hasattr(self.scaler, 'mean_') else X


# 兼容性函数（保持原有调用方式）
def apply_mpos_oversampling(features, labels, k_neighbors=5, target_ratio=0.5):
    """
    应用MPOS过采样（兼容性函数）
    
    参数:
        features: 特征矩阵
        labels: 标签
        k_neighbors: 最近邻数
        target_ratio: 目标比例
        
    返回:
        增强后的特征和标签
    """
    mpos = MPOSAugmenter(
        k_neighbors=k_neighbors,
        target_ratio=target_ratio,
        random_state=42,
        scale_features=True
    )
    
    return mpos.fit_resample(features, labels)
# [file content end]