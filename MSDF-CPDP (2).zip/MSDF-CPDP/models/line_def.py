"""
LineDef 完整实现（AST 结构图版）
使用 tree-sitter 构建 AST 图，替代 CodeBERT 语义嵌入。

核心思路：
- 跨项目可迁移性来源于语法结构，而非代码语义
- AST 节点类型（IfStatement、TryCatch 等）是跨项目的公共语言
- 节点特征 = 可学习类型嵌入（32d）+ 结构位置编码（depth/subtree/sibling, 3d）= 35d
- 图边 = 父子边（双向）+ 兄弟边（相邻）+ 自环
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv, global_max_pool
import numpy as np
from typing import List, Tuple, Optional
from collections import deque
from torch_geometric.utils import softmax


# =============================================================================
# 1. AST 节点类型词汇表（Java + Python，与项目无关）
# =============================================================================

_JAVA_NODE_TYPES = [
    # 顶层结构
    'program', 'class_declaration', 'interface_declaration', 'enum_declaration',
    'annotation_type_declaration', 'record_declaration',
    # 类体成员
    'class_body', 'interface_body', 'enum_body', 'enum_body_declarations',
    'method_declaration', 'constructor_declaration', 'field_declaration',
    'constant_declaration', 'annotation_type_element_declaration',
    'static_initializer', 'instance_initializer',
    # 语句
    'block', 'expression_statement', 'local_variable_declaration',
    'if_statement', 'else_clause', 'for_statement', 'enhanced_for_statement',
    'while_statement', 'do_statement', 'return_statement', 'throw_statement',
    'try_statement', 'try_with_resources_statement', 'catch_clause', 'finally_clause',
    'switch_statement', 'switch_expression', 'switch_block_statement_group',
    'switch_rule', 'switch_label', 'break_statement', 'continue_statement',
    'synchronized_statement', 'assert_statement', 'labeled_statement',
    'empty_statement', 'yield_statement',
    # 表达式
    'assignment_expression', 'binary_expression', 'unary_expression',
    'update_expression', 'ternary_expression', 'cast_expression',
    'instanceof_expression', 'method_invocation', 'object_creation_expression',
    'array_access', 'field_access', 'array_creation_expression',
    'lambda_expression', 'method_reference', 'parenthesized_expression',
    'class_literal', 'this', 'super',
    # 声明与类型
    'formal_parameters', 'formal_parameter', 'spread_parameter',
    'receiver_parameter', 'type_parameters', 'type_parameter',
    'type_identifier', 'void_type', 'integral_type', 'floating_point_type',
    'boolean_type', 'array_type', 'generic_type', 'scoped_type_identifier',
    'type_arguments', 'wildcard', 'annotated_type', 'intersection_type',
    'union_type', 'inferred_parameters',
    # 其他
    'variable_declarator', 'argument_list', 'identifier', 'modifiers',
    'modifier', 'annotation', 'annotation_argument_list', 'element_value_pair',
    'element_value_array_initializer', 'import_declaration', 'package_declaration',
    'resource', 'resource_specification', 'catch_type', 'catch_formal_parameter',
    'string_literal', 'integer_literal', 'floating_point_literal',
    'boolean_literal', 'null_literal', 'character_literal', 'text_block',
    'line_comment', 'block_comment', 'constructor_body',
    'explicit_generic_invocation', 'explicit_generic_invocation_suffix',
    'dimensions', 'dimensions_expr', 'array_initializer',
    'extends_interfaces', 'super_interfaces', 'implements',
    'permits', 'throws', 'requires', 'provides', 'opens',
]

_PYTHON_NODE_TYPES = [
    'module', 'function_definition', 'decorated_definition', 'class_definition',
    'if_statement', 'elif_clause', 'else_clause',
    'for_statement', 'while_statement', 'try_statement',
    'except_clause', 'except_group_clause', 'finally_clause',
    'with_statement', 'with_item', 'return_statement', 'raise_statement',
    'import_statement', 'import_from_statement', 'aliased_import',
    'future_import_statement', 'wildcard_import',
    'assignment', 'augmented_assignment', 'annotated_assignment',
    'named_expression', 'type_alias_statement',
    'call', 'attribute', 'subscript', 'slice',
    'list', 'tuple', 'dictionary', 'set', 'pair', 'list_splat', 'dictionary_splat',
    'list_comprehension', 'set_comprehension', 'dictionary_comprehension',
    'generator_expression', 'comparison_operator', 'boolean_operator',
    'binary_operator', 'unary_operator', 'not_operator', 'await',
    'lambda', 'conditional_expression', 'yield', 'yield_from',
    'string', 'integer', 'float', 'true', 'false', 'none',
    'comment', 'expression_statement', 'delete_statement',
    'pass_statement', 'break_statement', 'continue_statement',
    'global_statement', 'nonlocal_statement', 'assert_statement',
    'block', 'parameters', 'parameter', 'default_parameter',
    'typed_parameter', 'typed_default_parameter', 'list_splat_pattern',
    'dictionary_splat_pattern', 'keyword_argument', 'positional_separator',
    'identifier', 'pattern_list', 'tuple_pattern', 'list_pattern',
    'match_statement', 'case_clause',
    'class_pattern', 'complex_pattern', 'splat_pattern',
]

# 去重合并，加 PAD 和 UNK
_ALL_NODE_TYPES = ['<PAD>', '<UNK>'] + sorted(set(_JAVA_NODE_TYPES + _PYTHON_NODE_TYPES))
NODE_TYPE_VOCAB: dict = {t: i for i, t in enumerate(_ALL_NODE_TYPES)}

STATEMENT_NODE_TYPES = {
    # Java
    'expression_statement', 'local_variable_declaration', 'if_statement',
    'else_clause', 'for_statement', 'enhanced_for_statement', 'while_statement',
    'do_statement', 'return_statement', 'throw_statement', 'try_statement',
    'try_with_resources_statement', 'catch_clause', 'finally_clause',
    'switch_statement', 'switch_expression', 'switch_block_statement_group',
    'switch_rule', 'switch_label', 'break_statement', 'continue_statement',
    'synchronized_statement', 'assert_statement', 'labeled_statement',
    'empty_statement', 'yield_statement', 'field_declaration',
    'constructor_declaration', 'method_declaration', 'constructor_body', 'block',
    # Python
    'expression_statement', 'assignment', 'augmented_assignment',
    'annotated_assignment', 'if_statement', 'elif_clause', 'else_clause',
    'for_statement', 'while_statement', 'try_statement', 'except_clause',
    'except_group_clause', 'finally_clause', 'with_statement',
    'return_statement', 'raise_statement', 'import_statement',
    'import_from_statement', 'future_import_statement', 'delete_statement',
    'pass_statement', 'break_statement', 'continue_statement',
    'global_statement', 'nonlocal_statement', 'assert_statement',
    'match_statement', 'case_clause', 'function_definition', 'class_definition',
    'decorated_definition', 'block',
}
COMMENT_NODE_TYPES = {'line_comment', 'block_comment', 'comment'}


VOCAB_SIZE: int = len(NODE_TYPE_VOCAB)   # ~220
EMBED_DIM:  int = 24                      # 节点类型可学习嵌入维度
STRUCT_DIM: int = 4                       # 结构位置特征维度 (depth, subtree, sibling, is_statement)
NODE_FEAT_DIM: int = EMBED_DIM + STRUCT_DIM  # 28，传入第一层 GNN 的维度


# =============================================================================
# 2. AST 图构建器
# =============================================================================

class ASTGraphBuilder:
    """
    基于 tree-sitter 的 AST 图构建器。
    
    节点：AST 中每个语法节点（包括叶节点）
    节点特征：
        - type_idx  (long): 节点类型在 NODE_TYPE_VOCAB 中的索引
        - x (float, 4d) : [depth_norm, subtree_size_log_norm, sibling_rank_norm, is_statement]
    边：
        - 父子边（双向）
        - 相邻兄弟边（双向）
        - 自环
    行映射：每个 AST 节点映射到其起始行号（0-based）
    
    当 tree-sitter 不可用或解析失败时，自动回退到 token 滑动窗口图。
    """

    def __init__(self, language: str = 'java', line_win: int = 6, max_nodes: int = 8000):
        """
        Args:
            language:  tree-sitter 语言名称，'java' 或 'python'
            line_win:  行级图的滑动窗口大小
            max_nodes: 单文件最大 AST 节点数（超过则裁剪，防止 OOM）
        """
        self.language = language
        self.line_win = line_win
        self.max_nodes = max_nodes
        self.parser = None
        self._init_parser()

    def _init_parser(self):
        """初始化 tree-sitter 解析器，失败则静默降级。"""
        try:
            from tree_sitter_languages import get_parser
            self.parser = get_parser(self.language)
            print(f"[ASTGraphBuilder] tree-sitter-{self.language} 初始化成功，"
                  f"词汇表大小={VOCAB_SIZE}，节点特征维度={NODE_FEAT_DIM}")
        except ImportError:
            print("[ASTGraphBuilder] ⚠ tree_sitter_languages 未安装，"
                  "请运行: pip install tree-sitter-languages\n"
                  "         将使用 token 滑动窗口作为 fallback。")
        except Exception as e:
            print(f"[ASTGraphBuilder] ⚠ tree-sitter 初始化失败 ({e})，使用 fallback。")

    # ------------------------------------------------------------------ #
    # Public API                                                           #
    # ------------------------------------------------------------------ #

    def build_one(self, lines: List[str]):
        """
        构建单个源文件的图数据。
        
        Args:
            lines: 文件的所有行（List[str]）
        
        Returns:
            tok_data  : PyG Data，AST 节点图
                        .x         (N, STRUCT_DIM) float，结构位置特征
                        .type_idx  (N,) long，节点类型索引
                        .edge_index (2, E) long
            line_data : PyG Data，行级滑动窗口图
                        .edge_index (2, E) long
                        .num_nodes  int
            line_map  : (N,) long，每个 AST 节点对应的行号（0-based）
        """
        num_lines = len(lines)
        if num_lines == 0:
            lines = ['']
            num_lines = 1

        if self.parser is not None:
            try:
                source = '\n'.join(lines)
                return self._build_ast_graph(source, num_lines)
            except Exception as e:
                pass  # 静默降级

        return self._build_fallback_graph(lines)

    # ------------------------------------------------------------------ #
    # AST Graph (tree-sitter path)                                        #
    # ------------------------------------------------------------------ #

    def _build_ast_graph(self, source: str, num_lines: int):
        from torch_geometric.data import Data

        tree = self.parser.parse(bytes(source, 'utf-8', errors='replace'))
        root = tree.root_node

        # BFS 遍历，收集节点信息
        (type_indices, depths, subtrees, sib_ranks, is_statements,
         node_lines, all_edges) = self._collect_nodes_bfs(root, num_lines)

        num_nodes = len(type_indices)
        if num_nodes == 0:
            return self._build_fallback_graph(source.splitlines() or [''])

        # 构建 tok_data
        struct_feat = torch.tensor(
            list(zip(depths, subtrees, sib_ranks, is_statements)), dtype=torch.float
        )  # (N, 4)
        type_idx_t = torch.tensor(type_indices, dtype=torch.long)

        node_lines_clipped = [min(max(0, l), num_lines - 1) for l in node_lines]
        line_map = torch.tensor(node_lines_clipped, dtype=torch.long)

        edge_index = self._build_edge_index(all_edges, num_nodes)

        tok_data = Data(x=struct_feat, edge_index=edge_index)
        tok_data.type_idx = type_idx_t

        line_data = self._build_line_graph(num_lines)
        return tok_data, line_data, line_map

    def _collect_nodes_bfs(self, root_node, num_lines: int):
        """
        BFS 遍历 AST，收集节点属性和边。

        Returns:
            type_indices  : List[int]
            depths        : List[float] normalized
            subtrees      : List[float] log-normalized
            sib_ranks     : List[float] normalized
            is_statements : List[float] 0/1
            node_lines    : List[int]  0-based line number
            all_edges     : List[Tuple[int, int]]  (src, dst) pairs
        """
        def _valid_children(node):
            return [ch for ch in node.children if ch.type not in COMMENT_NODE_TYPES]

        # ---- Pass 1: BFS 分配 ID，记录基本信息 ----
        node_info = []   # (node, depth, parent_id, sib_idx, num_sibs)
        root_children = _valid_children(root_node)
        q = deque([(root_node, 0, -1, 0, max(1, len(root_children)))])

        while q and len(node_info) < self.max_nodes:
            node, depth, parent_id, sib_idx, num_sibs = q.popleft()
            if node.type in COMMENT_NODE_TYPES:
                continue

            my_id = len(node_info)
            node_info.append((node, depth, parent_id, sib_idx, num_sibs))

            children = _valid_children(node)
            n_ch = max(1, len(children))
            for i, child in enumerate(children):
                if len(node_info) + len(q) < self.max_nodes:
                    q.append((child, depth + 1, my_id, i, n_ch))

        num_nodes = len(node_info)
        if num_nodes == 0:
            return [], [], [], [], [], [], []

        # ---- Pass 2: 自底向上计算子树大小 ----
        subtree_size = [1] * num_nodes
        for i in range(num_nodes - 1, -1, -1):
            _, _, parent_id, _, _ = node_info[i]
            if parent_id >= 0:
                subtree_size[parent_id] += subtree_size[i]

        max_depth = max(max(info[1] for info in node_info), 1)
        max_subtree = max(max(subtree_size), 1)

        # ---- Pass 3: 收集特征和边 ----
        type_indices = []
        depths = []
        subtrees = []
        sib_ranks = []
        is_statements = []
        node_lines = []
        parent_child_edges = []
        sibling_edges = []

        children_by_parent = {}  # parent_id -> [(sib_idx, child_id)]

        for i, (node, depth, parent_id, sib_idx, num_sibs) in enumerate(node_info):
            type_indices.append(NODE_TYPE_VOCAB.get(node.type, NODE_TYPE_VOCAB['<UNK>']))
            depths.append(depth / max_depth)
            subtrees.append(np.log1p(subtree_size[i]) / np.log1p(max_subtree))
            sib_ranks.append(sib_idx / max(num_sibs - 1, 1))
            is_statements.append(1.0 if node.type in STATEMENT_NODE_TYPES else 0.0)
            node_lines.append(node.start_point[0])

            if parent_id >= 0:
                parent_child_edges.append((parent_id, i))
                parent_child_edges.append((i, parent_id))
                children_by_parent.setdefault(parent_id, []).append((sib_idx, i))

        # 相邻兄弟边
        for _, children in children_by_parent.items():
            sorted_ch = sorted(children, key=lambda x: x[0])
            for k in range(len(sorted_ch) - 1):
                a = sorted_ch[k][1]
                b = sorted_ch[k + 1][1]
                sibling_edges.append((a, b))
                sibling_edges.append((b, a))

        all_edges = parent_child_edges + sibling_edges
        return type_indices, depths, subtrees, sib_ranks, is_statements, node_lines, all_edges

    # ------------------------------------------------------------------ #
    # Fallback: token sliding window graph                                #
    # ------------------------------------------------------------------ #

    def _build_fallback_graph(self, lines: List[str]):
        """
        当 tree-sitter 不可用时的回退方案。
        节点 = token，特征 = 简单三分类（关键字/操作符/其他）。
        """
        from torch_geometric.data import Data

        _KW = {
            'if', 'else', 'for', 'while', 'do', 'return', 'throw',
            'try', 'catch', 'finally', 'class', 'interface', 'new',
            'this', 'super', 'null', 'true', 'false', 'import',
            'public', 'private', 'protected', 'static', 'final', 'void',
            'def', 'lambda', 'yield', 'with', 'as', 'and', 'or', 'not',
            'in', 'is', 'pass', 'break', 'continue', 'raise', 'from',
        }

        all_tokens, token_line_ids = [], []
        for line_idx, line in enumerate(lines):
            toks = line.split()
            all_tokens.extend(toks)
            token_line_ids.extend([line_idx] * len(toks))

        num_tokens = len(all_tokens)
        num_lines  = len(lines)

        if num_tokens == 0:
            all_tokens     = ['<empty>']
            token_line_ids = [0]
            num_tokens     = 1

        def _feat(t):
            if t.lower() in _KW:
                return [1.0, 0.0, 0.0, 0.0]
            if any(c in t for c in '=+-*/<>!&|'):
                return [0.0, 1.0, 0.0, 0.0]
            return [0.0, 0.0, 1.0, 0.0]

        struct_feat  = torch.tensor([_feat(t) for t in all_tokens], dtype=torch.float)
        type_idx_t   = torch.ones(num_tokens, dtype=torch.long)  # all <UNK>
        line_map     = torch.tensor(token_line_ids, dtype=torch.long)

        # 滑动窗口边（窗口=2）
        edge_parts = []
        sl = torch.arange(num_tokens, dtype=torch.long)
        edge_parts.append(torch.stack([sl, sl], dim=0))
        base = torch.arange(num_tokens, dtype=torch.long)
        for w in [1, 2]:
            if num_tokens > w:
                s, d = base[:-w], base[w:]
                edge_parts.append(torch.stack([s, d], dim=0))
                edge_parts.append(torch.stack([d, s], dim=0))

        edge_index = torch.cat(edge_parts, dim=1)

        tok_data = Data(x=struct_feat, edge_index=edge_index)
        tok_data.type_idx = type_idx_t

        line_data = self._build_line_graph(num_lines)
        return tok_data, line_data, line_map

    # ------------------------------------------------------------------ #
    # Line graph + edge helpers                                           #
    # ------------------------------------------------------------------ #

    def _build_line_graph(self, num_lines: int):
        """构建行级滑动窗口图。"""
        from torch_geometric.data import Data

        if num_lines == 0:
            return Data(edge_index=torch.zeros((2, 0), dtype=torch.long), num_nodes=0)

        parts = []
        sl = torch.arange(num_lines, dtype=torch.long)
        parts.append(torch.stack([sl, sl], dim=0))

        base = torch.arange(num_lines, dtype=torch.long)
        for w in range(1, self.line_win):
            if num_lines > w:
                s, d = base[:-w], base[w:]
                parts.append(torch.stack([s, d], dim=0))
                parts.append(torch.stack([d, s], dim=0))

        edge_index = torch.cat(parts, dim=1)
        return Data(edge_index=edge_index, num_nodes=num_lines)

    @staticmethod
    def _build_edge_index(edges: list, num_nodes: int) -> torch.Tensor:
        """将边列表 + 自环转换为 edge_index。"""
        sl = torch.arange(num_nodes, dtype=torch.long)
        self_loop_part = torch.stack([sl, sl], dim=0)

        if edges:
            edge_t = torch.tensor(edges, dtype=torch.long).t().contiguous()
            return torch.cat([edge_t, self_loop_part], dim=1)
        return self_loop_part


# =============================================================================
# 3. 工具函数
# =============================================================================

def scatter_add(src, index, dim=0, out=None, dim_size=None):
    """torch_scatter.scatter_add 的纯 PyTorch 实现。"""
    if out is None:
        size = list(src.size())
        if dim_size is not None:
            size[dim] = dim_size
        elif index.numel() == 0:
            size[dim] = 0
        else:
            size[dim] = int(index.max()) + 1
        out = torch.zeros(size, dtype=src.dtype, device=src.device)

    if index.dim() != src.dim():
        if dim < 0:
            dim = src.dim() + dim
        view_shape = [1] * src.dim()
        view_shape[dim] = -1
        index = index.view(view_shape).expand_as(src)

    return out.scatter_add_(dim, index, src)


# =============================================================================
# 4. GNN 模型
# =============================================================================

class LineDefGCNAtt(nn.Module):
    """
    AST 版 GNN 特征提取层（多尺度版）。

    输入：
        x        : (N, STRUCT_DIM)   结构位置特征
        type_idx : (N,)              节点类型索引
        edge_index, batch            标准 PyG 参数

    内部流程：
        1. 节点类型嵌入（默认 24d）
        2. 与结构特征拼接 → 28 维（当 use_struct_pos_encoding=True）
        3. 三层混合卷积：GCN -> GAT -> GCN
        4. 跳跃连接：拼接 h1/h2/h3 得到多尺度节点表示
        5. Bottleneck 压缩（默认 96 -> 48）
        6. 注意力池化 + 最大池化 + 平均池化
        7. 拼接得到文件向量

    输出：
        file_vec : (B, out_dim)  文件级特征向量
    """

    def __init__(self,
                 vocab_size: int = VOCAB_SIZE,
                 embed_dim: int = EMBED_DIM,
                 struct_dim: int = STRUCT_DIM,
                 hidden_channels: int = 128,
                 out_channels: int = 64,
                 dropout: float = 0.5,
                 in_channels: int = None,
                 use_struct_pos_encoding: bool = True,
                 num_graphs: int = 1):
        super().__init__()

        self.dropout = dropout
        self.embed_dim = embed_dim
        self.struct_dim = struct_dim
        self.use_struct_pos_encoding = use_struct_pos_encoding
        self.num_graphs = num_graphs
        
        # 如果不使用结构位置编码，输入维度只包含节点类型嵌入
        # 多图情况下，类型嵌入维度 = embed_dim * num_graphs
        input_dim = embed_dim * num_graphs + struct_dim if use_struct_pos_encoding else embed_dim * num_graphs

        self.node_embed = nn.Embedding(vocab_size, embed_dim, padding_idx=0)
        nn.init.xavier_uniform_(self.node_embed.weight[1:])

        self.conv1 = GCNConv(input_dim, hidden_channels)
        self.ln1 = nn.LayerNorm(hidden_channels)

        self.conv2 = GCNConv(hidden_channels, hidden_channels)
        self.ln2 = nn.LayerNorm(hidden_channels)

        self.conv3 = GCNConv(hidden_channels, hidden_channels)
        self.ln3 = nn.LayerNorm(hidden_channels)

        half_out = out_channels // 2
        self.bottleneck = nn.Sequential(
            nn.Linear(hidden_channels, half_out),
            nn.Tanh()
        )
        self.att_weight = nn.Linear(half_out, 1)
        self.out_dim = half_out * 2
        self.out_channels = self.out_dim

    def forward(self, x, edge_index, batch,
                line_batch_vec=None, type_idx=None):
        """
        Args:
            x          : (N, struct_dim) 结构特征
            edge_index : (2, E)
            batch      : (N,) batch 向量
            type_idx   : (N,) 或 (N, num_graphs) long，节点类型索引
                        - 单图：一维张量
                        - 多图：二维张量，每列对应一个图类型的类型索引
        """
        if type_idx is not None:
            if type_idx.dim() == 1:
                # 单图情况
                type_emb = self.node_embed(type_idx)
            else:
                # 多图情况：每个图类型有独立的类型嵌入
                num_graphs = type_idx.size(1)
                type_embs = []
                for i in range(num_graphs):
                    type_embs.append(self.node_embed(type_idx[:, i]))
                type_emb = torch.cat(type_embs, dim=1)  # (N, embed_dim * num_graphs)
        else:
            type_emb = torch.zeros(x.size(0), self.embed_dim, device=x.device)

        # 根据 use_struct_pos_encoding 决定是否拼接结构特征
        if self.use_struct_pos_encoding:
            h0 = torch.cat([type_emb, x], dim=1)
        else:
            h0 = type_emb

        h1 = self.conv1(h0, edge_index)
        h1 = self.ln1(h1)
        h1 = F.relu(h1)
        h1 = F.dropout(h1, p=self.dropout, training=self.training)

        h2 = self.conv2(h1, edge_index)
        h2 = self.ln2(h2)
        h2 = F.relu(h2)
        h2 = h2 + h1
        h2 = F.dropout(h2, p=self.dropout, training=self.training)

        h3 = self.conv3(h2, edge_index)
        h3 = self.ln3(h3)
        h3 = F.relu(h3)
        h3 = h3 + h2
        h3 = F.dropout(h3, p=self.dropout, training=self.training)

        h_c = self.bottleneck(h3)

        scores = self.att_weight(h_c)
        alpha = softmax(scores, batch)
        att_pool = scatter_add(h_c * alpha, batch, dim=0)
        max_pool = global_max_pool(h_c, batch)

        file_vec = torch.cat([att_pool, max_pool], dim=1)
        return file_vec, None, alpha, None


# =============================================================================
# 向后兼容：保留旧类名的别名（已废弃，仅供过渡）
# =============================================================================

class TokenEmbedding:
    """已废弃，保留仅供向后兼容检查。"""
    def __init__(self, *args, **kwargs):
        raise RuntimeError(
            "TokenEmbedding 已废弃，请使用 ASTGraphBuilder 替代。"
        )


class LineDefGraphBuilder:
    """已废弃，保留仅供向后兼容检查。"""
    def __init__(self, *args, **kwargs):
        raise RuntimeError(
            "LineDefGraphBuilder 已废弃，请使用 ASTGraphBuilder 替代。"
        )